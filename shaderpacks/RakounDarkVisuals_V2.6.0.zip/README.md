# 🦝 Rakoun Dark Visuals — v2.0 BETA

Shaderpack **Dark Fantasy** pour **Minecraft 1.16.5 → 1.21.x** · Compatible **Oculus** (Forge) et **Iris** (Fabric) · Menu en **français** et anglais

*A dark fantasy shaderpack for Minecraft 1.16.5 – 1.21.x — Oculus & Iris compatible. English menu included.*

---

## ✨ Points forts

- **Reflets écran (SSR)** de haute précision sur l'eau, le verre et les sols
  mouillés — marche en espace écran à tolérance relative, normales
  octaédriques 16 bits, extension de bord
- **TAA** (anti-crénelage temporel) + **motion blur** cinématique
- **Nuits profondes** : obscurité assumée, îlots de lumière dorée généreux
  autour des lanternes et torches (flammes qui vacillent, lumière portée
  en main, lanternes qui se balancent au vent)
- **Pluie vivante** : sols mouillés avec flaques réfléchissantes, matériaux
  différenciés (la pierre luit, le bois fonce, la terre absorbe), anneaux
  d'impact sur l'eau et dans les reflets des flaques, gouttes sur l'écran,
  végétation en tempête
- **Eau complète** : vagues procédurales jamais répétitives qui déplacent
  la surface, écume de rivage, assombrissement par profondeur, caustiques
  dansantes, couleur claire teintée par le biome
- **Fondu procédural entre blocs** *(exclusivité)* : les frontières
  herbe/chemin/pierre se mélangent en lignes organiques uniques — routes
  usées, mousse qui déborde
- **Remontée de végétation** *(exclusivité)* : l'herbe grimpe naturellement
  sur la base des blocs posés
- **Atmosphère** : vraie lumière volumétrique (raymarch de la shadow map),
  god rays, nuages volumétriques, brume au sol en nappes dérivantes,
  crépuscules rouge sang
- **Détails** : SSAO, relief automatique des textures, variations
  organiques du sol, compatibilité mods (tags Iris 1.7+ et listes
  explicites, dont Oh The Biomes We've Gone)
- **Pipeline HDR cinéma** : tonemap ACES préservant les ors, auto-exposition,
  bloom, aberration chromatique, vignettage, grain, DOF et bandes cinéma
  optionnels
- **Nether et End** avec ambiances dédiées (première passe)

## 📥 Installation

1. Installer **Oculus** (Forge) ou **Iris** (Fabric) pour votre version de Minecraft (1.16.5 a 1.21.x).
2. Placer le zip du pack dans `.minecraft/shaderpacks/`.
3. En jeu : Options → Options graphiques → Shaders → sélectionner le pack.

## ⚙️ Réglages

Menu « Réglages du shader » en jeu, avec **3 profils** :

| Profil | Usage |
|---|---|
| **Performance** | Petites configs — ombres 1024, effets volumétriques allégés |
| **Équilibré** *(défaut)* | Le rendu de référence |
| **Qualité** | Screenshots et grosses configs |

Réglages notables : *Luminosité nocturne* (si les nuits sont trop rudes),
*Flou de mouvement* (question de goût), *Profondeur de champ* (pour les
screenshots), et tous les effets désactivables individuellement.

## ⚠️ BETA — problèmes connus

- Les reflets SSR ne peuvent pas montrer ce qui est hors écran (limite de
  la technique) : un objet qui sort du champ voit son reflet s'estomper.
  Une option expérimentale « Reflets hors écran (capture 360°) » existe
  dans le menu Eau.
- L'ondulation des feuillages moddés nécessite **Iris 1.7+** (tags de
  blocs). Sous Oculus, les blocs vanilla et *Oh The Biomes We've Gone*
  sont couverts par des listes explicites.
- Le Nether et l'End ont une ambiance dédiée mais moins aboutie que
  l'Overworld.
- Le TAA adoucit légèrement l'image (comportement normal de la technique).

Retours et bugs bienvenus — merci de joindre un screenshot et de préciser
si l'artefact est fixe dans le monde, collé à l'écran, ou suit le joueur.

## 🙏 Crédits

- Conception et direction : **Rakoun**
- Développement : assisté par **Claude** (Anthropic)
- L'architecture de la marche SSR s'inspire des techniques de
  **Kappa Shader** (rre36) — merci pour l'inspiration
- Merci à la communauté **shaderLABS** pour la documentation du format

## 📜 Licence

Voir `LICENSE.txt` — utilisation et modification personnelles libres,
redistribution interdite sans autorisation, crédit requis.

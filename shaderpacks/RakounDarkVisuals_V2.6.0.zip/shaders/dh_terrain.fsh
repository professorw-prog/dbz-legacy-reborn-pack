#version 330 compatibility

// DISTANT HORIZONS : shading du terrain LOD.
//  - couleur = gl_Color de DH (pas de texture) + micro-variation bruitée
//    façon texels (sans elle, les LOD sont des aplats plastiques)
//  - lumière = NOTRE formule (l'ombre est estimée par la lightmap : la
//    shadow map ne porte pas à ces distances)
//  - FONDU d'apparition dithéré entre far*0.5 et far*0.75 : les vrais
//    chunks gardent la main de près, le LOD prend le relai sans couture
//  - le fog vient de composite (resolve DH sur dhDepthTex)

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

flat in int matId;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalW;
in vec3 playerPos;

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float far;
uniform int frameCounter;
uniform int dhRenderDistance;

void main() {
    // Le DÔME DE NUAGES de DH passe AUSSI par cette passe (opaque !) —
    // le vrai terrain LOD vit sous la hauteur du monde et en-deçà de la
    // distance DH : tout le reste est écarté (sinon : dôme gris permanent
    // peint dans le ciel).
    if (length(playerPos) > float(dhRenderDistance) + 64.0
     || playerPos.y + cameraPosition.y > 400.0) discard;

    vec3 albedo = srgbToLinear(glcolor.rgb);

    // micro-variation par "texels" de 0.25 bloc : casse les aplats
    vec3 wp = playerPos + cameraPosition;
    vec2 np = floor(wp.xz * 4.0 + 0.001) / 8.0 + floor(wp.y * 4.0) * 0.731;
    float nz = valueNoise(np);
    albedo *= 0.86 + 0.28 * nz;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;
    vec3 N = normalize(normalW);
    vec3 lightW = safeNormalize(mat3(gbufferModelViewInverse) * shadowLightPosition);

    float NdotL = clamp(dot(N, lightW), 0.0, 1.0);
    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);   // ombre estimée
    float skyGate = smoothstep(0.05, 0.35, lmcoord.y);
    float hemi = 0.45 + 0.55 * (N.y * 0.5 + 0.5);
    float flick = torchFlicker(frameTimeCounter);

    vec3 light = getShadowLightColor(sunH, rainStrength) * (skyExposure * NdotL * skyGate)
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y) * hemi
               + getTorchLight(lmcoord.x) * flick
               + CAVE_AMBIENT;

    vec3 color = albedo * light;

    // émissifs DH (catégories fournies par Iris)
    float lum = luminance(albedo);
    if (matId == DH_BLOCK_LAVA) {
        color = albedo * light * 0.25 + albedo * pow(lum, 1.5) * 7.0;
    } else if (matId == DH_BLOCK_ILLUMINATED) {
        color += albedo * pow(lum, 2.0) * 6.0 * flick;
    }

    // fondu d'apparition (cylindre, comme DH lui-même) + dither
    float cyl = max(length(playerPos.xz), abs(playerPos.y));
    float aIn = smoothstep(far * 0.5, far * 0.75, cyl);
    // dither STATIQUE (pas de terme temporel) : en mouvement le TAA
    // rejette son historique et un dither animé devenait un anneau de
    // grésillement visible autour du joueur
    float dither = hash12(gl_FragCoord.xy);
    if (aIn < dither) discard;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

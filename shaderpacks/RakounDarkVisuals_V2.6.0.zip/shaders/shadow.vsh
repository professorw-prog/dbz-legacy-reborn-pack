#version 430 compatibility

// Passe shadow map : rend la scène du point de vue du soleil/de la lune.
// Pour le GI (RSM), elle écrit AUSSI l'albedo (shadowcolor0) et la
// normale (shadowcolor1) de chaque texel : chaque point éclairé devient
// une petite source de lumière rebondie.
//
// v2.4 : elle VOXELISE aussi les blocs (technique ACL, apprise de
// FantasyShader/Complementary) — chaque sommet écrit l'ID matière de son
// bloc dans une image 3D centrée caméra (128x64x128). Le compute
// shadowcomp.csh y propage ensuite la lumière colorée en flood-fill.
// Iris/Oculus uniquement (images 3D) : OptiFine compile sans ce bloc.

#include "/lib/settings.glsl"
#include "/lib/shadows.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normalM;

#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
    attribute vec4 mc_Entity;
    attribute vec4 at_midBlock;

    uniform int renderStage;
    uniform vec3 cameraPosition;
    uniform mat4 shadowModelViewInverse;

    writeonly uniform image3D voxel_img;   // r8 float : id/255

    const ivec3 voxelVolumeSize = ivec3(128, 64, 128);

    // IDs voxel : 0 = air/traverse, 1 = occulteur, 2+ = émetteur,
    // 200-215 = vitrail (teinte la lumière qui passe).
    // Doit rester cohérent avec shadowcomp.csh.
    int voxelId(float mat) {
        if (mat == 10010.0 || mat == 10011.0) return 2;   // feu doré
        if (mat == 11001.0 || mat == 11002.0) return 3;   // âmes
        if (mat == 11003.0) return 4;                     // redstone
        if (mat == 11004.0) return 5;                     // sea lantern
        if (mat == 11005.0) return 6;                     // améthyste
        if (mat == 11006.0) return 7;                     // end rod
        if (mat == 11007.0) return 8;                     // glowstone
        if (mat == 11008.0) return 9;                     // shroomlight
        if (mat == 11009.0) return 10;                    // froglight ocre
        if (mat == 11010.0) return 11;                    // froglight vert
        if (mat == 11011.0) return 12;                    // froglight nacré
        if (mat == 10009.0) return 13;                    // lave / magma
        if (mat == 10014.0) return 14;                    // portail (sang)
        if (mat >= 11020.0 && mat <= 11035.0)
            return 200 + int(mat - 11020.0);              // vitraux
        // traversés par la lumière : eau, verre clair, glace, plantes
        if (mat == 10008.0 || mat == 10012.0 || mat == 10013.0
         || mat == 10001.0 || mat == 10002.0) return 0;
        // le reste : les blocs du pass SOLID occultent, le cutout
        // (feuilles, fleurs...) laisse passer
        if (renderStage == MC_RENDER_STAGE_TERRAIN_SOLID) return 1;
        return 0;
    }
#endif

void main() {
    gl_Position = ftransform();

    #if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
    if (renderStage == MC_RENDER_STAGE_TERRAIN_SOLID
     || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT
     || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED
     || renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT) {
        int vid = voxelId(mc_Entity.x);
        if (vid > 0) {
            // centre du bloc en espace scène (caméra-relatif) -> voxel
            vec3 modelPos = gl_Vertex.xyz + at_midBlock.xyz / 64.0;
            vec3 scenePos = (shadowModelViewInverse
                    * (gl_ModelViewMatrix * vec4(modelPos, 1.0))).xyz;
            vec3 voxelPos = scenePos + fract(cameraPosition)
                          + 0.5 * vec3(voxelVolumeSize);
            if (clamp(voxelPos, vec3(0.0), vec3(voxelVolumeSize) - 0.5) == voxelPos) {
                imageStore(voxel_img, ivec3(voxelPos),
                        vec4(float(vid) / 255.0, 0.0, 0.0, 0.0));
            }
        }
    }
    #endif

    gl_Position.xyz = distortShadowClip(gl_Position.xyz);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    // Le terrain n'est jamais tourné : l'espace modèle EST l'orientation
    // monde — suffisant pour orienter les rebonds du GI
    normalM = normalize(gl_Normal);
}

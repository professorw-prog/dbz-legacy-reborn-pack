#version 120

// NETHER : deferred NEUTRE (dédié — jamais écrasé par sync_worlds).
// Pas de VL solaire ni de mer de brouillard ici : la version Overworld
// calculait les nappes (colortex6.b) que final utilisait pour gonfler le
// bloom -> taches marbrées blanches sur toute la géométrie du Nether.

varying vec2 texcoord;

void main() {
/* DRAWBUFFERS:6 */
    // vl neutre, brume nulle — alpha 0.0 = MARQUEUR "Nether" lu par final
    // (la brume de chaleur y est appliquée APRÈS le TAA, sinon smear)
    gl_FragData[0] = vec4(1.0, 1.0, 0.0, 0.0);
}

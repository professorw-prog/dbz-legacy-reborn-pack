#version 120

// Passe shadow map : rend la scène du point de vue du soleil/de la lune.
// Pour le GI (RSM), elle écrit AUSSI l'albedo (shadowcolor0) et la
// normale (shadowcolor1) de chaque texel : chaque point éclairé devient
// une petite source de lumière rebondie.

#include "/lib/settings.glsl"
#include "/lib/shadows.glsl"

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normalM;

void main() {
    gl_Position = ftransform();
    gl_Position.xyz = distortShadowClip(gl_Position.xyz);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    // Le terrain n'est jamais tourné : l'espace modèle EST l'orientation
    // monde — suffisant pour orienter les rebonds du GI
    normalM = normalize(gl_Normal);
}

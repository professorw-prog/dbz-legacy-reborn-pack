#version 120

// Passe finale : aberration chromatique, bloom, tonemapping,
// étalonnage Dark Fantasy façon pellicule, vignettage, grain,
// bandes cinéma optionnelles.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex3;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform ivec2 eyeBrightnessSmooth;
uniform int isEyeInWater;

varying vec2 texcoord;

#ifdef SCREEN_DROPLETS
// Gouttes d'eau sur l'objectif : naissent, glissent, s'évaporent.
// Chaque goutte réfracte l'image comme une petite loupe.
vec2 dropletOffset(vec2 uv, float t, float wet) {
    float aspect = viewWidth / viewHeight;
    vec2 p = uv * vec2(aspect, 1.0);
    vec2 g = vec2(0.0);
    for (int L = 0; L < 2; L++) {
        float sc = (L == 0) ? 5.0 : 9.0;
        vec2 pp = p * sc + float(L) * 3.71;
        vec2 id = floor(pp);
        vec2 f = fract(pp) - 0.5;
        float rnd = hash12(id + float(L) * 17.3);
        if (rnd < 0.08 + wet * 0.25) {
            float ph = fract(t * 0.12 + rnd * 13.0); // vie de la goutte
            vec2 c = (vec2(hash12(id + 5.1), hash12(id + 8.7)) - 0.5) * 0.55;
            c.y -= ph * ph * 0.35; // glisse vers le bas en accélérant
            vec2 dv = f - c;
            float rr = (0.10 + 0.10 * hash12(id + 2.9)) * (1.0 - ph * 0.7);
            float d = length(dv);
            if (d < rr) {
                g += dv * (d / rr - 1.0) * (1.4 / sc);
            }
        }
    }
    return g * vec2(1.0 / aspect, 1.0);
}
#endif

void main() {
    // Vue de diagnostic : gauche = image brute (avant étalonnage),
    // droite = carte de profondeur (noir = rien n'est rendu)
    #ifdef DEBUG_VIEW
        // 4 quadrants : HG = scène brute (colortex0), HD = bloom x4
        // (colortex1), BG = colortex6 (VL / brume / marqueur), BD = profondeur.
        // -> si le marbré apparaît en HD : c'est le bloom ; en BG : le
        // deferred ; seulement en HG : peint avant (gbuffers/composite/TAA)
        if (texcoord.x < 0.5 && texcoord.y >= 0.5) {
            vec2 q = vec2(texcoord.x * 2.0, texcoord.y * 2.0 - 1.0);
            gl_FragData[0] = vec4(texture2D(colortex0, q).rgb, 1.0);
        } else if (texcoord.x >= 0.5 && texcoord.y >= 0.5) {
            vec2 q = vec2(texcoord.x * 2.0 - 1.0, texcoord.y * 2.0 - 1.0);
            gl_FragData[0] = vec4(texture2D(colortex1, q * 0.5).rgb * 4.0, 1.0);
        } else if (texcoord.x < 0.5) {
            vec2 q = vec2(texcoord.x * 2.0, texcoord.y * 2.0);
            gl_FragData[0] = vec4(texture2D(colortex6, q * 0.5).rgb, 1.0);
        } else {
            vec2 q = vec2(texcoord.x * 2.0 - 1.0, texcoord.y * 2.0);
            float dRaw = texture2D(depthtex0, q).r;
            gl_FragData[0] = vec4(vec3(1.0 - pow(dRaw, 64.0)), 1.0);
        }
        return;
    #endif

    vec2 v = texcoord - 0.5;

    // Gouttes sur l'écran : seulement sous la pluie, à ciel ouvert
    vec2 uvD = texcoord;
    #ifdef SCREEN_DROPLETS
        float lensWet = rainStrength * clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
        if (lensWet > 0.01) uvD += dropletOffset(texcoord, frameTimeCounter, lensWet);
    #endif

    // Sous l'eau : la vision ondule doucement (réfraction)
    if (isEyeInWater == 1) {
        uvD += vec2(sin(texcoord.y * 14.0 + frameTimeCounter * 1.7),
                    cos(texcoord.x * 12.0 - frameTimeCounter * 1.3)) * 0.0022;
    }

    // NETHER (marqueur colortex6.a = 0, écrit par son deferred dédié) :
    // brume de chaleur APPLIQUÉE ICI, APRÈS le TAA — l'ondulation pré-TAA
    // transformait le basalte contrasté en marbrures blanches baveuses.
    // AUCUNE ondulation de base (sinon sensation de caméra qui tangue) :
    // uniquement de la turbulence FINE et ASCENDANTE au-dessus du chaud
    float dimFlag = texture2D(colortex6, texcoord * 0.5).a;
    float heatShimmer = 0.0;
    if (dimFlag < 0.1) {
        vec3 below = max(texture2D(colortex0, max(texcoord - vec2(0.0, 0.05), 0.0)).rgb,
                         texture2D(colortex0, max(texcoord - vec2(0.0, 0.12), 0.0)).rgb);
        float heat = clamp((below.r - below.b) * 1.5, 0.0, 1.0)
                   * clamp(luminance(below) * 1.2, 0.0, 1.0);
        if (heat > 0.02) {
            // LE MIRAGE : colonnes d'air chaud qui MONTENT — déplacement
            // surtout HORIZONTAL, modulé par un bruit qui défile vers le
            // haut (l'effet "au-dessus d'un feu"), + fines bandes de
            // lueur ascendantes (heatShimmer, appliqué plus bas)
            vec2 px = vec2(viewWidth, viewHeight);
            float w1 = valueNoise(vec2(texcoord.x * px.x * 0.012,
                                       texcoord.y * px.y * 0.008 - frameTimeCounter * 2.8));
            float w2 = valueNoise(vec2(texcoord.x * px.x * 0.028 + 31.0,
                                       texcoord.y * px.y * 0.018 - frameTimeCounter * 4.6));
            uvD.x += ((w1 - 0.5) * 0.010 + (w2 - 0.5) * 0.004) * heat;
            uvD.y += (w2 - 0.5) * 0.0035 * heat;
            heatShimmer = ((w1 - 0.5) + (w2 - 0.5)) * heat;
        }
    }

    // Aberration chromatique : les canaux R et B dérivent vers les bords
    vec2 caOff = v * dot(v, v) * 0.012 * CHROMATIC_ABERRATION;
    vec3 color;
    color.r = texture2D(colortex0, uvD + caOff).r;
    color.g = texture2D(colortex0, uvD).g;
    color.b = texture2D(colortex0, uvD - caOff).b;

    // Flou de bord : les bords de l'écran fondent doucement, le regard
    // est guidé vers le centre — façon tableau sombre. Subtil par défaut,
    // désactivable (les bords qui fuient ne plaisent pas à tout le monde).
    #ifdef EDGE_BLUR
    {
        float edgeF = smoothstep(0.12, 0.55, dot(v, v)) * EDGE_BLUR_STRENGTH;
        if (edgeF > 0.01) {
            float rad = edgeF * 0.008;
            vec3 blur = color;
            blur += texture2D(colortex0, uvD + vec2( rad,  rad * 0.6)).rgb;
            blur += texture2D(colortex0, uvD + vec2(-rad,  rad * 0.6)).rgb;
            blur += texture2D(colortex0, uvD + vec2( rad, -rad * 0.6)).rgb;
            blur += texture2D(colortex0, uvD + vec2(-rad, -rad * 0.6)).rgb;
            blur += texture2D(colortex0, uvD + vec2( rad * 1.8, 0.0)).rgb;
            blur += texture2D(colortex0, uvD + vec2(-rad * 1.8, 0.0)).rgb;
            blur += texture2D(colortex0, uvD + vec2(0.0,  rad * 1.4)).rgb;
            blur += texture2D(colortex0, uvD + vec2(0.0, -rad * 1.4)).rgb;
            color = mix(color, blur / 9.0, min(edgeF * 1.2, 0.85));
        }
    }
    #endif

    // Le bloom vit en quart de résolution (coin bas-gauche de colortex1) :
    // l'agrandissement bilinéaire donne un halo doux, sans crénelage.
    // Dans la brume volumétrique (colortex6.b), les halos GONFLENT :
    // la lumière des lanternes mord dans le brouillard — dark fantasy.
    vec3 bloom = texture2D(colortex1, uvD * 0.5).rgb;
    float mistGlow = texture2D(colortex6, uvD * 0.5).b;
    // (v2.2.1 : boost brume 1.6 -> 0.8, plafonné — anti-flashbang)
    color += bloom * BLOOM_STRENGTH * (1.0 + min(mistGlow, 0.75) * 0.8);

    // Bandes de lueur d'air chaud qui montent (Nether, cf. heatShimmer)
    color *= 1.0 + heatShimmer * 0.30;

    // Auto-exposition : l'oeil s'adapte (bornée pour préserver l'ambiance)
    #ifdef AUTO_EXPOSURE
        float avgLum = texture2D(colortex3, vec2(0.5, 0.5)).r;
        // Plafond bas : l'auto-exposition ne doit pas COMBATTRE la nuit
        color *= clamp(0.15 / max(avgLum, 0.004), 0.7, 1.12);
    #endif

    color *= EXPOSURE;

    #ifdef TONEMAP_AGX
    // AgX (idée IterationT, courbe adoptée par Blender) : les couleurs
    // saturées gardent leur TEINTE au lieu de blanchir — couchers roses
    // qui restent roses, torches qui restent orange
    {
        mat3 agxMat = mat3(
            0.842479062253094, 0.0423282422610123, 0.0423756549057051,
            0.0784335999999992, 0.878468636469772, 0.0784336,
            0.0792237451477643, 0.0791661274605434, 0.879142973793104);
        mat3 agxMatInv = mat3(
            1.19687900512017, -0.0528968517574562, -0.0529716355144438,
            -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
            -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
        vec3 v = agxMat * (color * 1.25);
        v = clamp(log2(max(v, vec3(1e-10))), -12.47393, 4.026069);
        v = (v + 12.47393) / (12.47393 + 4.026069);
        vec3 v2 = v * v;
        vec3 v4 = v2 * v2;
        v = 15.5 * v4 * v2 - 40.14 * v4 * v + 31.96 * v4
          - 6.868 * v2 * v + 0.4298 * v2 + 0.1191 * v - 0.00232;
        color = clamp(agxMatInv * v, 0.0, 1.0);
        // AgX sort déjà en espace écran : pas de linearToSrgb
    }
    #else
    // Tonemapping filmique (approximation ACES de Narkowicz), à moitié
    // basé sur la luminance : le par-canal pur délave les oranges intenses
    // en jaune-blanc — la version luminance garde les halos DORÉS
    vec3 tmC = clamp((color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14), 0.0, 1.0);
    float lumHDR = max(luminance(color), 1e-5);
    float tmL = clamp((lumHDR * (2.51 * lumHDR + 0.03)) / (lumHDR * (2.43 * lumHDR + 0.59) + 0.14), 0.0, 1.0);
    vec3 tmS = clamp(color * (tmL / lumHDR), 0.0, 1.0);
    color = mix(tmC, tmS, 0.5);

    color = linearToSrgb(color);
    #endif

    // Étalonnage Dark Fantasy : désaturation + contraste
    float lum = luminance(color);
    color = mix(vec3(lum), color, SATURATION);
    color = (color - 0.5) * CONTRAST + 0.5;

    // Split-toning : ombres légèrement froides (discret — trop fort, ça grise tout)
    color *= mix(vec3(0.95, 1.00, 1.06), vec3(1.0), clamp(lum * 1.5, 0.0, 1.0));

    // Noirs légèrement délavés, comme une pellicule fanée (subtil :
    // trop fort, ça aplatit les nuits)
    color = color * 0.99 + 0.004;

    // Vignettage
    color *= 1.0 - VIGNETTE_STRENGTH * smoothstep(0.1, 0.5, dot(v, v));

    // Grain de film animé
    float grain = hash12(texcoord * vec2(viewWidth, viewHeight) + fract(frameTimeCounter) * 371.0);
    color += (grain - 0.5) * GRAIN_STRENGTH;

    #ifdef LETTERBOX
        // Bandes noires format cinémascope (2.39:1)
        float aspect = viewWidth / viewHeight;
        float barH = max(0.0, (1.0 - aspect / 2.39) * 0.5);
        if (texcoord.y < barH || texcoord.y > 1.0 - barH) color = vec3(0.0);
    #endif

    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}

#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normalM;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

/* DRAWBUFFERS:01 */
    // shadowcolor0 = albedo (flux du rebond GI), shadowcolor1 = normale monde
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(normalM * 0.5 + 0.5, 1.0);
}

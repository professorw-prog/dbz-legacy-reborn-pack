#version 120

// Motion blur cinématique : flou directionnel basé sur le mouvement de la
// caméra (reprojection vers la frame précédente, comme le TAA). Subtil,
// plafonné, et jamais appliqué à la main du joueur.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

#ifdef MOTION_BLUR
    float depth = texture2D(depthtex0, texcoord).r;
    if (depth > 0.56) { // jamais la main
        vec4 ndc = vec4(texcoord, depth, 1.0) * 2.0 - 1.0;
        vec4 vp = gbufferProjectionInverse * ndc;
        vec3 playerPos = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;

        vec3 prevPlayer = playerPos;
        if (depth < 1.0) prevPlayer += cameraPosition - previousCameraPosition;

        vec4 prevClip = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevPlayer, 1.0));
        if (prevClip.w > 0.0) {
            vec2 prevUV = prevClip.xy / prevClip.w * 0.5 + 0.5;
            vec2 vel = (texcoord - prevUV) * 0.5 * MOTION_BLUR_STRENGTH;

            float vpx = length(vel * vec2(viewWidth, viewHeight));
            if (vpx > 0.5) {
                vel *= min(vpx, 20.0) / vpx; // plafonné à ~20 px
                vec3 acc = vec3(0.0);
                for (int i = 0; i < 6; i++) {
                    float o = (float(i) + 0.5) / 6.0 - 0.5;
                    acc += texture2D(colortex0, texcoord + vel * o).rgb;
                }
                color = acc / 6.0;
            }
        }
    }
#endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

#version 120

// TAA : anti-aliasing temporel.
// L'image jitterée de chaque frame est accumulée dans un historique
// (colortex5, jamais effacé) reprojeté selon le mouvement de la caméra.
// L'historique est borné par le voisinage 3x3 courant (anti-ghosting).

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

void main() {
    vec3 curr = texture2D(colortex0, texcoord).rgb;
    // Assainissement : un NaN qui entre dans l'historique TAA y reste pour
    // toujours (le clamp par voisinage ne filtre pas les NaN)
    if (!(curr.r == curr.r) || !(curr.g == curr.g) || !(curr.b == curr.b)) curr = vec3(0.0);
    curr = min(curr, vec3(60.0));
    vec3 result = curr;

#ifdef TAA
    float depth = texture2D(depthtex0, texcoord).r;

    // Position du pixel dans la frame précédente
    vec2 prevUV;
    if (depth < 0.56) {
        // La main est solidaire de la caméra : pas de reprojection
        prevUV = texcoord;
    } else {
        vec4 ndc = vec4(texcoord, depth, 1.0) * 2.0 - 1.0;
        vec4 vp = gbufferProjectionInverse * ndc;
        vec3 playerPos = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;

        // Le ciel est à l'infini : rotation seule, pas de translation
        vec3 prevPlayer = playerPos;
        if (depth < 1.0) prevPlayer += cameraPosition - previousCameraPosition;

        vec4 prevClip = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevPlayer, 1.0));
        if (prevClip.w <= 0.0) {
            prevUV = vec2(-1.0);
        } else {
            prevUV = prevClip.xy / prevClip.w * 0.5 + 0.5;
        }
    }

    if (prevUV.x > 0.0 && prevUV.x < 1.0 && prevUV.y > 0.0 && prevUV.y < 1.0) {
        vec3 hist = texture2D(colortex5, prevUV).rgb;
        // L'historique peut contenir du garbage VRAM au premier passage
        // dans une dimension (buffer jamais effacé)
        if (!(hist.r == hist.r) || !(hist.g == hist.g) || !(hist.b == hist.b)) hist = curr;
        hist = min(hist, vec3(60.0));

        // Bornage par le voisinage courant : rejette l'historique périmé
        vec2 px = 1.0 / vec2(viewWidth, viewHeight);
        vec3 mn = curr;
        vec3 mx = curr;
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                if (x == 0 && y == 0) continue;
                vec3 c = texture2D(colortex0, texcoord + vec2(float(x), float(y)) * px).rgb;
                mn = min(mn, c);
                mx = max(mx, c);
            }
        }
        hist = clamp(hist, mn, mx);

        // Mélange : fort en statique, réduit quand ça bouge à l'écran
        float vel = length((prevUV - texcoord) * vec2(viewWidth, viewHeight));
        float blendF = mix(0.90, 0.60, clamp(vel / 24.0, 0.0, 1.0));
        result = mix(curr, hist, blendF);
    }
#endif

/* DRAWBUFFERS:05 */
    gl_FragData[0] = vec4(result, 1.0);
    gl_FragData[1] = vec4(result, 1.0);
}

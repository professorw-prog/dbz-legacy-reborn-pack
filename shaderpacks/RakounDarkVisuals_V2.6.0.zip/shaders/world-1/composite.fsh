#version 120

// NETHER : l'enfer respire.
//  - brume de chaleur : l'image ondule comme au-dessus d'un brasier
//  - brouillard stratifié : lueur de lave en contrebas, cendre au plafond,
//    pulsation lente (le "souffle" du Nether)
//  - braises en suspension : deux couches parallaxe de points incandescents
//    qui montent, dérivent et vacillent — elles nourrissent le bloom
// Remplace la passe atmosphérique de l'Overworld (pas de SSR / VL / nuages).
// IMPORTANT : les const de buffers doivent être REDÉCLARÉES ici — quand un
// dossier de dimension surcharge composite.fsh, celles du fichier racine
// sont perdues pour cette dimension.

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA16F;
const bool colortex3Clear = false;
const int colortex4Format = RGBA16F;
const bool colortex4Clear = false;
const int colortex5Format = RGBA16F;
const bool colortex5Clear = false;
const int colortex6Format = RGBA16;
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int frameCounter;

varying vec2 texcoord;

// Champ de FUMÉE volumétrique (recette Kappa portée en GLSL 120) :
// dense vers le niveau des laves, s'efface en altitude, et le champ
// défile vers le BAS -> les colonnes de fumée MONTENT
float smokeField(vec3 wp, float t) {
    float alt = exp(-max(wp.y - 36.0, 0.0) * 0.030);
    if (alt < 0.01) return 0.0;
    float n = valueNoise(wp.xz * 0.055 + vec2(t * 0.35, wp.y * 0.060 - t * 0.50)) * 0.62
            + valueNoise(wp.xz * 0.150 + vec2(-t * 0.20, wp.y * 0.130 - t * 1.05)) * 0.38;
    return clamp((n - 0.46) * 2.4, 0.0, 1.0) * alt;
}

// Une couche de braises : cellules 3D, une braise par cellule "élue",
// qui monte lentement, dérive et vacille
float emberLayer(vec3 wp, float t) {
    vec3 p = wp / 2.5;
    p.y -= t * 0.55;                     // les braises montent
    vec3 cell = floor(p);
    vec3 f = fract(p) - 0.5;
    float h = hash12(cell.xz + cell.y * 31.7);
    if (h < 0.94) return 0.0;
    vec3 off = vec3(hash12(cell.xy + 3.1), hash12(cell.yz + 7.7), hash12(cell.zx + 9.3)) - 0.5;
    off.x += sin(t * 1.1 + h * 40.0) * 0.18;   // dérive latérale
    float d = length(f - off * 0.55);
    float flicker = 0.45 + 0.55 * (0.5 + 0.5 * sin(t * (2.0 + h * 4.0) + h * 90.0));
    return max(0.0, 1.0 - d * 9.0) * flicker;
}

void main() {
    // NB : la brume de chaleur est désormais appliquée dans final.fsh,
    // APRÈS le TAA (marqueur colortex6.a) — ici elle smearait le basalte
    vec3 color = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;

    vec4 ndc = vec4(texcoord, depth, 1.0) * 2.0 - 1.0;
    vec4 vp = gbufferProjectionInverse * ndc;
    vec3 playerPos = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;
    float dist = length(playerPos);
    vec3 dirW = playerPos / max(dist, 1e-4);
    if (depth >= 1.0) dist = 300.0; // le "ciel" du Nether = brouillard plein

    // Brouillard stratifié : la lave irradie d'en bas, la cendre pèse en haut
    float pulse = 0.92 + 0.08 * sin(frameTimeCounter * 0.6);
    float sampleY = cameraPosition.y + dirW.y * min(dist, 48.0);
    float lavaGlow = smoothstep(60.0, 30.0, sampleY);   // fort près du niveau de lave
    float ashHigh  = smoothstep(75.0, 110.0, sampleY);  // sombre vers le plafond
    vec3 fogCol = vec3(0.060, 0.014, 0.006);
    fogCol = mix(fogCol, vec3(0.110, 0.028, 0.008), lavaGlow);
    fogCol = mix(fogCol, vec3(0.028, 0.009, 0.005), ashHigh);
    fogCol *= pulse;

    // Le fog ne peut JAMAIS effacer totalement la scène (garde-fou : même
    // avec une profondeur cassée, les silhouettes restent diagnosticables)
    float f = min(1.0 - exp(-dist * 0.014 * FOG_DENSITY), 0.9);
    if (depth >= 1.0) f = 1.0; // seul le vrai "ciel" est plein fog
    color = mix(color, fogCol, f);

    // === FUMÉE VOLUMÉTRIQUE (à la Kappa) : des colonnes montent des
    // laves, denses en contrebas, éclairées orange par la fournaise —
    // marchées le long du rayon avec vraie transmittance ===
    {
        float T = 1.0;
        vec3 scat = vec3(0.0);
        float mMax = min(dist, 64.0);
        float stepLen = mMax / 8.0;
        float dith = fract(hash12(gl_FragCoord.xy)
                + float(frameCounter - (frameCounter / 64) * 64) * 0.6180339887);
        for (int i = 0; i < 8; i++) {
            if (T < 0.05) break;
            float tt = (float(i) + dith) / 8.0 * mMax;
            vec3 wp = cameraPosition + dirW * tt;
            float d = smokeField(wp, frameTimeCounter);
            if (d < 1e-3) continue;
            float a = d * 0.09 * stepLen;
            // Plus la volute est basse, plus la fournaise l'embrase
            float low = smoothstep(70.0, 35.0, wp.y);
            vec3 smokeCol = mix(vec3(0.040, 0.015, 0.009), vec3(0.150, 0.048, 0.014), low);
            scat += smokeCol * (1.0 - exp(-a)) * T;
            T *= exp(-a);
        }
        color = color * T + scat;
    }

    // Braises en suspension : deux plans de parallaxe, cachés par la géométrie
    vec3 emberCol = vec3(1.0, 0.42, 0.10);
    float t = frameTimeCounter;
    if (dist > 5.0) {
        vec3 wp1 = cameraPosition + dirW * 5.0;
        color += emberCol * emberLayer(wp1, t) * 0.9;
    }
    if (dist > 12.0) {
        vec3 wp2 = cameraPosition + dirW * 12.0;
        color += emberCol * emberLayer(wp2 + 17.3, t) * 0.45; // plus loin : plus faible
    }

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

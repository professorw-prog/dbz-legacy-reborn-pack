#version 120

// Bloom, passe 1 : extraction des hautes lumières + flou horizontal.
// (Lit l'image stabilisée par le TAA : les halos ne scintillent pas.)

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex6;
uniform float viewWidth;
uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;

varying vec2 texcoord;

// Facteur nuit (0 = plein jour, 1 = nuit noire), calculé une fois dans main
float gNight = 0.0;

vec3 brightSample(vec2 uv) {
    vec3 c = texture2D(colortex0, uv).rgb;
    // Seuil haut LE JOUR : seuls les émissifs (flammes, lave, astres)
    // déclenchent le bloom — pas le sol éclairé, sinon voile laiteux.
    // LA NUIT : seuil abaissé + boost des tons CHAUDS — les halos dorés
    // des lanternes débordent et réchauffent le village ; la lune et les
    // étoiles (froides) restent sobres.
    float bl = luminance(c);
    // Plafond : le soleil (luminance énorme) faisait exploser le halo au
    // point de "manger" les bâtiments — les lanternes, elles, sont sous le cap
    float cap = min(bl, 4.0) / max(bl, 1e-4);

    float warm = clamp((c.r - c.b) * 2.5, 0.0, 1.0);
    float lo = mix(0.6, 0.24, gNight);
    float hi = mix(1.5, 0.95, gNight);
    float boost = 1.0 + gNight * (0.35 + 0.85 * warm);
    vec3 tint = mix(vec3(1.0), vec3(1.08, 0.97, 0.85), gNight * warm);

    return c * tint * (smoothstep(lo, hi, bl) * cap * boost);
}

void main() {
    // Bloom en QUART DE RÉSOLUTION (coin bas-gauche de colortex1) :
    // halo 2x plus large pour le même nombre de prises, ré-agrandi en
    // bilinéaire dans final -> plus AUCUN crénelage, et 4x moins cher.
    if (texcoord.x > 0.502 || texcoord.y > 0.502) {
/* DRAWBUFFERS:1 */
        gl_FragData[0] = vec4(0.0);
        return;
    }

    float sunH = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition).y;
    gNight = 1.0 - smoothstep(0.0, 0.15, sunH);
    // Nether / End (marqueur colortex6.a < 0.5) : PAS de seuil nocturne
    // abaissé — le facteur nuit y est permanent (pas de soleil) et le
    // basalte gris clair passait sous le seuil -> marbrures blanches
    // floues sur toute sa texture. Seuls les vrais émissifs bloomeront.
    if (texture2D(colortex6, vec2(0.25, 0.25)).a < 0.5) gNight = 0.0;

    vec2 fullUV = min(texcoord * 2.0, vec2(0.9995));
    // Prises resserrées (2 px écran) : le bilinéaire comble les trous,
    // le sous-échantillonnage ne laisse plus de bandes
    vec2 px = vec2(2.0 / viewWidth, 0.0);

    vec3 bloom = brightSample(fullUV) * 0.227;
    bloom += (brightSample(fullUV + px)       + brightSample(fullUV - px))       * 0.194;
    bloom += (brightSample(fullUV + px * 2.0) + brightSample(fullUV - px * 2.0)) * 0.121;
    bloom += (brightSample(fullUV + px * 3.0) + brightSample(fullUV - px * 3.0)) * 0.054;
    bloom += (brightSample(fullUV + px * 4.0) + brightSample(fullUV - px * 4.0)) * 0.016;

/* DRAWBUFFERS:1 */
    gl_FragData[0] = vec4(bloom, 1.0);
}

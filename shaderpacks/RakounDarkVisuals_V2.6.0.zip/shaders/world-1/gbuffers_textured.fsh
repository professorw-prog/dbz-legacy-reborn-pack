#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;

    vec3 albedo = srgbToLinear(tex.rgb * glcolor.rgb);

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    // Éclairage simplifié (pas d'ombres portées) : lightmap uniquement
    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);

    vec3 light = getShadowLightColor(sunH, rainStrength) * skyExposure * 0.5
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y)
               + getTorchLight(lmcoord.x) * torchFlicker(frameTimeCounter)
               + CAVE_AMBIENT
               + srgbToLinear(fogColor) * 0.055 * (1.0 - lmcoord.y);

    vec3 color = albedo * light;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, tex.a * glcolor.a);
}

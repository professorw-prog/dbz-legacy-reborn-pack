#version 120

// Particules, main du joueur (via fallback), objets texturés simples.

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
}

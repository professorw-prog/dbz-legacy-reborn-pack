#version 120

// gbuffers_basic — le LOD du mod Rakoun Dark Horizons (terrain lointain
// en POSITION_COLOR). La couleur du vertex est un ALBEDO (lambert du
// relief déjà baké) : on l'éclaire avec la MÊME recette que le terrain
// réel, version plein ciel — sinon le lointain sort pâle et délavé
// (couleur brute broyée par le tonemap) et jure avec le monde gradé.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;

varying vec4 glcolor;

void main() {
    float sunH = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition).y;

    vec3 albedo = srgbToLinear(glcolor.rgb);
    // plein ciel : lumière directe (l'ombrage du relief vit dans l'albedo)
    // + ambiance du ciel — jour, nuit, pluie et couchers suivent tout seuls
    vec3 light = getShadowLightColor(sunH, rainStrength) * 0.80
               + getSkyAmbientColor(sunH, rainStrength)
               + CAVE_AMBIENT;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(albedo * light, glcolor.a);
}

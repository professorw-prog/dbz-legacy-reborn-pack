#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;

    // === SPLASH DE PLUIE VANILLA : cube bleu opaque -> à la poubelle ===
    // Trois conditions cumulées, pour ne JAMAIS toucher les autres
    // particules (fumée, feu, redstone, portail...) :
    //   1. la région d'atlas des sprites splash (relevée au debug UV)
    //   2. la texture est bleutée/blanche (le splash l'est, la fumée non)
    //   3. il pleut (par temps clair, aucune particule ne peut disparaître)
    bool isRainSplash = texcoord.x > SPLASH_UV_UMIN
                     && texcoord.y > SPLASH_UV_VMIN
                     && tex.b >= tex.r * 0.98
                     && rainStrength > 0.01;

    #if DEBUG_PARTICLE_UV == 1
        // relevé : R = u, V = v
        gl_FragData[0] = vec4(texcoord.x, texcoord.y, 0.25, 1.0);
        return;
    #elif DEBUG_PARTICLE_UV == 2
        // vérification : ROUGE = ce que le kill supprimerait, VERT = gardé
        gl_FragData[0] = isRainSplash ? vec4(1.0, 0.0, 0.0, 1.0)
                                      : vec4(0.0, 1.0, 0.0, 1.0);
        return;
    #endif

    #ifdef KILL_VANILLA_RAIN_SPLASH
        if (isRainSplash) discard;
    #endif

    vec3 albedo = srgbToLinear(tex.rgb * glcolor.rgb);

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    // Éclairage simplifié (pas d'ombres portées) : lightmap uniquement
    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);

    vec3 light = getShadowLightColor(sunH, rainStrength) * skyExposure * 0.5
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y)
               + getTorchLight(lmcoord.x) * torchFlicker(frameTimeCounter)
               + CAVE_AMBIENT
               + srgbToLinear(fogColor) * 0.055 * (1.0 - lmcoord.y);

    vec3 color = albedo * light;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, tex.a * glcolor.a);
}

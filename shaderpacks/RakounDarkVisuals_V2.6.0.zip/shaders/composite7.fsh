#version 120

// FXAA léger : anti-aliasing de secours quand le TAA est désactivé.
// (Désactivé par défaut — le TAA fait mieux.)

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

#ifdef FXAA
float lumaTM(vec3 c) {
    c = c / (1.0 + c);
    return sqrt(luminance(c));
}
#endif

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

#ifdef FXAA
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);

    float lC  = lumaTM(color);
    float lNW = lumaTM(texture2D(colortex0, texcoord + vec2(-px.x, -px.y)).rgb);
    float lNE = lumaTM(texture2D(colortex0, texcoord + vec2( px.x, -px.y)).rgb);
    float lSW = lumaTM(texture2D(colortex0, texcoord + vec2(-px.x,  px.y)).rgb);
    float lSE = lumaTM(texture2D(colortex0, texcoord + vec2( px.x,  px.y)).rgb);

    float lMin = min(lC, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lC, max(max(lNW, lNE), max(lSW, lSE)));

    if (lMax - lMin > max(0.04, lMax * 0.12)) {
        vec2 dir;
        dir.x = -((lNW + lNE) - (lSW + lSE));
        dir.y =  ((lNW + lSW) - (lNE + lSE));

        float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
        float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
        dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * px;

        vec3 rgbA = 0.5 * (texture2D(colortex0, texcoord + dir * (1.0 / 3.0 - 0.5)).rgb
                         + texture2D(colortex0, texcoord + dir * (2.0 / 3.0 - 0.5)).rgb);
        vec3 rgbB = rgbA * 0.5 + 0.25 * (texture2D(colortex0, texcoord + dir * -0.5).rgb
                                       + texture2D(colortex0, texcoord + dir *  0.5).rgb);

        float lB = lumaTM(rgbB);
        if (lB < lMin || lB > lMax) color = rgbA;
        else                        color = rgbB;
    }
#endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

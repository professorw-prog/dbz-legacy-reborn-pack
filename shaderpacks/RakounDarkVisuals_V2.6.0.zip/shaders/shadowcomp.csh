#version 430 compatibility

// FLOOD-FILL de lumière colorée (technique ACL, apprise de
// FantasyShader/Complementary) : chaque frame, chaque voxel devient la
// moyenne de ses 6 voisins (la lumière se PROPAGE), les émetteurs
// réinjectent leur couleur, les blocs solides l'éteignent, et les
// VITRAUX multiplient la lumière qui les traverse par leur teinte.
// Ping-pong entre deux volumes selon la parité de la frame — le volume
// suit la caméra (décalage par le delta de position).

layout (local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 8, 16);

#if defined IRIS_FEATURE_COMPUTE_SHADERS && defined IRIS_FEATURE_CUSTOM_IMAGES

const ivec3 voxelVolumeSize = ivec3(128, 64, 128);

uniform int frameCounter;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

uniform sampler3D voxel_sampler;   // r8 float : id/255
uniform sampler3D floodfill_sampler;
uniform sampler3D floodfill_sampler_copy;
writeonly uniform image3D floodfill_img;
writeonly uniform image3D floodfill_img_copy;

// Couleurs des émetteurs (IDs cohérents avec shadow.vsh). Des valeurs
// hautes = la couleur porte plus loin et domine ses voisines.
vec3 emitterColor(uint id) {
    if (id ==  2u) return vec3(2.05, 0.83, 0.27) * 3.8;  // feu doré
    if (id ==  3u) return vec3(0.30, 2.00, 2.20);        // âmes
    if (id ==  4u) return vec3(5.00, 0.10, 0.10) * 0.30; // redstone
    if (id ==  5u) return vec3(1.00, 1.25, 1.50) * 3.4;  // sea lantern
    if (id ==  6u) return vec3(0.65, 0.30, 0.90) * 2.2;  // améthyste
    if (id ==  7u) return vec3(1.00, 1.00, 1.00) * 4.0;  // end rod
    if (id ==  8u) return vec3(1.70, 0.90, 0.40) * 4.0;  // glowstone
    if (id ==  9u) return vec3(3.00, 0.90, 0.20) * 3.0;  // shroomlight
    if (id == 10u) return vec3(1.10, 0.85, 0.35) * 5.0;  // froglight ocre
    if (id == 11u) return vec3(0.60, 1.30, 0.60) * 4.5;  // froglight vert
    if (id == 12u) return vec3(1.10, 0.50, 0.90) * 4.5;  // froglight nacré
    if (id == 13u) return vec3(3.40, 0.90, 0.20) * 4.0;  // lave
    if (id == 14u) return vec3(2.20, 0.35, 0.30) * 1.5;  // portail (sang)
    return vec3(0.0);
}

// Teintes des vitraux (200 + ordre vanilla)
vec3 tintColor(uint id) {
    uint i = id - 200u;
    if (i ==  0u) return vec3(1.0);              // blanc
    if (i ==  1u) return vec3(1.0, 0.35, 0.1);   // orange
    if (i ==  2u) return vec3(1.0, 0.1, 1.0);    // magenta
    if (i ==  3u) return vec3(0.5, 0.65, 1.0);   // bleu clair
    if (i ==  4u) return vec3(1.0, 1.0, 0.1);    // jaune
    if (i ==  5u) return vec3(0.1, 1.0, 0.1);    // vert clair
    if (i ==  6u) return vec3(1.0, 0.4, 1.0);    // rose
    if (i ==  7u) return vec3(0.8);              // gris
    if (i ==  8u) return vec3(0.9);              // gris clair
    if (i ==  9u) return vec3(0.3, 0.8, 1.0);    // cyan
    if (i == 10u) return vec3(0.7, 0.3, 1.0);    // violet
    if (i == 11u) return vec3(0.1, 0.15, 1.0);   // bleu
    if (i == 12u) return vec3(1.0, 0.75, 0.5);   // brun
    if (i == 13u) return vec3(0.3, 1.0, 0.3);    // vert
    if (i == 14u) return vec3(1.0, 0.1, 0.1);    // rouge
    return vec3(0.6);                            // noir : assombrit
}

vec4 lightAt(sampler3D s, ivec3 p) {
    return texelFetch(s, clamp(p, ivec3(0), voxelVolumeSize - 1), 0);
}

vec4 lightAverage(sampler3D s, ivec3 p) {
    vec4 l = lightAt(s, p)
           + lightAt(s, p + ivec3( 1, 0, 0)) + lightAt(s, p + ivec3(-1, 0, 0))
           + lightAt(s, p + ivec3( 0, 1, 0)) + lightAt(s, p + ivec3( 0,-1, 0))
           + lightAt(s, p + ivec3( 0, 0, 1)) + lightAt(s, p + ivec3( 0, 0,-1));
    // légèrement > 7 : la lumière s'éteint au lieu de porter à l'infini
    // (7.08 : diffusion LONGUE façon Eclipse — 7.2 mourait en 1-2 blocs)
    return l / 7.08;
}

void main() {
    ivec3 pos = ivec3(gl_GlobalInvocationID);
    // le volume suit la caméra : on relit la frame précédente décalée
    ivec3 prevPos = ivec3(vec3(pos)
            - (floor(previousCameraPosition) - floor(cameraPosition)));

    uint voxel = uint(texelFetch(voxel_sampler, pos, 0).r * 255.0 + 0.5);
    bool even = (frameCounter & 1) == 0;

    if (voxel == 1u) {
        // occulteur : la lumière ne traverse pas
        if (even) imageStore(floodfill_img_copy, pos, vec4(0.0));
        else      imageStore(floodfill_img, pos, vec4(0.0));
        return;
    }

    vec4 light = even ? lightAverage(floodfill_sampler, prevPos)
                      : lightAverage(floodfill_sampler_copy, prevPos);

    if (voxel >= 200u) {
        light.rgb *= tintColor(voxel);           // vitrail : filtre coloré
    } else if (voxel >= 2u) {
        vec3 c = emitterColor(voxel);
        light.rgb = max(light.rgb, c * c);       // émetteur : réinjection
    }

    if (even) imageStore(floodfill_img_copy, pos, light);
    else      imageStore(floodfill_img, pos, light);
}

#else
void main() {}
#endif

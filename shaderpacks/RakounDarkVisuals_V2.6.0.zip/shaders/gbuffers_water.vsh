#version 120

// Translucides : eau (vagues déplacées), verre (reflets), glace...

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"
#include "/lib/common.glsl"
#include "/lib/water.glsl"

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;
varying float isWater;
varying float glassType; // 0 = non, 1 = verre clair, 2 = verre teinté
varying float upFace;
varying vec3 worldPos;
varying vec3 viewVec;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);

    isWater = float(mc_Entity.x == 10008.0);
    glassType = 0.0;
    if (mc_Entity.x == 10012.0) glassType = 1.0;
    if (mc_Entity.x == 10013.0) glassType = 2.0;
    if (mc_Entity.x >= 11020.0 && mc_Entity.x <= 11035.0) glassType = 2.0;
    if (mc_Entity.x == 10014.0) glassType = 3.0; // portail du Nether

    upFace   = clamp(gl_Normal.y, 0.0, 1.0);
    worldPos = playerPos.xyz + cameraPosition;

    // Déplacement vertical de la surface : l'eau bouge vraiment
    if (isWater > 0.5) {
        playerPos.y += waveHeight(worldPos.xz, frameTimeCounter) * WAVE_AMPLITUDE * upFace;
        viewPos = gbufferModelView * playerPos;
    }

    gl_Position = gl_ProjectionMatrix * viewPos;
    gl_Position.xy += taaJitter() * gl_Position.w;
    viewVec = viewPos.xyz;

    vec4 shadowSample = playerPos;
    shadowSample.xyz += (mat3(gbufferModelViewInverse) * normalV) * 0.06;
    shadowPos = shadowProjection * (shadowModelView * shadowSample);
    vertDist = length(playerPos.xyz);
}

#version 120

// Profondeur de champ cinématique (optionnelle, pour les screenshots).
// La mise au point suit le centre de l'écran, lissée par OptiFine/Iris.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

const float centerDepthHalflife = 1.5;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform float centerDepthSmooth;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

#ifdef DOF
float linDist(float d) {
    float m22 = gbufferProjection[2].z;
    float m32 = gbufferProjection[3].z;
    return m32 / (d * 2.0 - 1.0 + m22);
}
#endif

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

#ifdef DOF
    float d = texture2D(depthtex0, texcoord).r;
    // On ne floute pas la main (elle occupe la zone de profondeur proche)
    if (d > 0.56) {
        float zs = abs(linDist(d));
        float zf = abs(linDist(centerDepthSmooth));
        float coc = clamp(abs(zs - zf) / max(zf, 1.0) * 1.2, 0.0, 1.0);
        coc *= smoothstep(0.03, 0.18, coc); // zone de netteté préservée

        float radius = coc * 6.0 * DOF_STRENGTH * (viewHeight / 1080.0);
        if (radius > 0.5) {
            vec2 px = radius / vec2(viewWidth, viewHeight);
            vec3 acc = color;
            // Anneau de 8 échantillons + 4 à mi-rayon
            acc += texture2D(colortex0, texcoord + vec2( 1.00,  0.00) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2(-1.00,  0.00) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.00,  1.00) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.00, -1.00) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.71,  0.71) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2(-0.71,  0.71) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.71, -0.71) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2(-0.71, -0.71) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.35,  0.35) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2(-0.35,  0.35) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2( 0.35, -0.35) * px).rgb;
            acc += texture2D(colortex0, texcoord + vec2(-0.35, -0.35) * px).rgb;
            color = acc / 13.0;
        }
    }
#endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

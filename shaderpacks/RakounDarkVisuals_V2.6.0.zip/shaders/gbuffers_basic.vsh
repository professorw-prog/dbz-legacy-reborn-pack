#version 120

// gbuffers_basic — géométrie POSITION_COLOR. Chez nous, c'est le
// Distant Horizons maison (mod Rakoun Dark Horizons) qui passe par là.

varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    glcolor = gl_Color;
}

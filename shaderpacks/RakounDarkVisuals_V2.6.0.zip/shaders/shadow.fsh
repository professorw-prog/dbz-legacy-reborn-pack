#version 430 compatibility

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 normalM;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

/* DRAWBUFFERS:01 */
    // shadowcolor0 = albedo (flux du rebond GI ; sert AUSSI de teinte au
    // soleil coloré : un vitrail y écrit sa couleur) ; shadowcolor1 = normale
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(normalM * 0.5 + 0.5, 1.0);
}

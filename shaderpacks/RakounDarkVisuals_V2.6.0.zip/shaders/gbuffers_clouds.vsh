#version 120

// Nuages vanilla, ré-éclairés aux couleurs du shader.

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
}

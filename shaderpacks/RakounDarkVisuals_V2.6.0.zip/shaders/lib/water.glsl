#ifndef WATER_GLSL
#define WATER_GLSL

// Vagues procédurales de l'eau — partagées entre gbuffers_water.vsh
// (déplacement des sommets) et .fsh (normales), pour rester cohérentes.
// Nécessite lib/common.glsl (hash12).
// p = position monde xz, t = frameTimeCounter. Retour dans [-1, 1].

float waveHeight(vec2 p, float t) {
    // Des SINUS directionnels (vraies vagues structurées) dont les phases
    // sont déformées par deux champs de bruit indépendants : la répétition
    // est cassée SANS créer de taches. Jamais de bruit brut en hauteur —
    // le bruit fait du camouflage, pas des vagues.
    float w1 = valueNoise(p * 0.11 + t * 0.020) * 5.0;
    float w2 = valueNoise(p * 0.23 + 7.7 - t * 0.015) * 4.0;

    float h = sin(p.x * 0.7 + w1 + t * 1.4) * 0.40
            + sin(p.y * 0.9 + p.x * 0.3 - w1 + t * 1.1) * 0.30
            + sin((p.x + p.y) * 1.7 + w2 + t * 2.3) * 0.20
            + sin(p.x * 3.1 - p.y * 2.3 - w2 + t * 3.4) * 0.10;
    return h;
}

// Amplitude réelle du déplacement vertical (en blocs)
// (réduite de 25% suite aux retours beta : l'eau était "gélatineuse")
const float WAVE_AMPLITUDE = 0.09;

// Normale monde de la surface : pentes des grandes vagues exagérées
// + micro-vaguelettes (uniquement dans la normale, pas le déplacement)
vec3 waveNormalWorld(vec2 p, float t) {
    const float e = 0.12;
    float dx = waveHeight(p + vec2(e, 0.0), t) - waveHeight(p - vec2(e, 0.0), t);
    float dz = waveHeight(p + vec2(0.0, e), t) - waveHeight(p - vec2(0.0, e), t);

    // Clapotis haute fréquence, phases décalées par du bruit statique
    // pour ne jamais retomber sur le même motif
    float w2 = valueNoise(p * 0.6) * 6.283;
    dx += sin(p.x * 5.3 + p.y * 2.1 + w2 + t * 3.8) * 0.10;
    dz += sin(p.y * 6.1 - p.x * 1.7 - w2 + t * 4.3) * 0.10;

    return normalize(vec3(-dx * 1.0, 1.0, -dz * 1.0));
}

// Anneaux d'ondulation des gouttes de pluie : deux grilles de cellules à
// échelles différentes. À chaque cycle, une cellule a une CHANCE de recevoir
// une goutte, à une position RE-TIRÉE au hasard — pas de motif répétitif.
// Retourne le GRADIENT de hauteur (perturbation de normale).
// ============================================================
//  IMPACTS DE PLUIE PROCÉDURAUX (v2.6)
//  Une goutte qui tombe dans une FLAQUE propage une onde de surface :
//  l'anneau s'étend, l'énergie voyage. Une goutte sur de la PIERRE
//  MOUILLÉE ne propage rien : elle s'écrase et éclabousse. D'où deux
//  régimes, interpolés par le masque de flaque (paramètre `puddle`).
//  Une SEULE grille hashée alimente les 3 composants.
//  Retour : xy = gradient de normale (anneau), z = couronne, w = éclat sec
// ============================================================
vec4 rainSplash(vec2 p, float t, float puddle) {
    vec2 grad = vec2(0.0);
    float crown = 0.0;
    float spark = 0.0;

    for (int L = 0; L < 2; L++) {
        // Grille FINE : cellule ~0.38 bloc -> des dizaines d'impacts à
        // l'écran, pas six.
        float sc = ((L == 0) ? 2.6 : 4.3) * RAIN_SPLASH_DENSITY;
        vec2 pp = p * sc + float(L) * vec2(6.37, 11.71);
        vec2 id = floor(pp);
        vec2 f = fract(pp) - 0.5;
        float rnd = hash12(id + float(L) * 31.7);

        // ~0.3 s de vie (cycle 0.24-0.33 s)
        float cycT = t * (3.0 + 1.2 * rnd) + rnd * 7.0;
        float cyc = floor(cycT);
        float ph = fract(cycT);

        if (hash12(id + vec2(cyc * 0.618, float(L) * 13.7)) < 0.75) {
            // centre CONFINÉ dans la cellule : deux impacts voisins ne
            // peuvent plus se toucher (fini les formes en 8)
            vec2 c = (vec2(hash12(id + cyc + 3.3), hash12(id + cyc + 9.9)) - 0.5) * 0.32;
            vec2 dv = f - c;
            float d = length(dv) + 1e-4;

            // === ANNEAU (le composant PRINCIPAL) ===
            // Un cercle CREUX qui naît, s'étend et meurt. Rayon max
            // 0.13 cellule ~ 5 cm : il reste chez lui.
            // Le gradient est la DÉRIVÉE d'une gaussienne étroite : un
            // vrai bourrelet (pente montante puis descendante), pas un
            // disque plein.
            // rayon 0.19 cellule (~7 cm) : le centre est confiné à ±0.16,
            // donc 0.16 + 0.19 = 0.35 < 0.5 -> l'anneau reste dans SA
            // cellule, aucune fusion possible avec la voisine.
            float r = ph * 0.19 * RAIN_SPLASH_SIZE;
            float x = (d - r) * 75.0;                   // paroi douce (~3 cm)
            float g = -2.0 * x * exp(-x * x * 0.35);    // profil d'onde
            grad += (dv / d) * g * (1.0 - ph) * (1.0 - ph) * puddle;

            // === COURONNE : un accent MINUSCULE et TRÈS bref ===
            // (les ~15 % du début de vie ; le rebond de la goutte)
            crown += exp(-d * d * 2600.0) * exp(-ph * 26.0);

            // === ÉCLABOUSSURE SÈCHE (hors flaque) ===
            #ifdef RAIN_SPLASH_SPARKLE
                spark += exp(-d * d * 900.0) * exp(-ph * 14.0) * (1.0 - puddle);
            #endif
        }
    }
    return vec4(grad, crown, spark);
}

vec2 rainRippleGrad(vec2 p, float t) {
    vec2 g = vec2(0.0);
    for (int L = 0; L < 2; L++) {
        float sc = (L == 0) ? 1.3 : 2.3;
        vec2 pp = p * sc + float(L) * vec2(6.37, 11.71);
        vec2 id = floor(pp);
        vec2 f = fract(pp) - 0.5;
        float rnd = hash12(id + float(L) * 31.7);

        // cycle propre à la cellule ; nouvelle goutte à chaque cycle
        // (rapide : un anneau réel s'étend en ~0.6 s)
        float cycT = t * (1.3 + 0.9 * rnd) + rnd * 7.0;
        float cyc = floor(cycT);
        float ph = fract(cycT);

        // ~70% des cycles produisent une goutte
        if (hash12(id + vec2(cyc * 0.618, float(L) * 13.7)) < 0.7) {
            vec2 c = (vec2(hash12(id + cyc + 3.3), hash12(id + cyc + 9.9)) - 0.5) * 0.6;
            vec2 dv = f - c;
            float d = length(dv) + 1e-4;
            float r = ph * 0.45;
            float x = (d - r) * 40.0;
            float env = exp(-abs(x) * 0.4) * (1.0 - ph) * (1.0 - ph);
            g += cos(x) * env * (dv / d);
        }
    }
    return g;
}

// Caustiques : interférences lumineuses dansantes sur le fond
float caustic(vec2 p, float t) {
    float c = sin(p.x * 1.7 + t * 1.3)
            + sin(p.y * 2.3 - t * 1.1)
            + sin((p.x + p.y) * 1.3 + t * 1.7);
    return pow(clamp(1.0 - abs(c) * 0.4, 0.0, 1.0), 3.0);
}

#endif

#ifndef LIGHTING_GLSL
#define LIGHTING_GLSL

// Éclairage Dark Fantasy — couleurs en espace linéaire.
// Inclure APRÈS lib/settings.glsl et lib/common.glsl.
// sunH = hauteur normalisée du soleil dans le monde (sunDir.y).

const vec3 CAVE_AMBIENT = vec3(0.0045, 0.0052, 0.0075);
const vec3 FIRE_COLOR   = vec3(1.00, 0.48, 0.12); // or profond, façon lanterne

float dayFactor(float sunH) {
    return smoothstep(-0.05, 0.25, sunH);
}

float duskFactor(float sunH) {
    return 1.0 - smoothstep(0.05, 0.35, abs(sunH));
}

// Couleur de la lumière directionnelle (soleil le jour, lune la nuit)
vec3 getShadowLightColor(float sunH, float rain) {
    float day  = dayFactor(sunH);
    float dusk = duskFactor(sunH);
    vec3 sun  = mix(vec3(0.85, 0.78, 0.62), vec3(0.55, 0.18, 0.08), dusk);
    vec3 moon = vec3(0.018, 0.026, 0.055) * NIGHT_BRIGHTNESS;
    // On garde un peu de directionnel sous la pluie : c'est lui qui donne le relief
    return mix(moon, sun, day) * (1.0 - 0.65 * rain);
}

// Lumière ambiante du ciel (modulée par lightmap.y)
vec3 getSkyAmbientColor(float sunH, float rain) {
    float day  = dayFactor(sunH);
    float dusk = duskFactor(sunH);
    vec3 dayA   = mix(vec3(0.100, 0.130, 0.190), vec3(0.110, 0.070, 0.060), dusk * 0.7);
    vec3 nightA = vec3(0.006, 0.009, 0.019) * NIGHT_BRIGHTNESS;
    vec3 amb = mix(nightA, dayA, day);
    // Pluie : gris désaturé mais PAS plus lumineux (sinon rendu laiteux)
    return mix(amb, vec3(luminance(amb)) * 0.9, rain * 0.5);
}

// Vacillement des flammes : plusieurs sinus désynchronisés
float torchFlicker(float t) {
#ifdef TORCH_FLICKER
    float n = sin(t * 11.0) * 0.45
            + sin(t * 27.3 + 1.7) * 0.35
            + sin(t * 51.7 + 4.2) * 0.20;
    return 1.0 + n * 0.10;
#else
    return 1.0;
#endif
}

// Lumière des torches : de GRANDES flaques dorées généreuses — la
// portée moyenne est ce qui fait le "woaw" des intérieurs Kappa.
// Courbe relevée sur toute la plage (« abuse un peu nos lights ») :
// pic ~3.2, mi-distance ~2x plus lumineuse qu'avant.
float getTorchIntensity(float t) {
    return pow(t, 1.5) * (0.75 + 2.45 * pow(t, 2.5));
}

vec3 getTorchLight(float t) {
    return FIRE_COLOR * getTorchIntensity(t);
}

// Lumière dynamique de l'objet tenu en main (torche, lanterne...)
// heldValue = valeur lumineuse 0..15, dist = distance au fragment
vec3 getHeldLight(float dist, float heldValue, float flick) {
    float falloff = clamp(1.0 - dist / max(heldValue * 0.85, 0.001), 0.0, 1.0);
    return FIRE_COLOR * (falloff * falloff * heldValue / 15.0) * 1.6 * flick;
}

#endif

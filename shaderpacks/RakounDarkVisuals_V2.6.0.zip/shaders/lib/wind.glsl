#ifndef WIND_GLSL
#define WIND_GLSL

// ====================================================================
//  VENT 2.0 : UN SEUL vent pour tout le monde — l'herbe, les feuilles,
//  les cultures ET la pluie lisent le même champ de bourrasques : une
//  rafale TRAVERSE le paysage et tout ce qu'elle touche plie ensemble,
//  puis le calme revient. Tempête quand il pleut.
//  Autonome (bruit local) : inclus depuis des .vsh sans common.glsl.
// ====================================================================

float windHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float windNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = windHash(i);
    float b = windHash(i + vec2(1.0, 0.0));
    float c = windHash(i + vec2(0.0, 1.0));
    float d = windHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Direction du vent (unitaire, plan xz) : un cap dominant qui DÉRIVE
// lentement — jamais figé, jamais erratique
vec2 windDirection(float t) {
    float a = 2.4 + 0.5 * sin(t * 0.013) + 0.25 * sin(t * 0.047);
    return vec2(cos(a), sin(a));
}

// Force locale du vent en ce point du monde, ~[0.3 .. 1.8] (jusqu'à ~3
// sous l'orage) : houle de fond + BOURRASQUES nettes qui balayent la
// carte dans le sens du vent
float windGust(vec2 xz, float t, float rain) {
    vec2 wd = windDirection(t);
    // le champ de rafales DÉFILE dans le sens du vent (plus vite sous l'orage)
    vec2 p = (xz - wd * t * (5.5 + rain * 9.0)) * 0.045;
    float n = windNoise(p) * 0.65 + windNoise(p * 2.7 + 31.4) * 0.35;
    // crêtes marquées : des accalmies, puis des rafales qui claquent
    float gust = smoothstep(0.35, 0.85, n);
    return (0.30 + 0.55 * n + 0.90 * gust * gust) * (1.0 + rain * 1.1);
}

#endif

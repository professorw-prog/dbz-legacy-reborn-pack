#ifndef JITTER_GLSL
#define JITTER_GLSL

// Jitter sous-pixel du TAA (séquence de Halton 2,3 sur 8 frames).
// À inclure APRÈS lib/settings.glsl, dans les VERTEX shaders gbuffers,
// puis appliquer après le calcul final de gl_Position :
//     gl_Position.xy += taaJitter() * gl_Position.w;
// La passe shadow ne doit PAS être jitterée.

#ifdef TAA
uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;

vec2 taaJitter() {
    int i = int(mod(float(frameCounter), 8.0));
    vec2 j;
    if      (i == 0) j = vec2(0.500, 0.333);
    else if (i == 1) j = vec2(0.250, 0.667);
    else if (i == 2) j = vec2(0.750, 0.111);
    else if (i == 3) j = vec2(0.125, 0.444);
    else if (i == 4) j = vec2(0.625, 0.778);
    else if (i == 5) j = vec2(0.375, 0.222);
    else if (i == 6) j = vec2(0.875, 0.556);
    else             j = vec2(0.0625, 0.889);
    return (j - 0.5) * 2.0 / vec2(viewWidth, viewHeight);
}
#else
vec2 taaJitter() { return vec2(0.0); }
#endif

#endif

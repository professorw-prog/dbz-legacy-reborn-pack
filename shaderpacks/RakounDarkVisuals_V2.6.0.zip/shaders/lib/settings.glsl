#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

//==============================================
//  Rakoun Dark Fantasy — Réglages
//  (les listes [..] alimentent le menu en jeu)
//==============================================

// --- Ombres ---
const int   shadowMapResolution      = 2048;   // [1024 2048 3072 4096]
const float shadowDistance           = 120.0;  // [80.0 120.0 160.0 200.0 256.0]
const float shadowDistanceRenderMul  = 1.0;
const float sunPathRotation          = -30.0;  // [-40.0 -30.0 -20.0 -10.0 0.0 10.0 20.0 30.0 40.0]

#define SHADOW_SOFTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]

// --- Ambiance ---
#define NIGHT_BRIGHTNESS 1.0 // [0.4 0.6 0.8 1.0 1.4 2.0]
#define FOG_DENSITY 1.0      // [0.0 0.5 0.75 1.0 1.5 2.0 3.0]
#define MIST_STRENGTH 1.0    // [0.0 0.5 1.0 1.5 2.0]
#define VOLUMETRIC_CLOUDS
#define CLOUD_SHADOWS
#define DEEP_SKY
#define HEAVY_FOG
#define POM
#define POM_DEPTH 0.12    // [0.05 0.08 0.12 0.16 0.20]
#define POM_DISTANCE 24.0 // [16.0 24.0 32.0 48.0]
#define RAIN_WETNESS
#define SCREEN_DROPLETS
#define DRIFTING_MIST

// --- Lumières & feu ---
#define TORCH_FLICKER
#define HAND_LIGHT
#define GODRAYS
#define GODRAY_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define GODRAY_SAMPLES 16   // [8 16 24 32 48]
#define VOLUMETRIC_LIGHT
#define VL_SAMPLES 12       // [8 12 16 24 32]
#define VL_STRENGTH 1.0     // [0.5 0.75 1.0 1.5 2.0]
#define GI
#define GI_STRENGTH 1.0     // [0.5 0.75 1.0 1.5 2.0 3.0]
#define GI_SAMPLES 12       // [8 12 16 24]
#define GI_RADIUS 8.0       // [4.0 6.0 8.0 12.0]
#define COLORED_LIGHT
#define COLORED_LIGHT_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]

// --- Splash de pluie : la particule vanilla est un cube bleu opaque ---
// On la supprime pour la remplacer par des impacts procéduraux.
// Discrimination : région d'atlas (relevée au debug) + texture bleutée
// + il pleut. Un resource pack qui réorganise l'atlas des particules peut
// fausser la région -> le toggle existe pour ça.
// Les 4 sprites splash_0..3 sont sur la MÊME LIGNE de l'atlas (v élevé)
// mais à des u DIFFÉRENTS : seul v discrimine. (u laissé à 0 = ignoré.)
#define KILL_VANILLA_RAIN_SPLASH
#define SPLASH_UV_UMIN 0.0
#define SPLASH_UV_VMIN 0.72

// Debug particules : 0 = off, 1 = UV en couleur (R = u, V = v),
// 2 = ROUGE sur ce que le kill supprimerait (vérification avant activation)
#define DEBUG_PARTICLE_UV 0   // [0 1 2]

// --- Impacts de pluie procéduraux (remplacent la particule vanilla) ---
// Deux régimes : ANNEAU qui se propage dans les flaques (une onde de
// surface a besoin d'une lame d'eau) ; IMPACT SEC + éclaboussure sur la
// pierre simplement mouillée. Tout est ADDITIF (règle du pack : une
// modulation animée SOUSTRACTIVE de l'éclairage laisse des taches
// fantômes moyennées par le TAA).
#define RAIN_SPLASH
#define RAIN_SPLASH_DENSITY 1.0  // [0.5 0.75 1.0 1.5 2.0]
#define RAIN_SPLASH_SIZE 1.0     // [0.6 0.8 1.0 1.3 1.6]
#define RAIN_SPLASH_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
// Éclaboussure sèche : léger surcoût, coupée dans le profil PERFORMANCE
#define RAIN_SPLASH_SPARKLE

// --- Contraste local (compression de tons LOCALE, domaine log2) ---
// Quand god rays + bloom + brume s'empilent, le contraste local s'effondre
// et l'image devient laiteuse : l'ACES ne compresse que globalement.
#define LOCAL_CONTRAST
#define LOCAL_CONTRAST_STRENGTH 1.15 // [1.0 1.05 1.1 1.15 1.2 1.3 1.45 1.6]
#define LOCAL_CONTRAST_RADIUS 6.0    // [4.0 5.0 6.0 7.0 8.0]
#define LOCAL_CONTRAST_CLAMP 1.5     // [0.75 1.0 1.25 1.5 2.0 3.0]
// 0 = off, 1 = base floutée, 2 = détail (gris = 0), 3 = masque du clamp
#define DEBUG_LOCAL_CONTRAST 0       // [0 1 2 3]

// --- Matériaux PBR auto (zéro resource pack) ---
#define AUTO_PBR
#define PBR_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]

// --- Eau ---
#define WATER_REFLECTIONS
#define SSR_STEPS 24 // [16 24 32 48]
//#define OFFSCREEN_REFLECTIONS
#define WATER_CAUSTICS
#define WATER_FOAM
#define WATER_PARALLAX

// --- Détails & relief ---
#define AUTO_NORMALS
#define RELIEF_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define COLOR_VARIATION
#define BLOCK_BLENDING
#define BLEND_WIDTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define GROUND_CREEP
#define SSAO
#define SSAO_STRENGTH 1.0 // [0.5 0.75 1.0 1.5]

// --- Végétation ---
#define WAVING_PLANTS
#define WAVING_LEAVES

// --- Post-traitement ---
#define EXPOSURE 1.0          // [0.6 0.8 1.0 1.2 1.5]
//#define TONEMAP_AGX
#define AUTO_EXPOSURE
#define CONTRAST 1.15         // [1.0 1.05 1.1 1.15 1.2 1.3]
#define SATURATION 0.9        // [0.4 0.5 0.6 0.75 0.9 1.0]
#define BLOOM_STRENGTH 0.45   // [0.0 0.1 0.25 0.35 0.45 0.6 0.8 1.0]
#define VIGNETTE_STRENGTH 0.4 // [0.0 0.15 0.3 0.4 0.45 0.6]
#define EDGE_BLUR
#define EDGE_BLUR_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
#define GRAIN_STRENGTH 0.03   // [0.0 0.015 0.03 0.05 0.08]
#define TAA
//#define FXAA
#define MOTION_BLUR
#define MOTION_BLUR_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]

// --- Diagnostic ---
//#define DEBUG_VIEW

// --- Cinéma ---
#define CHROMATIC_ABERRATION 0.5 // [0.0 0.25 0.5 1.0 1.5]
//#define DOF
#define DOF_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
//#define LETTERBOX

#endif

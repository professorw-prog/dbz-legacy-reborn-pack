#ifndef COMMON_GLSL
#define COMMON_GLSL

// Utilitaires partagés. Inclure APRÈS lib/settings.glsl.

float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// normalize() NaN-proof : dans les dimensions sans astre (Nether, End,
// dims moddées), sunPosition/shadowLightPosition valent zéro — un
// normalize(0) produit des NaN qui contaminent tout l'écran.
vec3 safeNormalize(vec3 v) {
    return v / max(length(v), 1e-4);
}

vec3 srgbToLinear(vec3 c) {
    return pow(c, vec3(2.2));
}

vec3 linearToSrgb(vec3 c) {
    return pow(max(c, 0.0), vec3(1.0 / 2.2));
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// Bruit de valeur 2D lissé
float valueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Encodage octaédrique des normales : 2 composantes couvrent TOUTE la
// sphère. Indispensable : reconstruire z = +sqrt(...) suppose z > 0, or en
// regardant vers le haut la normale du sol a un z view-space NÉGATIF —
// la normale se retournait et les reflets fondaient (prouvé par simulation).
vec2 octEncode(vec3 n) {
    n /= abs(n.x) + abs(n.y) + abs(n.z);
    vec2 e = n.xy;
    if (n.z < 0.0) {
        vec2 f = vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
        e = (1.0 - abs(e.yx)) * f;
    }
    return e * 0.5 + 0.5;
}

vec3 octDecode(vec2 e) {
    e = e * 2.0 - 1.0;
    vec3 n = vec3(e, 1.0 - abs(e.x) - abs(e.y));
    if (n.z < 0.0) {
        vec2 f = vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
        n.xy = (1.0 - abs(n.yx)) * f;
    }
    return normalize(n);
}

// Coordonnées équirectangulaires de la capture sphérique (panorama 360°).
// Doit rester l'exact inverse du mapping d'écriture dans composite7.
vec2 sphereCoord(vec3 dir) {
    float phi = atan(dir.x, dir.z);
    float theta = acos(clamp(dir.y, -1.0, 1.0));
    return vec2(phi / 6.2831853 + 0.5, 1.0 - theta / 3.14159265);
}

// Fractal brownian motion, 4 octaves (nuages, variations organiques)
float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += valueNoise(p) * a;
        p = p * 2.17 + vec2(13.7, 91.3);
        a *= 0.5;
    }
    return v;
}

// Ombre des nuages : la couche nuageuse est projetée au sol le long du
// soleil — les taches de lumière courent sur le terrain (idée IterationT).
// DOIT rester synchronisé avec le champ de nuages de composite.fsh
// (même fbm, même vent, même échelle 0.0035, même couverture).
float cloudShadow(vec3 worldPos, vec3 sunDirW, float rain, float t) {
#ifdef CLOUD_SHADOWS
    if (sunDirW.y < 0.08) return 1.0; // soleil rasant : la nuit prend le relais
    vec2 cp = worldPos.xz + sunDirW.xz / sunDirW.y * (165.0 - worldPos.y);
    vec2 wind = vec2(t * 3.0, t * 0.9);
    float n = fbm((cp + wind) * 0.0035);
    float cover = 0.50 + 0.30 * rain;
    float cd = smoothstep(1.0 - cover, 1.0 - cover + 0.30, n);
    float fadeSun = smoothstep(0.08, 0.20, sunDirW.y);
    return 1.0 - cd * 0.70 * fadeSun;
#else
    return 1.0;
#endif
}

#endif

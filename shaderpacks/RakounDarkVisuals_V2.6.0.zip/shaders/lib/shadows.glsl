#ifndef SHADOWS_GLSL
#define SHADOWS_GLSL

// Échantillonnage de la shadow map avec distorsion + PCF.
// Inclure APRÈS lib/settings.glsl.

uniform sampler2D shadowtex0;

// Distorsion : concentre la résolution près du joueur.
// Doit être appliquée à l'identique dans shadow.vsh et ici.
vec3 distortShadowClip(vec3 pos) {
    float f = length(pos.xy) * 0.9 + 0.1;
    pos.xy /= f;
    pos.z *= 0.5;
    return pos;
}

float sampleShadowmap(vec2 uv, float z) {
    return step(z, texture2D(shadowtex0, uv).r);
}

// SOLEIL COLORÉ (v2.5) : shadowtex1 = occulteurs OPAQUES seulement,
// shadowcolor0 = couleur du dernier caster (les vitraux y écrivent leur
// teinte). Lumière passée à travers un translucide = teintée.
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

float sampleShadowmapOpaque(vec2 uv, float z) {
    return step(z, texture2D(shadowtex1, uv).r);
}

// shadowClipPos : position en espace clip de la shadow camera (non distordue)
float getShadow(vec4 shadowClipPos, float NdotL) {
    // Dimensions sans soleil (Nether, dims moddées) : les matrices d'ombre
    // sont invalides -> NaN/valeurs énormes. On sort proprement, sinon le
    // NaN contamine l'éclairage puis désactive le clamp du TAA (garbage
    // VRAM plein écran).
    if (!(shadowClipPos.x == shadowClipPos.x) || abs(shadowClipPos.x) > 1e6) return 1.0;

    if (NdotL <= 0.0) return 0.0;

    float distortFactor = length(shadowClipPos.xy) * 0.9 + 0.1;
    vec3 sp = distortShadowClip(shadowClipPos.xyz);
    sp = sp * 0.5 + 0.5;

    // Le biais augmente avec la distorsion (texels plus grands au loin),
    // avec un PLANCHER : près du joueur distortFactor² ≈ 0.01 rendait le
    // biais 100x trop petit -> acné d'ombre en ovale suivant le joueur,
    // moyennée en disques par le TAA
    float bias = (0.0010 + 0.0025 * (1.0 - NdotL)) * max(distortFactor * distortFactor, 0.15);
    sp.z -= bias;

    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 1.0;

    float radius = SHADOW_SOFTNESS / float(shadowMapResolution);
    float sh = 0.0;
    sh += sampleShadowmap(sp.xy + vec2( radius,        radius * 0.5), sp.z);
    sh += sampleShadowmap(sp.xy + vec2(-radius * 0.5,  radius      ), sp.z);
    sh += sampleShadowmap(sp.xy + vec2(-radius,       -radius * 0.5), sp.z);
    sh += sampleShadowmap(sp.xy + vec2( radius * 0.5, -radius      ), sp.z);
    return sh * 0.25;
}

// ============================================================
//  TEINTE DES VITRAUX PAR MARCHE VOXEL (v2.5)
//  La shadow map ne retient qu'UN caster par texel : impossible d'y
//  empiler deux vitres. On marche donc le rayon du point vers le SOLEIL
//  dans le volume voxel du monde (celui de la lumière colorée) et on
//  MULTIPLIE les filtres traversés — bleu x jaune = VERT, comme dans la
//  vraie vie. Iris/Oculus uniquement (le volume n'existe que là).
// ============================================================
#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
uniform sampler3D voxel_sampler;   // r8 float : id / 255

vec3 glassTintOf(int id) {
    int i = id - 200;
    if (i ==  0) return vec3(0.95);              // blanc
    if (i ==  1) return vec3(1.0, 0.45, 0.12);   // orange
    if (i ==  2) return vec3(0.95, 0.15, 0.95);  // magenta
    if (i ==  3) return vec3(0.45, 0.65, 1.0);   // bleu clair
    if (i ==  4) return vec3(1.0, 0.95, 0.15);   // jaune
    if (i ==  5) return vec3(0.35, 1.0, 0.20);   // vert clair
    if (i ==  6) return vec3(1.0, 0.45, 0.75);   // rose
    if (i ==  7) return vec3(0.55);              // gris
    if (i ==  8) return vec3(0.75);              // gris clair
    if (i ==  9) return vec3(0.20, 0.85, 1.0);   // cyan
    if (i == 10) return vec3(0.65, 0.25, 1.0);   // violet
    if (i == 11) return vec3(0.15, 0.25, 1.0);   // bleu
    if (i == 12) return vec3(0.75, 0.50, 0.25);  // brun
    if (i == 13) return vec3(0.25, 0.85, 0.30);  // vert
    if (i == 14) return vec3(1.0, 0.15, 0.12);   // rouge
    return vec3(0.30);                           // noir : assombrit
}

// UN rayon : produit des filtres rencontrés entre le point et le soleil
vec3 glassRay(vec3 start, vec3 sunDirW) {
    vec3 p = start;
    vec3 tint = vec3(1.0);
    vec3 stepV = sunDirW * 0.5;                  // 2 pas par bloc
    ivec3 last = ivec3(-999);
    for (int i = 0; i < 48; i++) {
        p += stepV;
        if (p.x < 0.5 || p.x > 127.5 || p.y < 0.5 || p.y > 63.5
         || p.z < 0.5 || p.z > 127.5) break;     // sorti du volume
        ivec3 vi = ivec3(floor(p));
        if (vi == last) continue;                // même bloc : une seule fois
        last = vi;
        // centre du texel : le filtrage linéaire renvoie sa valeur exacte
        float raw = texture3D(voxel_sampler,
                (vec3(vi) + 0.5) / vec3(128.0, 64.0, 128.0)).r;
        int id = int(raw * 255.0 + 0.5);
        if (id >= 200) tint *= glassTintOf(id);  // FILTRE : on multiplie
        else if (id == 1) break;                 // opaque : la shadow map gère
    }
    return tint;
}

// La teinte est MOYENNÉE sur plusieurs rayons décalés autour du point :
// sans ça, la couleur saute d'un voxel à l'autre et deux vitrages voisins
// se touchent au couteau. Là, leurs teintes se FONDENT sur ~3 blocs.
vec3 sunGlassTint(vec3 playerPos, vec3 worldNormal, vec3 sunDirW, vec3 camPos) {
    vec3 p0 = playerPos + worldNormal * 0.6 + fract(camPos)
            + vec3(64.0, 32.0, 64.0);
    // hors du volume : pas d'info -> lumière blanche
    if (clamp(p0, vec3(0.5), vec3(127.5, 63.5, 127.5)) != p0) return vec3(1.0);

    // base perpendiculaire au soleil : les rayons s'écartent LATÉRALEMENT
    vec3 up = abs(sunDirW.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 tx = normalize(cross(sunDirW, up));
    vec3 ty = cross(sunDirW, tx);

    const float SOFT = 1.5;                      // blocs d'étalement
    vec3 sum = glassRay(p0, sunDirW) * 1.5;      // le centre pèse plus
    float w = 1.5;
    for (int i = 0; i < 5; i++) {
        float fi = float(i) + 0.5;
        float rr = SOFT * sqrt(fi / 5.0);
        float aa = fi * 2.3999632;               // spirale de Vogel
        vec3 off = (tx * cos(aa) + ty * sin(aa)) * rr;
        sum += glassRay(p0 + off, sunDirW);
        w += 1.0;
    }
    return sum / w;
}
#endif

// Ombre COLORÉE : comme getShadow, mais la lumière qui traverse un
// TRANSLUCIDE (vitrail, verre, eau) prend sa couleur — le soleil peint
// le sol aux couleurs du vitrail, façon SEUS PTGI.
vec3 getShadowColored(vec4 shadowClipPos, float NdotL, vec3 playerPos,
                      vec3 worldNormal, vec3 sunDirW, vec3 camPos) {
    if (!(shadowClipPos.x == shadowClipPos.x) || abs(shadowClipPos.x) > 1e6) return vec3(1.0);
    if (NdotL <= 0.0) return vec3(0.0);

    float distortFactor = length(shadowClipPos.xy) * 0.9 + 0.1;
    vec3 sp = distortShadowClip(shadowClipPos.xyz);
    sp = sp * 0.5 + 0.5;
    float bias = (0.0010 + 0.0025 * (1.0 - NdotL)) * max(distortFactor * distortFactor, 0.15);
    sp.z -= bias;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return vec3(1.0);

    float radius = SHADOW_SOFTNESS / float(shadowMapResolution);
    vec2 o1 = vec2( radius,        radius * 0.5);
    vec2 o2 = vec2(-radius * 0.5,  radius      );
    vec2 o3 = vec2(-radius,       -radius * 0.5);
    vec2 o4 = vec2( radius * 0.5, -radius      );

    // shadowtex0 = TOUS les casters (verre compris), shadowtex1 = les
    // OPAQUES seuls. La part de lumière arrêtée par shadowtex0 mais PAS
    // par shadowtex1 est celle qui traverse un translucide : elle passe,
    // teintée par la couleur du vitrail (shadowcolor0).
    float shAll = (sampleShadowmap(sp.xy + o1, sp.z) + sampleShadowmap(sp.xy + o2, sp.z)
                 + sampleShadowmap(sp.xy + o3, sp.z) + sampleShadowmap(sp.xy + o4, sp.z)) * 0.25;
    float shOp = (sampleShadowmapOpaque(sp.xy + o1, sp.z) + sampleShadowmapOpaque(sp.xy + o2, sp.z)
                + sampleShadowmapOpaque(sp.xy + o3, sp.z) + sampleShadowmapOpaque(sp.xy + o4, sp.z)) * 0.25;

    // === DIFFUSION (v2.5) : un vitrail ne projette pas au couteau — le
    // verre DISPERSE la lumière. La COUVERTURE translucide est mesurée
    // sur un DISQUE LARGE (rayon ~ 40x le PCF) : les bords fondent et la
    // couleur déborde bien au-delà de la découpe du vitrage.
    const float SPREAD = 40.0;
    vec2 sr = vec2(radius * SPREAD);
    float transluSum = 0.0;
    float wSum = 0.0;
    vec3 tintSum = vec3(0.0);
    for (int i = 0; i < 12; i++) {
        float fi = float(i) + 0.5;
        float rr = sqrt(fi / 12.0);
        float aa = fi * 2.3999632;             // spirale de Vogel
        vec2 uv = sp.xy + vec2(cos(aa), sin(aa)) * rr * sr;
        float a = sampleShadowmap(uv, sp.z);
        float o = sampleShadowmapOpaque(uv, sp.z);
        float t = max(o - a, 0.0);             // ce tap passe par du verre
        float w = 1.0 - rr * 0.55;             // le centre pèse plus
        transluSum += t * w;
        if (t > 0.0) tintSum += texture2D(shadowcolor0, uv).rgb * (t * w);
        wSum += w;
    }
    float translu = transluSum / max(wSum, 1e-4);
    // la lumière DIRECTE garde ses bords nets (4 taps), seule la couleur
    // qui traverse le verre est diffuse
    if (translu < 0.002) return vec3(shAll);

    // La COULEUR, elle, vient de la MARCHE VOXEL : produit de TOUS les
    // filtres entre le point et le soleil (bleu x jaune = vert). La
    // shadow map ne sert plus qu'à savoir COMBIEN de lumière passe.
    vec3 tint;
    #if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
        tint = sunGlassTint(playerPos, worldNormal, sunDirW, camPos);
        // rien trouvé dans le volume (hors portée) : repli shadowcolor0
        if (tint == vec3(1.0)) {
            tint = tintSum / max(transluSum, 1e-4);
            tint = tint / max(max(tint.r, max(tint.g, tint.b)), 0.30);
            tint *= tint;
        }
    #else
        tint = tintSum / max(transluSum, 1e-4);
        tint = tint / max(max(tint.r, max(tint.g, tint.b)), 0.30);
        tint *= tint;
    #endif

    // la part colorée est ÉTALÉE : son intensité suit la couverture
    // moyennée (dégradé doux), pas le masque binaire du texel
    return vec3(shAll) + tint * translu * 1.5;
}

#endif

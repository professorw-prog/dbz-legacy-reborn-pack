#ifndef SKY_GLSL
#define SKY_GLSL

// Ciel Dark Fantasy — couleurs en espace linéaire.
// Inclure APRÈS lib/settings.glsl et lib/common.glsl.
// dir et sunDir sont en espace monde, normalisés.

vec3 getSkyColor(vec3 dir, vec3 sunDir, float rain) {
    float sunH = sunDir.y;

    float day   = smoothstep(-0.05, 0.25, sunH);
    float night = 1.0 - day;
    float dusk  = 1.0 - smoothstep(0.05, 0.35, abs(sunH));

    float horizon = pow(1.0 - clamp(dir.y, 0.0, 1.0), 2.5);

    vec3 zenithDay    = vec3(0.045, 0.065, 0.100);
    vec3 horizonDay   = vec3(0.160, 0.180, 0.220);
    // Zénith d'encre, mais un discret dégradé bleu-gris à l'horizon :
    // un ciel 100% noir paraissait artificiel (retour beta)
    vec3 zenithNight  = vec3(0.0010, 0.0014, 0.0035) * NIGHT_BRIGHTNESS;
    vec3 horizonNight = vec3(0.0070, 0.0092, 0.0165) * NIGHT_BRIGHTNESS;

    vec3 sky = mix(mix(zenithNight, zenithDay, day),
                   mix(horizonNight, horizonDay, day),
                   horizon);

    // Lueur crépusculaire "rouge sang"
    float sunGlow = pow(max(dot(dir, sunDir), 0.0), 4.0);
    sky += vec3(0.25, 0.045, 0.02) * sunGlow * dusk * (0.4 + 0.6 * horizon) * (1.0 - rain);

    // Crépuscule DRAMATIQUE : bande dorée incandescente à l'horizon côté
    // soleil, rose poudré qui s'étale, voile pourpre en montant — le
    // dégradé "heure dorée" des couchers mémorables
    {
        vec2 dxz = dir.xz + vec2(1e-5, 0.0);
        vec2 sxz = sunDir.xz + vec2(1e-5, 0.0);
        float az = dot(normalize(dxz), normalize(sxz)) * 0.5 + 0.5;
        float sunAz = az * az * az;                                  // concentré côté soleil
        float belt = pow(1.0 - clamp(abs(dir.y), 0.0, 1.0), 6.0);    // fine bande d'horizon
        float spread = pow(1.0 - clamp(dir.y, 0.0, 1.0), 3.0);       // large montée

        sky += (vec3(0.85, 0.38, 0.08) * belt * (0.25 + 1.10 * sunAz)
              + vec3(0.38, 0.10, 0.10) * spread * (0.12 + 0.50 * sunAz)
              + vec3(0.10, 0.045, 0.14) * spread * 0.30) * dusk * (1.0 - rain);
    }

    // Halo pâle autour de la lune — il PERCE partiellement les nuages
    // d'orage (lueur diffuse, comme une vraie nuit de pluie)
    float moonGlow = pow(max(dot(dir, -sunDir), 0.0), 6.0);
    sky += vec3(0.020, 0.028, 0.050) * moonGlow * night * NIGHT_BRIGHTNESS
         * (1.0 - 0.70 * rain);

    // Pluie : ciel gris délavé, légèrement assombri de jour — l'horizon
    // doit rejoindre la dalle nuageuse, mais SANS s'éteindre
    sky = mix(sky, vec3(luminance(sky)) * vec3(0.90, 0.95, 1.05), rain * 0.8);
    sky *= 1.0 - rain * 0.18 * day;
    // Nuit de pluie : un plancher gris-bleu — le ciel d'orage ne doit
    // JAMAIS être un néant noir (retour joueurs : « ça gâche la vibe »)
    sky += vec3(0.0026, 0.0032, 0.0048) * NIGHT_BRIGHTNESS * rain * night;

    // Assombrissement sous l'horizon
    sky *= mix(1.0, 0.3, smoothstep(0.0, 0.35, -dir.y));

    return sky;
}

#endif

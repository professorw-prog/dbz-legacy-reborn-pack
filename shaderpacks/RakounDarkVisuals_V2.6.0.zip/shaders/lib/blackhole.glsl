#ifndef BLACKHOLE_GLSL
#define BLACKHOLE_GLSL

// ====================================================================
//  TROU NOIR À LENTILLE GRAVITATIONNELLE (recette IterationT/EndSky
//  portée en GLSL 120) : le rayon se COURBE vers la singularité à
//  chaque pas (attraction en 1/d²) — les étoiles s'étirent en anneau,
//  le disque d'accrétion s'enroule au-dessus ET en dessous de
//  l'horizon, façon Interstellar. Le fond (étoiles, voie lactée...)
//  DOIT être échantillonné avec la direction de SORTIE courbée.
//  Nécessite lib/common.glsl (fbm, hash12, valueNoise).
// ====================================================================

// Une couche d'étoiles : cellules sur la projection octaédrique,
// position et brillance aléatoires par cellule (partagée Overworld/End)
float starLayer(vec2 suv, float cells, float thresh, float sharp) {
    vec2 cid = floor(suv * cells);
    vec2 f = fract(suv * cells);
    float h = hash12(cid);
    if (h < thresh) return 0.0;
    vec2 spos = vec2(hash12(cid + 17.1), hash12(cid + 39.7)) * 0.6 + 0.2;
    float d = length(f - spos);
    float b = (h - thresh) / (1.0 - thresh);
    return max(0.0, 1.0 - d * sharp) * b * b;
}

// Profil radial du disque (bosse asymétrique, cf. IterationT pcurve)
float bhPcurve(float x) {
    float x2 = x * x;
    return 12.207 * x2 * x2 * (1.0 - x);
}

// dir       : direction de vue (monde, normalisée)
// bhDir     : position du trou dans le ciel
// bhSize    : demi-angle apparent du disque (rad) — 0.15 discret, 0.4 géant
// intensity : échelle de luminosité du disque
// Retour    : direction de fond COURBÉE ; out : transmittance + lueur
vec3 blackHoleMarch(vec3 dir, vec3 bhDir, float bhSize, float dither,
                    float t, float intensity,
                    out float transOut, out vec3 glowOut) {
    transOut = 1.0;
    glowOut = vec3(0.0);

    float ang = acos(clamp(dot(dir, bhDir), -1.0, 1.0));
    float gate = bhSize * 4.6;
    if (ang > gate) return dir; // loin du trou : rien à faire
    // Fondu doux vers le bord du cône : le disque et la déflexion
    // s'estompent AVANT la limite — plus jamais de coupe franche
    float edgeFade = 1.0 - smoothstep(bhSize * 3.2, gate, ang);

    // Base locale (z vers le trou) ; calibration : bhSize = taille
    // apparente de l'ANNEAU DE PHOTONS (le coeur visuel), pas du disque
    // diffus — l'anneau interne fait ~0.125 rad vu de la caméra virtuelle
    vec3 aux = (abs(bhDir.y) > 0.9) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 tX = normalize(cross(bhDir, aux));
    vec3 tY = cross(bhDir, tX);
    float zoom = 0.16 / max(bhSize, 0.02);
    vec3 rd = normalize(vec3(dot(dir, tX) * zoom, dot(dir, tY) * zoom, dot(dir, bhDir)));
    vec3 rd0 = rd; // direction d'entrée (pour mesurer la déflexion)

    // Disque incliné (pitch 0.1, roll -0.35), matrice constante
    mat3 rot = mat3(1.0, 0.0, 0.0,
                    0.0, 0.99500417, 0.09983342,
                    0.0, -0.09983342, 0.99500417)
             * mat3(0.93937271, -0.34289781, 0.0,
                    0.34289781, 0.93937271, 0.0,
                    0.0, 0.0, 1.0);

    // Caméra virtuelle à 8 unités, départ à 3 du trajet (géométrie IterationT)
    vec3 rp = vec3(0.0, 0.0, -8.0) + rd * (3.0 + 0.25 * dither);

    float trans = 1.0;
    vec3 glow = vec3(0.0);

    for (int i = 0; i < 40; i++) {
        if (trans < 0.002) break;
        // Courbure gravitationnelle : le rayon tombe vers la singularité
        float sd = length(rp);
        rd = normalize(rd - rp * (0.06 / (sd * sd * sd + 1e-5)));
        rp += rd * 0.25;

        // Horizon des événements : la lumière est avalée
        if (length(rp) < 0.42) { trans = 0.0; break; }

        vec3 dp = rot * rp;
        float r = length(dp);
        float h = dp.y;

        // --- Disque d'accrétion (anneau r 0.5 -> 4.0) ---
        float radial = 1.0 - clamp((r - 0.5) / 7.0, 0.0, 1.0);
        float thick = 0.10 * radial;
        float dens = bhPcurve(radial)
                   * clamp(1.0 - abs(h) / max(thick, 1e-4), 0.0, 1.0);
        dens = clamp(dens * 0.7, 0.0, 1.0);

        if (dens > 0.0005 && r > 0.5) {
            // Spirales de matière (fbm sur rayon/azimut, en rotation)
            float phi = atan(dp.x, dp.z);
            // La matière SPIRALE visiblement vers l'horizon : flux radial
            // rapide + dérive azimutale (plus vite près du centre)
            float rr = r * 3.0 - t * 0.55;
            float swirl = r * 4.0 - t * 0.35 / max(r * 0.5, 0.4);
            float f1 = fbm(vec2(rr, phi * 2.5 + swirl));
            // COUTURE : atan saute de -pi à +pi le long d'une ligne et le
            // bruit change de valeur d'un coup (tranche nette dans le
            // disque) — près de la couture on fond avec l'échantillon
            // déroulé de l'autre côté, raccord parfaitement continu
            float seamW = smoothstep(0.55, 1.0, abs(phi) * 0.3183099);
            if (seamW > 0.001) {
                float f1b = fbm(vec2(rr, (phi - sign(phi) * 6.2831853) * 2.5 + swirl));
                f1 = mix(f1, f1b, seamW * 0.5);
            }
            f1 = f1 * f1;
            dens *= f1 * bhPcurve(radial) * 4.0;

            float gr = 1.0 - radial;
            gr = gr * gr;
            float gs = min(1.0 / (gr * gr * 400.0 + 0.002), 60.0);
            // Corps noir approx : blanc-or brûlant au centre, orange dehors
            vec3 gcol = mix(vec3(1.0, 0.42, 0.12), vec3(1.0, 0.85, 0.60),
                            clamp(gs * 0.02, 0.0, 1.0)) * gs;
            // Doppler : le côté qui fonce vers nous est plus brillant
            gcol *= sin(phi - 1.07) * 0.75 + 1.0;

            float st = exp2(-dens * 7.0);
            glow += (1.0 - st) * trans * gcol * 0.08;
            trans *= st;
        }

        // Anneau de photons : tore incandescent serré autour de l'horizon
        float ringD = length(vec2(length(dp.xz) - 1.0, dp.y + 0.05));
        float ring = 1.0 / (pow(ringD, 3.5) * 10.0 + 0.001);
        glow += vec3(1.0, 0.90, 0.75) * ring * 0.0025 * trans * step(0.5, r);
    }

    transOut = mix(1.0, trans, edgeFade);
    glowOut = min(glow, vec3(24.0)) * intensity * edgeFade;

    // Direction de sortie : la DÉFLEXION mesurée en espace interne est
    // rapportée (dé-zoomée) sur la direction d'origine — un rayon non
    // dévié ressort EXACTEMENT inchangé (pas de remap parasite du fond)
    vec3 delta = (rd - rd0) * edgeFade;
    return normalize(dir + (tX * delta.x + tY * delta.y + bhDir * delta.z) / zoom);
}

#endif

#version 330 compatibility

// DISTANT HORIZONS : eau LOD — cohérente avec notre eau cristalline :
// teinte discrète, reflet du CIEL qui monte en rasant (fresnel), glint
// du soleil/de la lune. Les vagues n'existent pas à ces distances : la
// surface est un miroir calme, c'est exactement ce qu'on voit de loin.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/sky.glsl"

flat in int matId;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalW;
in vec3 playerPos;

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float far;
uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform sampler2D depthtex1;

void main() {
    // SEULE L'EAU est rendue ici : DH fait passer TOUS ses translucides
    // par ce programme — y compris ses NUAGES, que notre shading eau
    // peignait en dôme sombre permanent plein ciel. Nos nuages
    // volumétriques font le travail, ceux de DH sont écartés.
    if (matId != DH_BLOCK_WATER) discard;

    // Les translucides DH ne sont PAS testés contre le depth vanilla :
    // partout où un bloc RÉEL opaque couvre le pixel, on s'écarte —
    // sinon l'eau LOD se voit À TRAVERS le terrain (taches sombres et
    // bleues sur les murs). Même recette que Complementary.
    if (texture2D(depthtex1,
            gl_FragCoord.xy / vec2(viewWidth, viewHeight)).r < 1.0) discard;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;
    vec3 N = normalize(normalW);
    vec3 lightW = safeNormalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    vec3 viewW = normalize(playerPos);

    // teinte d'eau discrète (cohérente avec l'eau proche transparente)
    vec3 biomeTint = srgbToLinear(glcolor.rgb) * vec3(0.18, 0.22, 0.23);
    vec3 albedo = mix(vec3(0.05, 0.08, 0.09), biomeTint, 0.30);

    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);
    float hemi = 0.45 + 0.55 * (N.y * 0.5 + 0.5);
    vec3 light = getShadowLightColor(sunH, rainStrength) * skyExposure * 0.6
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y) * hemi
               + CAVE_AMBIENT;
    vec3 color = albedo * light;

    // reflet du ciel : monte en rasant — de loin l'eau EST un miroir
    float fresnel = pow(1.0 - clamp(dot(-viewW, N), 0.0, 1.0), 3.0);
    vec3 rDir = reflect(viewW, N);
    rDir.y = abs(rDir.y);
    vec3 skyRefl = getSkyColor(rDir, sunDirW, rainStrength)
                 * skyExposure * skyExposure;
    color = mix(color, skyRefl, 0.15 + 0.80 * fresnel);

    // glint serré du soleil / de la lune
    float glint = pow(clamp(dot(rDir, lightW), 0.0, 1.0), 220.0);
    color += getShadowLightColor(sunH, rainStrength) * glint * 2.2 * skyExposure;

    float alpha = mix(0.42, 0.95, fresnel);

    // fondu d'apparition, synchronisé avec le terrain DH
    float cyl = max(length(playerPos.xz), abs(playerPos.y));
    float aIn = smoothstep(far * 0.5, far * 0.75, cyl);
    // dither STATIQUE (pas de terme temporel) : en mouvement le TAA
    // rejette son historique et un dither animé devenait un anneau de
    // grésillement visible autour du joueur
    float dither = hash12(gl_FragCoord.xy);
    if (aIn < dither) discard;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, alpha);
}

#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/shadows.glsl"
#include "/lib/water.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform vec3 cameraPosition;
#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
uniform int frameCounter;
uniform sampler3D floodfill_sampler;
uniform sampler3D floodfill_sampler_copy;
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;
varying float isWater;
varying float glassType;
varying float upFace;
varying vec3 worldPos;
varying vec3 viewVec;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    vec3 albedo = srgbToLinear(tex.rgb * glcolor.rgb);
    float alpha = tex.a * glcolor.a;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    vec3 nV = normalV;

    if (isWater > 0.5) {
        // Eau 100% procédurale : on ignore la texture vanilla.
        // glcolor porte la teinte du biome (marécage, océan...)
        vec2 wxz = worldPos.xz;
        if (upFace > 0.5) {
            // Parallaxe des vagues (idée IterationT) : la hauteur de houle
            // est marchée le long du regard — les crêtes cachent les creux
            // en vue rasante, la surface prend un vrai RELIEF
            #ifdef WATER_PARALLAX
            {
                vec3 viewW = normalize(mat3(gbufferModelViewInverse) * viewVec);
                float vy = max(abs(viewW.y), 0.12);
                for (int i = 0; i < 4; i++) {
                    float hp = waveHeight(wxz, frameTimeCounter) * WAVE_AMPLITUDE;
                    wxz = worldPos.xz + viewW.xz * (-hp / vy);
                }
            }
            #endif
            vec3 nW = waveNormalWorld(wxz, frameTimeCounter);
            // Impacts de pluie : anneaux d'ondulation qui s'élargissent
            if (rainStrength > 0.01) {
                nW.xz += rainRippleGrad(wxz, frameTimeCounter) * 0.5 * rainStrength;
                nW = normalize(nW);
            }
            nV = normalize(mat3(gbufferModelView) * nW);
        }
        float h = waveHeight(wxz, frameTimeCounter);
        // Eau CRISTALLINE (v2.4.1) : en plongée la surface s'efface presque
        // (le fond se voit NET), le miroir n'existe qu'en rasant (fresnel,
        // plus bas). L'ancien alpha 0.36 posait un voile laiteux permanent.
        // TRANSPARENTE : teinte quasi neutre (gris froid à peine bleuté)
        // et alpha minimal — le fond se voit comme à travers du verre ;
        // la surface existe par ses reflets rasants, son glint et l'écume
        vec3 biomeTint = srgbToLinear(glcolor.rgb) * vec3(0.18, 0.22, 0.23);
        albedo = mix(vec3(0.05, 0.08, 0.09), biomeTint, 0.30) * (0.98 + 0.06 * h);
        alpha = 0.12;
    }

    float portalGlow = 0.0;
    if (glassType > 2.5) {
        // Portail MÉDIÉVAL DARK FANTASY, 100% procédural (réf SoftVoxels,
        // en rouge pourpre) : un marbre TOURBILLONNANT aux rides déformées
        // par le bruit — la base reste profonde et sombre, seules les
        // VEINES incandescentes et les étincelles explosent en HDR
        vec3 nWp = mat3(gbufferModelViewInverse) * normalV;
        vec2 pl = (abs(nWp.x) > 0.5) ? worldPos.zy : worldPos.xy;
        float t = frameTimeCounter;

        vec2 q = pl * 1.5;
        float w1 = fbm(q * 0.9 + vec2(0.0, -t * 0.22));          // flux montant lent
        float w2 = fbm(q * 1.8 + vec2(w1 * 2.4, -t * 0.35));
        float veins = 0.5 + 0.5 * sin(q.x * 2.2 + q.y * 2.8 + w2 * 8.0 - t * 0.7);
        veins = pow(veins, 2.4);
        float deep = 0.5 + 0.5 * sin(q.y * 1.4 - w1 * 5.0 + t * 0.4);

        // Le pourpre ne vit que dans les OMBRES (un violet sombre ne
        // clippe pas) ; les veines sont du rouge sang QUASI PUR — le
        // moindre bleu dans les zones vives vire au rose/magenta
        vec3 base = mix(vec3(0.045, 0.003, 0.028), vec3(0.16, 0.008, 0.030), deep);
        vec3 pcol = base + vec3(0.70, 0.030, 0.045) * pow(veins, 1.4) * 1.2;

        // Étincelles qui montent le long du vortex
        vec2 sc = pl * 5.0 + vec2(0.0, -t * 0.6);
        vec2 cellS = floor(sc);
        vec2 fS = fract(sc) - 0.5;
        float hS = hash12(cellS);
        float spark = step(0.90, hS) * max(0.0, 1.0 - length(fS) * 4.0)
                    * (0.6 + 0.4 * sin(t * 4.0 + hS * 50.0));
        pcol += vec3(0.95, 0.12, 0.08) * spark * 1.8;

        float pulse = 0.85 + 0.15 * sin(t * 1.7 + worldPos.y * 0.9);
        albedo = pcol;
        // Intensité contenue : le rouge poussé trop haut CLIPPE en rose
        // au tonemap — le pourpre profond exige de rester sous la limite
        portalGlow = (0.75 + veins * 1.3 + spark * 3.0) * pulse;
        alpha = 0.92;
    } else if (glassType > 0.5 && glassType < 1.5) {
        // Verre clair : on remplace la texture vanilla par une surface
        // lisse et légèrement teintée ; les stries deviennent discrètes
        float streak = tex.a;
        albedo = mix(vec3(0.20, 0.24, 0.26), albedo, streak * 0.4);
        alpha = 0.22 + streak * 0.25;
    } else if (glassType > 1.5) {
        // Verre teinté / glace : couleur conservée, surface lissée
        alpha = clamp(alpha, 0.35, 0.75);
    }

    vec3 lightDirV = safeNormalize(shadowLightPosition);
    float NdotL = clamp(dot(nV, lightDirV), 0.0, 1.0);

    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);
    vec3 shadow = getShadowColored(shadowPos, NdotL,
            worldPos - cameraPosition,
            mat3(gbufferModelViewInverse) * normalV, sunDirW, cameraPosition);
    float shadowFade = smoothstep(shadowDistance * 0.75, shadowDistance, vertDist);
    shadow = mix(shadow, vec3(skyExposure), shadowFade);
    // Les nuages projettent leurs ombres sur l'eau aussi
    shadow *= cloudShadow(worldPos, sunDirW, rainStrength, frameTimeCounter);

    float skyGate = smoothstep(0.05, 0.35, lmcoord.y);

    float flick = torchFlicker(frameTimeCounter);
    vec3 shadowLightColor = getShadowLightColor(sunH, rainStrength);

    // LUMIÈRE COLORÉE sur l'eau (v2.5) : elle reflète les lanternes des
    // âmes en bleu, la redstone en rouge... même volume que le terrain
    vec3 torchLightCol = getTorchLight(lmcoord.x);
    #if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
    {
        vec3 playerP = worldPos - cameraPosition;
        vec3 nWv = mat3(gbufferModelViewInverse) * normalV;
        vec3 vox = playerP + nWv * 0.55 + fract(cameraPosition)
                 + vec3(64.0, 32.0, 64.0);
        vec3 vt = vox / vec3(128.0, 64.0, 128.0);
        if (vt == clamp(vt, vec3(0.01), vec3(0.99))) {
            vec4 lv = (mod(float(frameCounter), 2.0) < 0.5)
                    ? texture3D(floodfill_sampler_copy, vt)
                    : texture3D(floodfill_sampler, vt);
            vec3 cv = sqrt(max(lv.rgb, 0.0));
            float pres = luminance(cv);
            if (pres > 0.015) {
                float voxI = pres * pres * (0.11 * COLORED_LIGHT_STRENGTH);
                float inten = max(getTorchIntensity(lmcoord.x), voxI);
                vec3 colored = inten * (cv / pres) * luminance(FIRE_COLOR);
                vec3 eV = abs(vt - 0.5) * 2.0;
                float edge = smoothstep(1.0, 0.8, max(eV.x, max(eV.y, eV.z)));
                torchLightCol = mix(torchLightCol, colored,
                                    edge * smoothstep(0.003, 0.030, pres));
            }
        }
    }
    #endif

    vec3 light = shadowLightColor * (shadow * NdotL * skyGate)
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y)
               + torchLightCol * flick
               + CAVE_AMBIENT
               + srgbToLinear(fogColor) * 0.055 * (1.0 - lmcoord.y);

    #ifdef HAND_LIGHT
        float held = float(max(heldBlockLightValue, heldBlockLightValue2));
        light += getHeldLight(vertDist, held, flick);
    #endif

    vec3 color = albedo * light;

    // Le portail ÉMET sa propre lumière (il nourrit le bloom et se
    // reflète sur les sols mouillés via colortex0)
    if (glassType > 2.5) {
        color = albedo * portalGlow;
    }

    vec3 viewDir = normalize(viewVec);
    float fresnel = pow(1.0 - clamp(dot(-viewDir, nV), 0.0, 1.0), 3.0);

    if (isWater > 0.5) {
        // Reflet spéculaire du soleil / de la lune : SERRÉ et net —
        // l'ancien pow 64 x3 s'étalait en taches blanches molles (« l'eau
        // fait floue »). Cristallin = étincelle fine sur les crêtes.
        vec3 refl = reflect(viewDir, nV);
        float spec = pow(clamp(dot(refl, lightDirV), 0.0, 1.0), 220.0);
        color += shadowLightColor * spec * shadow * 2.2;
        alpha = mix(alpha, 0.95, fresnel * 0.55);
    } else if (glassType > 0.5 && glassType < 2.5) {
        // Éclat spéculaire fin sur le verre (pas sur le portail : il rayonne)
        vec3 refl = reflect(viewDir, nV);
        float spec = pow(clamp(dot(refl, lightDirV), 0.0, 1.0), 128.0);
        color += shadowLightColor * spec * shadow * 1.5;
        alpha = mix(alpha, 0.9, fresnel * 0.6);
    }

    // Données pour les reflets écran (composite) — écrites SANS blending
    // (cf. shaders.properties) : rg = normale view-space, b = exposition
    // au ciel, a = masque (1.0 = eau, 0.6 = verre, 0.0 = rien)
    float reflMask = 0.0;
    if (glassType > 0.5 && glassType < 2.5) reflMask = 0.6;
    if (isWater > 0.5) reflMask = 1.0;

/* DRAWBUFFERS:02 */
    gl_FragData[0] = vec4(color, alpha);
    gl_FragData[1] = vec4(octEncode(nV), lmcoord.y, reflMask);
}

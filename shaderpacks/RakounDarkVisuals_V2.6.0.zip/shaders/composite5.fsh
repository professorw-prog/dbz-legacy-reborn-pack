#version 120
#extension GL_ARB_shader_texture_lod : enable

// Auto-exposition : mesure de la luminance moyenne de l'image (mips)
// lissée dans le temps, stockée dans colortex3 (jamais effacé).
//
// v2.6 : cette passe génère DÉJÀ les mips de colortex0 — elle en profite
// pour écrire la BASE basse fréquence du contraste local dans colortex3.g
// (canal libre : le .r de l'auto-expo est une valeur GLOBALE, identique
// sur tous les pixels). final la relit d'un simple texture2D : aucune
// seconde génération de mipmaps (Iris en refait une par programme qui
// déclare colortex0MipmapEnabled), aucun buffer supplémentaire.

/*
const bool colortex0MipmapEnabled = true;
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform float frameTime;

varying vec2 texcoord;

void main() {
    // Moyenne pondérée : centre + trois zones, à des mips très réduits
    vec3 avg = texture2DLod(colortex0, vec2(0.5, 0.5), 16.0).rgb * 0.5
             + (texture2DLod(colortex0, vec2(0.25, 0.4), 8.0).rgb
              + texture2DLod(colortex0, vec2(0.75, 0.4), 8.0).rgb
              + texture2DLod(colortex0, vec2(0.5, 0.65), 8.0).rgb) * 0.1667;
    float lum = max(luminance(avg), 0.0005);

    // Adaptation progressive (~1 seconde), comme l'oeil
    float prev = texture2D(colortex3, vec2(0.5, 0.5)).r;
    if (prev <= 0.0001) prev = lum;
    float sm = mix(prev, lum, clamp(frameTime * 1.8, 0.005, 0.5));

    // BASE du contraste local : luminance LINÉAIRE d'un mip large de
    // l'image post-TAA. (Pré-expo : final lui applique le même gain.)
    float baseL = 0.0;
    #ifdef LOCAL_CONTRAST
        baseL = luminance(texture2DLod(colortex0, texcoord,
                                       LOCAL_CONTRAST_RADIUS).rgb);
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(sm, baseL, 0.0, 1.0);
}

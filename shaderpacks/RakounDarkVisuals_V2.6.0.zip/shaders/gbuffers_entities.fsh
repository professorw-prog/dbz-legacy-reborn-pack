#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/shadows.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform vec4 entityColor;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;

    // Flash rouge quand l'entité est blessée
    tex.rgb = mix(tex.rgb, entityColor.rgb, entityColor.a);

    vec3 albedo = srgbToLinear(tex.rgb * glcolor.rgb);

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    vec3 lightDirV = safeNormalize(shadowLightPosition);
    float NdotL = clamp(dot(normalV, lightDirV), 0.0, 1.0);

    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);
    float shadow = getShadow(shadowPos, NdotL);
    float shadowFade = smoothstep(shadowDistance * 0.75, shadowDistance, vertDist);
    shadow = mix(shadow, skyExposure, shadowFade);

    float skyGate = smoothstep(0.05, 0.35, lmcoord.y);

    float flick = torchFlicker(frameTimeCounter);

    float upW = clamp((mat3(gbufferModelViewInverse) * normalV).y, -1.0, 1.0);
    float hemi = 0.45 + 0.55 * (upW * 0.5 + 0.5);

    vec3 light = getShadowLightColor(sunH, rainStrength) * (shadow * NdotL * skyGate)
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y) * hemi
               + getTorchLight(lmcoord.x) * flick
               + CAVE_AMBIENT
               + srgbToLinear(fogColor) * 0.055 * (1.0 - lmcoord.y) * hemi;

    #ifdef HAND_LIGHT
        float held = float(max(heldBlockLightValue, heldBlockLightValue2));
        light += getHeldLight(vertDist, held, flick);
    #endif

    vec3 color = albedo * light;

/* DRAWBUFFERS:02 */
    gl_FragData[0] = vec4(color, tex.a * glcolor.a);
    // Efface le masque de reflets : pas de SSR sur les mobs devant un sol mouillé
    gl_FragData[1] = vec4(0.5, 0.5, lmcoord.y, 0.0);
}

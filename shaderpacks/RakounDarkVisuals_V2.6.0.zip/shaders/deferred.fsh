#version 120

// Lumière volumétrique en DEMI-RÉSOLUTION (technique "coin de buffer",
// comme le bloom de Kappa : portable, aucune dépendance aux propriétés).
// L'intégrale de visibilité (le raymarch de la shadow map, la partie
// chère) est calculée dans le quart bas-gauche de colortex6 : 4x moins
// de pixels. composite la ré-agrandit avec un filtre bilatéral guidé
// par la distance, pour ne pas baver sur les silhouettes.
//
// Cette passe tourne AVANT les translucides : la profondeur est celle
// des opaques. Pour un effet atmosphérique, la différence est invisible.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D depthtex0;
uniform sampler2D colortex2;
// (shadowcolor0 vient de lib/shadows.glsl — soleil coloré v2.5)
uniform sampler2D shadowcolor1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int frameCounter;

varying vec2 texcoord;

// Bruit allégé pour la nappe (2 octaves au lieu des 4 du fbm : la mer de
// brouillard est molle, elle n'a pas besoin de hautes fréquences)
float fogNoise(vec2 p) {
    return valueNoise(p) * 0.65 + valueNoise(p * 2.3 + 17.7) * 0.35;
}

void main() {
    float vl = 1.0;
    float distN = 1.0;
    float mistAcc = 0.0;
    vec3 gi = vec3(0.0);

    #if defined(VOLUMETRIC_LIGHT) || defined(GI)
    // Seul le quart bas-gauche travaille (quart de résolution effectif)
    if (texcoord.x < 0.502 && texcoord.y < 0.502) {
        vec2 uv = min(texcoord * 2.0, vec2(0.9995));
        float depth = texture2D(depthtex0, uv).r;

        vec4 ndc = vec4(uv, depth, 1.0) * 2.0 - 1.0;
        vec4 vp = gbufferProjectionInverse * ndc;
        vec3 playerPos = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;
        float dist = length(playerPos);
        vec3 dir = playerPos / dist;

        // Dither TEMPOREL (suite du nombre d'or) : il change chaque frame,
        // le TAA le moyenne — un dither statique laissait un grain figé
        // très visible à l'intérieur de la nappe
        float dither = fract(hash12(gl_FragCoord.xy)
                + float(frameCounter - (frameCounter / 64) * 64) * 0.6180339887);

        // === GI (RSM) : UN REBOND de lumière du soleil ===
        // Chaque texel ÉCLAIRÉ de la shadow map est une petite lampe
        // (albedo = shadowcolor0, normale = shadowcolor1). On intègre un
        // disque de lampes autour du pixel : un mur rouge au soleil teinte
        // le sol à côté, une prairie verdit le pied des troncs.
        #ifdef GI
        if (depth < 1.0) {
            vec3 nView = octDecode(texture2D(colortex2, uv).rg);
            vec3 nWorld = normalize(mat3(gbufferModelViewInverse) * nView);
            vec3 nS = mat3(shadowModelView) * nWorld;
            vec3 recvS = (shadowModelView * vec4(playerPos, 1.0)).xyz;
            float p22g = shadowProjection[2].z;
            float p32g = shadowProjection[3].z;

            float rot = dither * 6.2831853;
            for (int i = 0; i < GI_SAMPLES; i++) {
                float fi = float(i) + 0.5;
                float rr = GI_RADIUS * sqrt(fi / float(GI_SAMPLES));
                float aa = fi * 2.3999632 + rot;
                vec3 tapS = recvS + vec3(cos(aa) * rr, sin(aa) * rr, 0.0);
                vec4 tc = shadowProjection * vec4(tapS, 1.0);
                vec3 td = distortShadowClip(tc.xyz) * 0.5 + 0.5;
                if (td.x <= 0.001 || td.x >= 0.999
                 || td.y <= 0.001 || td.y >= 0.999) continue;
                float dsm = texture2D(shadowtex0, td.xy).r;
                // z stocké = clip distordu (z ayant subi *0.5) -> on défait
                float zS = ((dsm * 2.0 - 1.0) * 2.0 - p32g) / p22g;
                vec3 vpl = vec3(tapS.xy, zS);
                vec3 w = recvS - vpl;
                float d2 = dot(w, w);
                vec3 wn = w * inversesqrt(max(d2, 0.01));
                vec3 nvpl = texture2D(shadowcolor1, td.xy).rgb * 2.0 - 1.0;
                nvpl = mat3(shadowModelView) * nvpl;
                // (face au soleil, +z en vue ombre) x (émet vers le
                // récepteur) x (le récepteur y fait face)
                float form = max(nvpl.z, 0.0)
                           * max(dot(nvpl, wn), 0.0)
                           * max(dot(nS, -wn), 0.0);
                if (form <= 0.0) continue;
                vec3 alb = texture2D(shadowcolor0, td.xy).rgb;

                // VITRAUX : un verre teinté au soleil est une LAMPE, pas
                // une surface qui rebondit — il RAYONNE sa couleur dans la
                // pièce (le bleu bave sur les murs autour de la tache).
                // Détection : shadowtex1 (opaques) est PLUS LOIN que
                // shadowtex0 (tout) -> ce texel est un translucide éclairé.
                float dOp = texture2D(shadowtex1, td.xy).r;
                float glass = smoothstep(0.0002, 0.0020, dOp - dsm);
                // une lampe émet dans TOUTES les directions : le terme de
                // cosinus du VPL est relâché, et la couleur est amplifiée
                float gain = 1.0 + glass * 5.0;
                float formG = mix(form,
                                  max(dot(nS, -wn), 0.0) * max(nvpl.z, 0.0),
                                  glass);
                gi += (alb * alb) * (formG * gain / (d2 + 0.8)); // alb² ~ linéaire
            }
            float sunHg = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition).y;
            gi *= getShadowLightColor(sunHg, rainStrength)
                * (GI_RADIUS * GI_RADIUS / float(GI_SAMPLES)) * 0.10 * GI_STRENGTH;
            // compression douce : pas d'explosion HDR au ras des surfaces
            gi = gi / (1.0 + gi * 0.25);
            if (!(gi.x == gi.x) || !(gi.y == gi.y) || !(gi.z == gi.z)) gi = vec3(0.0);
        }
        #endif

        #ifdef VOLUMETRIC_LIGHT
        float maxDist = min(dist, 48.0);
        float acc = 0.0;
        for (int i = 0; i < VL_SAMPLES; i++) {
            float tt = (float(i) + dither) / float(VL_SAMPLES) * maxDist;
            vec3 sp = dir * tt;
            vec4 sc = shadowProjection * (shadowModelView * vec4(sp, 1.0));
            vec3 spos = distortShadowClip(sc.xyz) * 0.5 + 0.5;
            if (spos.x > 0.0 && spos.x < 1.0 && spos.y > 0.0 && spos.y < 1.0) {
                acc += sampleShadowmap(spos.xy, spos.z - 0.0008);
            } else {
                acc += 1.0;
            }
        }
        vl = acc / float(VL_SAMPLES);
        // Dimensions sans soleil : matrices d'ombre invalides -> NaN
        if (!(vl == vl)) vl = 1.0;
        distN = maxDist / 48.0;

        // === NAPPE LOURDE : une mer de brouillard qui noie les vallées ===
        // Couche dense entre ~58 et ~80, sommet ondulant sculpté par le
        // bruit — les collines émergent, les creux sont engloutis.
        // Vraie transmittance : jusqu'à ~95 % opaque. Dark fantasy violent.
        #ifdef HEAVY_FOG
        {
            // La nuit, la mer DÉVORE : plus haute, trois fois plus dense
            float sunH = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition).y;
            float nightK = 1.0 - smoothstep(0.0, 0.15, sunH);

            // La nappe suit la TERRE, mais reste NETTEMENT sous le regard :
            // depuis une crête, la mer remplit les vallées sans engloutir la
            // vue (v2.2.1 : -11 suivait trop la caméra, tout le contrebas
            // était noyé — "les gens ne voient rien")
            float baseLevel = max(63.0, cameraPosition.y - 26.0);
            float layerTopMax = baseLevel + 11.0 + nightK * 5.0;

            // Écrêtage analytique : si le rayon monte, il SORT de la nappe
            // à une distance connue — on ne marche que ce segment (regarder
            // le ciel ne coûte presque rien)
            float mMax = min(dist, 96.0);
            if (dir.y > 0.02) {
                float exitT = (layerTopMax + 2.0 - cameraPosition.y) / dir.y;
                mMax = min(mMax, max(exitT, 0.0));
            }

            if (mMax > 1.0) {
                float T = 1.0;
                float stepLen = mMax / 6.0;
                for (int i = 0; i < 6; i++) {
                    if (T < 0.03) break; // saturé : inutile de continuer
                    float tt = (float(i) + dither) / 6.0 * mMax;
                    vec3 wp = cameraPosition + dir * tt;
                    float hN = fogNoise(wp.xz * 0.012
                            + vec2(frameTimeCounter * 0.008, frameTimeCounter * 0.003));
                    float top = baseLevel + hN * 11.0 + nightK * 5.0;
                    float inLayer = smoothstep(top, top - 8.0, wp.y);
                    // Le champ proche reste lisible : la nappe se lève au loin
                    float nearFade = smoothstep(3.0, 18.0, tt);
                    // Rouleaux internes en bruit simple (contraste doux)
                    float dens = inLayer * nearFade * (0.70 + 0.30 * valueNoise(wp.xz * 0.030
                            - vec2(frameTimeCounter * 0.010, 0.0)));
                    T *= exp(-dens * (0.030 + 0.036 * nightK) * stepLen);
                }
                mistAcc = 1.0 - T;
                if (!(mistAcc == mistAcc)) mistAcc = 0.0;
            }
        }
        #else
        // Brume volumétrique douce : bancs de densité marchés le long du
        // rayon — profondeur réelle, dérive lente
        #ifdef DRIFTING_MIST
        {
            float mMax = min(dist, 36.0);
            for (int i = 0; i < 6; i++) {
                float tt = (float(i) + dither) / 6.0 * mMax;
                vec3 wp = cameraPosition + dir * tt;
                float hFall = exp(-max(wp.y - 63.0, 0.0) / 9.0);
                float bank = fbm(wp.xz * 0.02
                        + vec2(frameTimeCounter * 0.013, frameTimeCounter * 0.005)
                        + wp.y * 0.05);
                mistAcc += hFall * smoothstep(0.35, 0.75, bank);
            }
            mistAcc = mistAcc / 6.0 * (1.0 - exp(-mMax * 0.05));
            if (!(mistAcc == mistAcc)) mistAcc = 0.0;
        }
        #endif
        #endif
        #endif // VOLUMETRIC_LIGHT (marche VL + brouillards)
    }
    #endif

/* DRAWBUFFERS:61 */
    gl_FragData[0] = vec4(vl, distN, mistAcc, 1.0);
    // colortex1 (libre jusqu'au bloom) : l'irradiance GI demi-résolution
    gl_FragData[1] = vec4(gi, 1.0);
}

#version 120

// Entités : mobs, joueurs, item frames...

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);

    vec4 shadowSample = playerPos;
    shadowSample.xyz += (mat3(gbufferModelViewInverse) * normalV) * 0.06;
    shadowPos = shadowProjection * (shadowModelView * shadowSample);
    vertDist = length(playerPos.xyz);
}

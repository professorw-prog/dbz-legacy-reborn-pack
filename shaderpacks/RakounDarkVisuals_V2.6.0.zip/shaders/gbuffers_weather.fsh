#version 120

// PLUIE 2.0 : la texture vanilla est remplacée par des GOUTTES
// procédurales — des stries fines qui FILENT vers le sol, inclinées
// par le vent (cisaillement au vertex), et surtout ÉCLAIRÉES par la
// lumière locale : la pluie devient DORÉE près des lanternes, argentée
// sous la lune, presque invisible dans le noir. La neige garde son
// rendu vanilla, juste raccordée à notre éclairage.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldPosV;
varying float gustV;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.01) discard;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    // Lumière LOCALE (même recette que les particules) : c'est elle qui
    // rend la pluie visible — dorée aux lanternes, sombre dans la nuit
    vec3 light = getShadowLightColor(sunH, rainStrength) * smoothstep(0.7, 0.95, lmcoord.y) * 0.35
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y) * 1.4
               + getTorchLight(lmcoord.x) * torchFlicker(frameTimeCounter) * 1.6
               + CAVE_AMBIENT;

    // rain.png est BLEUTÉE (b >> r), snow.png est blanche : on distingue
    // la précipitation au texel — le shader reste unique pour les deux
    bool isSnow = tex.r > tex.b - 0.03;

    vec3 color;
    float alpha;

    if (isSnow) {
        // Neige : flocons vanilla, mais dans NOTRE éclairage
        color = srgbToLinear(tex.rgb * glcolor.rgb) * light * 1.3;
        alpha = tex.a * glcolor.a * 0.85;
    } else {
        float t = frameTimeCounter;

        // Colonnes de gouttes dans l'espace CISAILLÉ : verticales dans ce
        // repère, donc PENCHÉES à l'écran, exactement comme la géométrie
        float u = worldPosV.x * 6.31 + worldPosV.z * 9.77;
        float colId = floor(u);
        float rnd = hash12(vec2(colId, 3.7));

        // Une ligne fine au centre de la colonne
        float w = 1.0 - abs(fract(u) - 0.5) * 2.0;
        float thin = smoothstep(0.45, 0.95, w);

        // La goutte FILE vers le bas (vitesse propre par colonne),
        // trainée qui s'estompe derrière la tête
        float fall = fract(worldPosV.y * (0.16 + rnd * 0.10)
                         + t * (1.9 + rnd * 0.9) + rnd * 11.0);
        float dash = smoothstep(0.72, 0.30, fall) * smoothstep(0.02, 0.16, fall);

        // Des colonnes vides (la pluie n'est pas un rideau uniforme),
        // densité qui suit l'intensité de l'averse et les bourrasques
        float active = step(0.30, hash12(vec2(colId, 17.3)));
        alpha = thin * dash * active
              * (0.30 + 0.45 * rnd)
              * (0.45 + 0.55 * rainStrength)
              * (0.75 + 0.25 * gustV);

        // Teinte froide de l'eau × lumière locale : la pluie N'ÉMET pas,
        // elle REFLÈTE — près d'une lanterne elle s'embrase en doré
        color = light * vec3(0.55, 0.65, 0.80) * 1.35;
    }

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, alpha);
}

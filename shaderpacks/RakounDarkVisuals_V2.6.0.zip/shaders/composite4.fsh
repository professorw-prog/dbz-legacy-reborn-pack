#version 120

// Bloom, passe 2 : flou vertical — dans le quart bas-gauche de colortex1
// (le bloom vit en quart de résolution depuis composite3).

#include "/lib/settings.glsl"

uniform sampler2D colortex1;
uniform float viewHeight;

varying vec2 texcoord;

void main() {
    if (texcoord.x > 0.502 || texcoord.y > 0.502) {
/* DRAWBUFFERS:1 */
        gl_FragData[0] = vec4(0.0);
        return;
    }

    // 1 texel du coin = 2 px écran : ce pas vaut ~3 px écran une fois agrandi
    vec2 px = vec2(0.0, 1.5 / viewHeight);
    // Ne jamais lire hors du quart utile (au-delà : noir)
    float topClamp = 0.5 - 1.0 / viewHeight;

    vec3 bloom = texture2D(colortex1, texcoord).rgb * 0.227;
    bloom += (texture2D(colortex1, vec2(texcoord.x, min(texcoord.y + px.y, topClamp))).rgb
            + texture2D(colortex1, texcoord - px).rgb) * 0.194;
    bloom += (texture2D(colortex1, vec2(texcoord.x, min(texcoord.y + px.y * 2.0, topClamp))).rgb
            + texture2D(colortex1, texcoord - px * 2.0).rgb) * 0.121;
    bloom += (texture2D(colortex1, vec2(texcoord.x, min(texcoord.y + px.y * 3.0, topClamp))).rgb
            + texture2D(colortex1, texcoord - px * 3.0).rgb) * 0.054;
    bloom += (texture2D(colortex1, vec2(texcoord.x, min(texcoord.y + px.y * 4.0, topClamp))).rgb
            + texture2D(colortex1, texcoord - px * 4.0).rgb) * 0.016;

/* DRAWBUFFERS:1 */
    gl_FragData[0] = vec4(bloom, 1.0);
}

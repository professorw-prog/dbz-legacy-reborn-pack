#version 120

// Ciel : dégradé + étoiles vanilla.

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

uniform mat4 gbufferModelViewInverse;

varying vec4 starData; // rgb = couleur d'étoile, a = 1.0 si étoile
varying vec3 playerDir;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;

    // Les étoiles vanilla sont dessinées avec une couleur grise uniforme
    starData = vec4(gl_Color.rgb,
                    float(gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0));

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    playerDir = mat3(gbufferModelViewInverse) * viewPos.xyz;
}

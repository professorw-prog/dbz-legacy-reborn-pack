#version 120

// Passe atmosphérique principale :
//  - nuages volumétriques (pixels de ciel)
//  - reflets écran (SSR) sur l'eau et le verre
//  - caustiques sous-marines
//  - brouillard de distance + brume au sol + fog sous-marin
//  - lumière volumétrique (raymarch de la shadow map)

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA16F;
const bool colortex3Clear = false;
const int colortex4Format = RGBA16F;
const bool colortex4Clear = false;
const int colortex5Format = RGBA16F;
const bool colortex5Clear = false;
const int colortex6Format = RGBA16;
const int colortex7Format = RGBA8;
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"
#include "/lib/shadows.glsl"
#include "/lib/water.glsl"
#include "/lib/blackhole.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex;
uniform sampler2D dhDepthTex1;
uniform mat4 dhProjectionInverse;
uniform int dhRenderDistance;
uniform float far;
#endif
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform int isEyeInWater;
uniform int moonPhase;
uniform int frameCounter;

varying vec2 texcoord;

vec3 reconstructPlayer(vec2 uv, float d) {
    vec4 ndc = vec4(uv, d, 1.0) * 2.0 - 1.0;
    vec4 vp = gbufferProjectionInverse * ndc;
    return (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;
}

// ====================================================================
//  CIEL PROFOND : le Trou Noir (jour et nuit), la voie lactée (nuit),
//  le halo de lune. Directions FIXES : des repères permanents du monde.
// ====================================================================

vec3 deepSky(vec3 color, vec3 dir, vec3 sunDirW, float day, float rain) {
    float vis = 1.0 - rain * 0.9;   // la pluie voile le ciel profond
    float night = 1.0 - day;
    float horizonFade = smoothstep(-0.05, 0.12, dir.y);

    // --- LE TROU NOIR (vraie lentille gravitationnelle) : marché EN
    // PREMIER, car il COURBE la direction avec laquelle tout le fond
    // (étoiles, voie lactée, lune) est ensuite échantillonné ---
    float bhTrans = 1.0;
    vec3 bhGlow = vec3(0.0);
    {
        float dith = fract(hash12(gl_FragCoord.xy)
                + float(frameCounter - (frameCounter / 64) * 64) * 0.6180339887);
        dir = blackHoleMarch(dir, normalize(vec3(-0.12, 0.58, -0.85)), 0.15,
                             dith, frameTimeCounter, mix(1.0, 0.75, day) * vis,
                             bhTrans, bhGlow);
    }

    // --- Champ d'étoiles DENSE (nuit) : trois couches, teintes variées ---
    // La poussière de milliers d'étoiles fines, quelques moyennes qui
    // scintillent, de rares brillantes — façon ciel de désert
    {
        vec2 suv = octEncode(dir);
        float s1 = starLayer(suv, 420.0, 0.960, 9.0);        // poussière
        float s2 = starLayer(suv + 3.7, 190.0, 0.972, 7.0);  // moyennes
        float s3 = starLayer(suv + 9.1, 90.0, 0.986, 6.0);   // brillantes
        float tvar = hash12(floor(suv * 420.0) + 5.3);
        vec3 sCol = mix(vec3(1.0, 0.82, 0.62), vec3(0.72, 0.82, 1.0), tvar);
        float twinkle = 0.85 + 0.15 * sin(frameTimeCounter * 2.3 + tvar * 40.0);
        color += (s1 * 0.045 + s2 * 0.10 * twinkle + s3 * 0.22)
               * sCol * night * vis * horizonFade;
    }

    // --- Voie lactée : une VRAIE bande continue au zénith (nuit) ---
    {
        vec3 mwNormal = normalize(vec3(0.60, 0.15, 0.78));
        float band = dot(dir, mwNormal);
        // Voile large + coeur dense : la bande reste lisible d'un horizon à l'autre
        float mw = exp(-band * band * 26.0) + exp(-band * band * 110.0) * 0.7;
        vec3 t = normalize(cross(mwNormal, vec3(0.0, 1.0, 0.0)));
        vec3 b2 = cross(mwNormal, t);
        // Paramétrage SPHÉRIQUE (longitude le long de la bande, latitude
        // perpendiculaire) : taille angulaire constante partout — la
        // projection plane d'avant étirait les étoiles en traits loin du
        // centre. La couture de l'atan tombe à l'horizon (t horizontal).
        float lon = atan(dot(dir, b2), dot(dir, t));
        float lat = asin(clamp(band, -1.0, 1.0));
        vec2 buv = vec2(lon, lat) * 3.0;
        // Nuées : base haute (continuité) + poussière discrète en surface
        float cloudy = fbm(buv * 2.2 + 7.3);
        float dust = smoothstep(0.60, 0.80, fbm(buv * 4.1 - 3.7));
        mw *= (0.55 + 0.55 * cloudy) * (1.0 - 0.35 * dust);
        // Micro-étoiles denses dans la bande
        vec2 cell = floor(buv * 140.0);
        vec2 f = fract(buv * 140.0) - 0.5;
        float st = step(0.988, hash12(cell)) * max(0.0, 1.0 - length(f) * 3.0) * mw;
        vec3 mwCol = mix(vec3(0.050, 0.060, 0.095), vec3(0.085, 0.066, 0.058), cloudy);
        color += (mwCol * mw + vec3(0.45, 0.47, 0.55) * st) * night * vis * horizonFade;
    }

    // (Le Trou Noir raymarché est appliqué en FIN de fonction : sa
    // transmittance absorbe tout le fond, sa lueur s'ajoute par-dessus)

    // --- SOLEIL rond (le quad vanilla est désactivé) : disque chaud à
    //     bord adouci, rougi près de l'horizon, un poil plus grand ---
    {
        float srad = 0.058;
        float ang = acos(clamp(dot(dir, sunDirW), -1.0, 1.0));
        float disc = 1.0 - smoothstep(srad * 0.85, srad, ang);
        if (disc > 0.0) {
            float limb = 1.0 - 0.35 * smoothstep(0.0, srad, ang); // bord assombri
            vec3 sunCol = mix(vec3(1.20, 0.42, 0.12), vec3(1.35, 1.18, 0.95),
                              smoothstep(0.02, 0.30, sunDirW.y));
            color = mix(color, sunCol * 6.0 * limb, disc * vis * day);
        }
    }

    // --- LUNE ronde avec VRAIES phases (le quad vanilla est désactivé) ---
    {
        float mrad = 0.046;
        vec3 mdir = -sunDirW;
        vec3 aux = abs(mdir.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
        vec3 t = normalize(cross(mdir, aux));
        vec3 b = cross(mdir, t);
        vec2 p = vec2(dot(dir, t), dot(dir, b)) / mrad;
        float r = length(p);
        if (dot(dir, mdir) > 0.5 && r < 1.5) {
            float disc = 1.0 - smoothstep(0.92, 1.0, r);
            // Phase : un disque d'ombre décalé grignote la lune
            // (moonPhase : 0 = pleine, 4 = nouvelle)
            float dpn = abs(float(moonPhase) - 4.0);
            float mag = dpn / 4.0 * 2.4;
            float side = float(moonPhase) < 4.0 ? 1.0 : -1.0;
            float shadow = 1.0 - smoothstep(1.02, 1.18, length(p - vec2(side * mag, 0.0)));
            float lit = disc * (1.0 - shadow * 0.985);
            // Mers et cratères esquissés
            float mare = 0.80 + 0.28 * valueNoise(p * 3.1 + 11.7);
            vec3 moonCol = vec3(0.78, 0.80, 0.88) * mare;
            // Pleine présence la nuit, fantôme pâle le jour
            color = mix(color, moonCol * 0.9, lit * vis * (0.25 + 0.75 * night));
        }
    }

    // --- Halo de lune : auréole bleu argenté ---
    {
        vec3 moonDir = -sunDirW;
        float md = max(dot(dir, moonDir), 0.0);
        float halo = pow(md, 750.0) * 1.1 + pow(md, 80.0) * 0.16;
        color += vec3(0.50, 0.58, 0.72) * halo * night * vis;
    }

    // --- Application du Trou Noir : le fond (ciel + étoiles + voie
    // lactée + lune, tous lus avec la direction COURBÉE) est absorbé
    // par l'horizon des événements, puis le disque d'accrétion et
    // l'anneau de photons s'ajoutent par-dessus ---
    // L'ATMOSPHÈRE est DEVANT le trou : de jour, la lumière diffusée
    // par l'air VOILE son absorption (comme la lune diurne, délavée) —
    // on ne garde qu'un quart de l'assombrissement sur ciel lumineux,
    // le disque incandescent traverse, lui
    color = color * mix(bhTrans, 1.0, day * 0.75) + bhGlow;

    return color;
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 lightDirW = safeNormalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    float sunH = sunDirW.y;
    float day = dayFactor(sunH);
    float dusk = duskFactor(sunH);

    // Position reconstruite (au far plane pour le ciel : la direction reste valide)
    vec4 ndc = vec4(texcoord, depth, 1.0) * 2.0 - 1.0;
    vec4 vp = gbufferProjectionInverse * ndc;
    vec3 viewPos = vp.xyz / vp.w;
    vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    float dist = length(playerPos);
    vec3 dir = playerPos / dist;

    // === DISTANT HORIZONS (v2.5) : les LOD DH ont leur PROPRE depth
    // buffer (near/far différents). Là où le depth vanilla dit "ciel"
    // mais où DH a de la géométrie, on reconstruit la position avec les
    // matrices DH : le pixel redevient du TERRAIN pour tout le pipeline
    // (fog atmosphérique, mer de brouillard, brume...) au lieu d'être
    // écrasé par le ciel et les nuages.
    #ifdef DISTANT_HORIZONS
    if (depth >= 1.0) {
        // OPAQUE d'abord : dhDepthTex1 = le TERRAIN LOD seul. dhDepthTex
        // contient AUSSI les NUAGES de DH (translucides) — les résoudre
        // comme du terrain peignait un DÔME sombre plein ciel, surtout en
        // mouvement.
        float dhD = texture2D(dhDepthTex1, texcoord).r;
        bool okDH = dhD < 1.0;
        if (!okDH) {
            // translucides DH acceptés seulement SOUS l'oeil : l'eau LOD
            // à l'horizon oui, les nuages au-dessus non
            float dhDw = texture2D(dhDepthTex, texcoord).r;
            if (dhDw < 1.0) {
                vec4 ndcW = vec4(texcoord, dhDw, 1.0) * 2.0 - 1.0;
                vec4 vpW = dhProjectionInverse * ndcW;
                vec3 pW = (gbufferModelViewInverse
                        * vec4(vpW.xyz / vpW.w, 1.0)).xyz;
                if (pW.y < 8.0) { dhD = dhDw; okDH = true; }
            }
        }
        if (okDH) {
            vec4 ndcD = vec4(texcoord, dhD, 1.0) * 2.0 - 1.0;
            vec4 vpD = dhProjectionInverse * ndcD;
            vec3 viewD = vpD.xyz / vpD.w;
            vec3 playerD = (gbufferModelViewInverse * vec4(viewD, 1.0)).xyz;
            float distD = length(playerD);
            // GARDES PHYSIQUES : le vrai terrain DH vit SOUS la hauteur du
            // monde et EN-DEÇÀ de la distance DH — le DÔME de nuages de DH
            // (rendu opaque, présent dans les DEUX depth DH !) est à des
            // kilomètres et à des milliers de blocs d'altitude : rejeté.
            if (distD < float(dhRenderDistance) + 64.0
             && playerD.y + cameraPosition.y < 400.0) {
                viewPos = viewD;
                playerPos = playerD;
                dist = distD;
                dir = playerPos / dist;
                depth = 0.99995;   // plus "ciel" : chemins géométrie
            }
        }
    }
    #endif

    // === Ciel profond : voie lactée, planètes, trou noir, halo de lune ===
    // (dessiné AVANT les nuages : ils passent devant)
    #ifdef DEEP_SKY
    if (depth >= 1.0 && isEyeInWater == 0) {
        color = deepSky(color, dir, sunDirW, day, rainStrength);
    }
    #endif

    // === Nuages volumétriques (pixels de ciel) ===
    #ifdef VOLUMETRIC_CLOUDS
    if (depth >= 1.0 && dir.y > 0.01 && isEyeInWater == 0) {
        float fade = smoothstep(0.02, 0.15, dir.y);
        float cover = 0.50 + 0.26 * rainStrength;

        vec3 cloudShade = mix(vec3(0.0008, 0.0010, 0.0021) * NIGHT_BRIGHTNESS,
                              vec3(0.030, 0.033, 0.042), day);
        // Nuit : nuages baignés de lune, argentés (référence "clair de lune")
        vec3 cloudLit   = mix(vec3(0.0060, 0.0080, 0.0150) * NIGHT_BRIGHTNESS,
                              vec3(0.105, 0.115, 0.140), day);
        // Couchant : les nuages s'embrasent en rose pêche
        cloudLit = mix(cloudLit, vec3(0.50, 0.14, 0.10), dusk * 0.9);

        // Ciel d'orage : gris couvert, mais VIVANT — la dalle garde des
        // nuances internes (bancs plus clairs / plus denses) au lieu du
        // couvercle noir uniforme qui tuait l'ambiance (retour joueurs)
        vec3 overcast = mix(vec3(0.0036, 0.0045, 0.0068) * NIGHT_BRIGHTNESS,
                            vec3(0.078, 0.082, 0.092), day);
        cloudShade = mix(cloudShade, overcast * 0.62, rainStrength);
        cloudLit   = mix(cloudLit,   overcast * 1.45, rainStrength);

        // Deux couches pour la parallaxe (la plus haute d'abord)
        for (int L = 1; L >= 0; L--) {
            float h = 165.0 + float(L) * 25.0;
            if (cameraPosition.y < h - 5.0) {
                vec2 cp = cameraPosition.xz + dir.xz / max(dir.y, 0.05) * (h - cameraPosition.y);
                // Dérive lente (~3 blocs/s), en unités monde AVANT la mise à l'échelle
                vec2 wind = vec2(frameTimeCounter * 3.0, frameTimeCounter * 0.9);
                float n = fbm((cp + wind) * 0.0035 + float(L) * 39.7);
                // Sous l'orage, la bande de transition s'élargit : le ciel
                // couvert respire en dégradés au lieu de saturer à 100%
                float band = 0.30 + 0.35 * rainStrength;
                float cd = smoothstep(1.0 - cover, 1.0 - cover + band, n);
                if (cd > 0.0) {
                    // Les bords fins restent lumineux, le coeur est sombre
                    vec3 cCol = mix(cloudLit, cloudShade, cd);
                    // Liseré backlit : les bords s'embrasent face au soleil
                    // — sous la pluie il vire à l'ARGENT et survit à 45% :
                    // le soleil se devine derrière la masse (percées)
                    float rim = cd * (1.0 - cd) * 4.0;
                    float toSun = pow(max(dot(dir, sunDirW), 0.0), 6.0);
                    vec3 rimCol = mix(vec3(0.90, 0.35, 0.12),
                                      vec3(0.55, 0.58, 0.66), rainStrength);
                    cCol += rimCol * rim * toSun
                          * (0.20 + 1.20 * dusk * (1.0 - rainStrength))
                          * (1.0 - 0.55 * rainStrength);
                    color = mix(color, cCol, cd * fade * 0.95);
                }
            }
        }
    }
    #endif

    if (depth < 1.0) {
        // === Fondu procédural entre blocs ===
        // Près d'un joint entre deux blocs coplanaires, on fond la couleur
        // avec celle du bloc voisin (point miroir de l'autre côté du joint).
        // La largeur varie par du bruit propre à chaque joint : la frontière
        // herbe/chemin devient organique et jamais répétitive. Les angles de
        // murs et marches restent nets (test de coplanarité par profondeur).
        #ifdef BLOCK_BLENDING
        if (dist < 48.0) {
            vec4 bdata = texture2D(colortex2, texcoord);
            // Exclut l'eau (1.0) et le verre (0.6) mais PAS le sol mouillé
            // (masque <= 0.45), sinon le fondu disparaît sous la pluie
            if (bdata.a < 0.55) {
                vec3 nW = normalize(mat3(gbufferModelViewInverse) * octDecode(bdata.rg));
                vec3 wpos = playerPos + cameraPosition;

                // Axes tangents à la face
                vec3 t1, t2;
                if (abs(nW.y) > 0.7)      { t1 = vec3(1.0, 0.0, 0.0); t2 = vec3(0.0, 0.0, 1.0); }
                else if (abs(nW.x) > 0.7) { t1 = vec3(0.0, 0.0, 1.0); t2 = vec3(0.0, 1.0, 0.0); }
                else                      { t1 = vec3(1.0, 0.0, 0.0); t2 = vec3(0.0, 1.0, 0.0); }

                float m22b = gbufferProjection[2].z;
                float m32b = gbufferProjection[3].z;

                // Plein effet sur les sols ; discret sur les murs, où
                // l'architecture (encadrements, poutres) doit rester nette
                float faceK = (abs(nW.y) > 0.7) ? 1.0 : 0.4;

                for (int ax = 0; ax < 2; ax++) {
                    vec3 a = (ax == 0) ? t1 : t2;
                    vec3 b = (ax == 0) ? t2 : t1;
                    float c = dot(wpos, a);
                    float joint = floor(c + 0.5);  // joint le plus proche
                    float sd = joint - c;          // distance signée au joint
                    float dEdge = abs(sd);

                    // Largeur de transition irrégulière, propre à ce joint
                    // (plafonnée sous 0.5 : le point miroir doit rester dans
                    // le bloc voisin)
                    float w = clamp((0.14 + 0.40 * valueNoise(vec2(joint * 3.7, dot(wpos, b) * 1.9))) * BLEND_WIDTH * faceK, 0.04, 0.45);

                    if (dEdge < w && dEdge > 0.001) {
                        // Point miroir de l'autre côté du joint
                        vec3 nbPlayer = wpos + a * (2.0 * sd) - cameraPosition;
                        vec3 nbView = (gbufferModelView * vec4(nbPlayer, 1.0)).xyz;
                        vec4 nbClip = gbufferProjection * vec4(nbView, 1.0);
                        if (nbClip.w > 0.0) {
                            vec3 nbS = nbClip.xyz / nbClip.w * 0.5 + 0.5;
                            if (nbS.x > 0.0 && nbS.x < 1.0 && nbS.y > 0.0 && nbS.y < 1.0) {
                                // Le voisin doit être visible et coplanaire
                                float dExp = m32b / (nbS.z * 2.0 - 1.0 + m22b);
                                float dAct = m32b / (texture2D(depthtex0, nbS.xy).r * 2.0 - 1.0 + m22b);
                                if (abs(dExp - dAct) / max(abs(dAct), 0.1) < 0.03) {
                                    float bw = 0.5 * faceK * (1.0 - dEdge / w);
                                    vec3 nc = texture2D(colortex0, nbS.xy).rgb;
                                    float lumS = max(luminance(color), 0.005);
                                    float lumN = max(luminance(nc), 0.005);

                                    // Le fondu n'agit qu'entre MATIÈRES différentes :
                                    // ton différent (chroma) OU écart de luminance
                                    // franc (basalt vs pierre). Un dégradé d'ombre
                                    // douce sur une même matière (même ton, écart
                                    // faible) ne déclenche rien -> plus de lignes de
                                    // Mach le long des joints sur les pelouses.
                                    float chromaDiff = length(color / lumS - nc / lumN);
                                    float lumRatio = max(lumS, lumN) / min(lumS, lumN);
                                    float matDiff = clamp(smoothstep(0.05, 0.15, chromaDiff)
                                                        + smoothstep(1.35, 1.8, lumRatio), 0.0, 1.0);
                                    bw *= matDiff;

                                    // Et l'excès de luminance (ombres x4-6) reste
                                    // renormalisé dans une bande de matière plausible
                                    float target = clamp(lumN, lumS / 2.2, lumS * 2.2);
                                    nc *= target / lumN;
                                    color = mix(color, nc, bw);
                                }
                            }
                        }
                    }
                }
            }
        }
        #endif

        // === Remontée du sol sur la base des blocs posés ===
        // Au pied des faces verticales, la couleur du sol adjacent grimpe
        // sur une hauteur irrégulière (bruit) : l'herbe monte sur les
        // poteaux, la terre salit les murs — les blocs ont l'air POSÉS.
        #ifdef GROUND_CREEP
        if (dist < 32.0) {
            vec4 gdata = texture2D(colortex2, texcoord);
            if (gdata.a < 0.55) {
                vec3 nWg = normalize(mat3(gbufferModelViewInverse) * octDecode(gdata.rg));
                if (abs(nWg.y) < 0.4) { // face verticale
                    vec3 wposG = playerPos + cameraPosition;
                    float yAbove = fract(wposG.y); // hauteur au-dessus du joint bas

                    // hauteur de remontée, irrégulière le long du mur
                    float hC = 0.06 + 0.34 * valueNoise(wposG.xz * 3.1 + floor(wposG.y + 0.5) * 7.3);

                    if (yAbove < hC) {
                        // point du sol adjacent, au pied du mur
                        vec3 gPos = vec3(wposG.x, floor(wposG.y) + 0.03, wposG.z) + nWg * 0.35;
                        vec3 gView = (gbufferModelView * vec4(gPos - cameraPosition, 1.0)).xyz;
                        vec4 gClip = gbufferProjection * vec4(gView, 1.0);
                        if (gClip.w > 0.0) {
                            vec3 gS = gClip.xyz / gClip.w * 0.5 + 0.5;
                            if (gS.x > 0.0 && gS.x < 1.0 && gS.y > 0.0 && gS.y < 1.0) {
                                float m22g = gbufferProjection[2].z;
                                float m32g = gbufferProjection[3].z;
                                float dExpG = m32g / (gS.z * 2.0 - 1.0 + m22g);
                                float dActG = m32g / (texture2D(depthtex0, gS.xy).r * 2.0 - 1.0 + m22g);
                                // le sol doit être visible là où on l'échantillonne
                                if (abs(dExpG - dActG) / max(abs(dActG), 0.1) < 0.06) {
                                    vec3 gc = texture2D(colortex0, gS.xy).rgb;
                                    // Seule la VÉGÉTATION grimpe (dominance verte) :
                                    // l'herbe et la mousse remontent, pas la pierre
                                    float greenish = clamp((gc.g - max(gc.r, gc.b)) * 6.0, 0.0, 1.0);
                                    if (greenish > 0.01) {
                                        float lumSg = luminance(color);
                                        float lumNg = max(luminance(gc), 0.005);
                                        float targetG = clamp(lumNg, lumSg / 2.2, lumSg * 2.2);
                                        gc *= targetG / lumNg;
                                        float wCreep = smoothstep(hC, hC * 0.25, yAbove) * 0.85 * greenish;
                                        color = mix(color, gc, wCreep);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endif

        // === GI : la lumière REBONDIT (un rebond RSM) ===
        // L'irradiance indirecte est intégrée en demi-résolution dans
        // deferred (coin bas-gauche de colortex1) ; upsample bilatéral
        // guidé par la distance (colortex6.g, même grille), appliqué sur
        // l'ALBEDO plein-res (colortex7) : les couleurs de rebond restent
        // nettes au pixel. Avant le GTAO : l'occlusion assombrit aussi
        // la lumière rebondie.
        #if defined(GI) && defined(VOLUMETRIC_LIGHT)
        {
            vec3 albG = texture2D(colortex7, texcoord).rgb; // déjà linéaire
            if (albG.r + albG.g + albG.b > 0.002) {
                float refDg = min(dist, 48.0) / 48.0;
                vec2 pxg = vec2(1.0 / viewWidth, 1.0 / viewHeight);
                vec2 halfUVg = min(texcoord * 0.5, vec2(0.4995));
                vec3 giAcc = vec3(0.0);
                float wSumG = 0.0;
                for (int oy = 0; oy <= 1; oy++) {
                    for (int ox = 0; ox <= 1; ox++) {
                        vec2 suv = min(halfUVg + vec2(float(ox), float(oy)) * pxg,
                                       vec2(0.5) - pxg * 0.5);
                        float sd = texture2D(colortex6, suv).g;
                        float w = exp(-abs(sd - refDg) * 24.0) + 1e-4;
                        giAcc += texture2D(colortex1, suv).rgb * w;
                        wSumG += w;
                    }
                }
                color += (giAcc / wSumG) * albG;
            }
        }
        #endif

        // (Lumière colorée : appliquée dans final.fsh — le BLOOM y sert de
        // champ d'émetteurs : extraction seuillée AVANT flou, gaussienne
        // large, couleur des sources préservée, stabilisé par le TAA.)

        // === GTAO : occlusion ambiante par HORIZONS (ex-SSAO) ===
        // Pour chaque tranche autour du pixel, on cherche l'angle
        // d'horizon des deux côtés puis on intègre l'arc de ciel VISIBLE
        // pondéré cosinus autour de la normale — contacts nets, coins
        // vraiment creusés, plus de gris plat. L'angle tourne chaque
        // frame (nombre d'or) : le TAA moyenne le bruit.
        #ifdef SSAO
        if (dist < 80.0) {
            float m22s = gbufferProjection[2].z;
            float m32s = gbufferProjection[3].z;
            float p00 = gbufferProjection[0].x;
            float p11 = gbufferProjection[1].y;

            // Normale géométrique par dérivées écran : valable pour TOUT
            // pixel (terrain, entités, particules), aucun buffer requis
            vec3 nv = normalize(cross(dFdx(viewPos), dFdy(viewPos)));
            if (dot(nv, viewPos) > 0.0) nv = -nv;
            vec3 vd = -normalize(viewPos);

            // Rayon monde ~1.6 bloc projeté à l'écran (borné) ; l'aspect
            // isotropise les offsets uv -> la direction vue est (om, 0)
            float radUV = clamp(0.8 / dist, 0.004, 0.08);
            vec2 aspect = vec2(viewHeight / viewWidth, 1.0);

            float angJ = fract(hash12(gl_FragCoord.xy + 0.37)
                    + float(frameCounter - (frameCounter / 64) * 64) * 0.6180339887);
            float stepJ = fract(angJ * 7.13);

            float visSum = 0.0;
            for (int s = 0; s < 2; s++) {
                float phi = (angJ + float(s) * 0.5) * 3.14159265;
                vec2 om = vec2(cos(phi), sin(phi));

                // Cos des horizons de part et d'autre (h1 : +om, h2 : -om)
                float h1 = -1.0;
                float h2 = -1.0;
                for (int j = 1; j <= 4; j++) {
                    float sc = (float(j) - 1.0 + stepJ) * 0.25 + 0.08;
                    vec2 offUV = om * (radUV * sc) * aspect;
                    for (int side = 0; side < 2; side++) {
                        vec2 suv = texcoord + (side == 0 ? offUV : -offUV);
                        float dsm = texture2D(depthtex0, suv).r;
                        float zs = -m32s / (dsm * 2.0 - 1.0 + m22s);
                        vec2 ndcS = suv * 2.0 - 1.0;
                        vec3 sview = vec3(ndcS.x * (-zs) / p00,
                                          ndcS.y * (-zs) / p11, zs);
                        vec3 dvec = sview - viewPos;
                        float dl = length(dvec);
                        float ch = dot(dvec / max(dl, 1e-5), vd);
                        // au-delà du rayon, l'occulteur s'estompe (les
                        // objets lointains n'occluent pas le contact)
                        ch = mix(ch, -1.0, clamp((dl - 1.6) / 1.6, 0.0, 1.0));
                        if (side == 0) h1 = max(h1, ch);
                        else           h2 = max(h2, ch);
                    }
                }

                // Normale projetée dans le plan de la tranche
                vec3 dirV = vec3(om, 0.0);
                vec3 axis = normalize(cross(dirV, vd));
                vec3 projN = nv - axis * dot(nv, axis);
                float pl = length(projN);
                if (pl > 1e-4) {
                    vec3 pn = projN / pl;
                    float cosN = clamp(dot(pn, vd), -1.0, 1.0);
                    vec3 ortho = dirV - vd * dot(dirV, vd);
                    float gam = sign(dot(pn, ortho)) * acos(cosN);

                    float t2 = acos(clamp(h1, -1.0, 1.0));  // côté +om
                    float t1 = -acos(clamp(h2, -1.0, 1.0)); // côté -om
                    // horizons bornés à l'hémisphère de la normale
                    t1 = gam + max(t1 - gam, -1.5707963);
                    t2 = gam + min(t2 - gam, 1.5707963);
                    // intégrale d'arc pondérée cosinus (formule GTAO)
                    float sinG = sin(gam);
                    float cosG = cos(gam);
                    float arc = 0.25 * (
                        (-cos(2.0 * t1 - gam) + cosG + 2.0 * t1 * sinG) +
                        (-cos(2.0 * t2 - gam) + cosG + 2.0 * t2 * sinG));
                    visSum += pl * clamp(arc, 0.0, 1.0);
                }
            }
            float vis = clamp(visSum * 0.5, 0.0, 1.0);
            float occ = 1.0 - vis;
            if (!(occ == occ)) occ = 0.0; // garde NaN (bords, ciel)
            color *= 1.0 - occ * 0.75 * SSAO_STRENGTH;
        }
        #endif

        vec4 wdata = texture2D(colortex2, texcoord);

        // GARDE GÉNÉRIQUE MAIN/OBJETS TENUS : depthtex2 = profondeur SANS
        // la main. Si elle diffère de depthtex0, ce pixel appartient à la
        // main ou à l'objet tenu (peu importe son programme de rendu —
        // items moddés GeckoLib, glint d'enchantement, tout) : le masque
        // de reflets vient du terrain DERRIÈRE -> on l'annule.
        // (bug « wet surfaces glitch through the arm », ChaosMeli23)
        if (abs(texture2D(depthtex2, texcoord).r - depth) > 1e-7) {
            wdata.a = 0.0;
        }

        // === Reflets écran (masque : 1.0 = eau, 0.6 = verre) ===
        #ifdef WATER_REFLECTIONS
        if (wdata.a > 0.4 && isEyeInWater == 0) {
            vec3 n = octDecode(wdata.rg);

            vec3 vDir = normalize(viewPos);
            // NB : pas de jitter aléatoire ici — sans TAA pour moyenner,
            // un bruit par pixel dissout le reflet en poussière
            vec3 rDir = normalize(reflect(vDir, n));
            float fres = pow(1.0 - clamp(dot(-vDir, n), 0.0, 1.0), 3.0);
            // Réflectivité selon le masque : eau/verre = pleine ; sol mouillé
            // = décodé de la plage 0.40-0.54 (pierre miroir, bois discret)
            // Base relevée : du reflet même en plongée (fresnel faible) —
            // l'eau claire vit par ses reflets, pas par sa couleur
            // v2.4.1 : eau CRISTALLINE — en plongée on voit le FOND (base
            // basse), le miroir monte vite en rasant (fresnel 0.95) et le
            // "shiny" de KeanyKM vit dans le glint + le rasant. Bande MÉTAL
            // (0.70-0.80, auto-PBR) : un métal reflète même DE FACE
            bool metalM = wdata.a > 0.70 && wdata.a < 0.80;
            float reflBase = (wdata.a > 0.8) ? 0.18 : (metalM ? 0.45 : 0.20);
            float reflWeight = (reflBase + (0.95 - reflBase) * fres)
                             * ((wdata.a >= 0.58) ? 1.0 : clamp((wdata.a - 0.40) * 7.0, 0.0, 1.0));

            // Repli : ciel réfléchi (masqué en grotte via l'exposition lightmap)
            vec3 rWorld = normalize(mat3(gbufferModelViewInverse) * rDir);
            vec3 refl = getSkyColor(rWorld, sunDirW, rainStrength) * wdata.b * wdata.b;

            // Meilleur repli : la capture sphérique 360° (ce qu'on a déjà vu
            // dans cette direction, même si c'est sorti de l'écran)
            #ifdef OFFSCREEN_REFLECTIONS
                vec4 cap = texture2D(colortex4, sphereCoord(rWorld));
                refl = mix(refl, cap.rgb, cap.a);
            #endif

            // Marche façon Kappa : le rayon est projeté à l'écran puis
            // parcouru en pas uniformes JUSQU'AU BORD, et l'impact est testé
            // en tolérance RELATIVE (50% de la profondeur) — c'est cette
            // tolérance proportionnelle qui supprime les tranches et les
            // crans dépendant de l'angle de la caméra.
            // NB : la limite de distance couvre tout le terrain visible —
            // une limite courte (64) faisait s'évaporer les reflets du sol
            // lointain dès qu'on levait la tête. Et le seuil de poids doit
            // rester TRÈS bas : à la verticale du joueur le fresnel est
            // faible, un seuil haut dessinait un cercle sans reflets autour
            // de lui.
            if (reflWeight > 0.04 && dist < 320.0) {
                float m22 = gbufferProjection[2].z;
                float m32 = gbufferProjection[3].z;

                vec3 origin = viewPos + n * 0.1;

                // Extrémité lointaine, écrêtée avant le plan proche
                float rayLen = 256.0;
                if (origin.z + rDir.z * rayLen > -0.1)
                    rayLen = (-0.1 - origin.z) / rDir.z;
                vec3 endV = origin + rDir * rayLen;

                vec4 sC = gbufferProjection * vec4(origin, 1.0);
                vec4 eC = gbufferProjection * vec4(endV, 1.0);
                vec3 sS = sC.xyz / sC.w * 0.5 + 0.5;
                vec3 eS = eC.xyz / eC.w * 0.5 + 0.5;

                // Direction écran (xy normalisé), distance jusqu'au bord
                vec3 sDir = eS - sS;
                sDir /= max(length(sDir.xy), 1e-6);
                vec3 toEdge = (step(0.0, sDir) - sS) / sDir;
                float edgeDist = min(min(toEdge.x, toEdge.y), toEdge.z);

                float stepsF = clamp(edgeDist * viewHeight / 6.0, 8.0, float(SSR_STEPS) * 2.0);
                vec3 stepv = sDir * (edgeDist / stepsF);
                vec3 prev = sS;
                vec3 pos = sS + stepv;

                for (int i = 0; i < SSR_STEPS * 2; i++) {
                    if (float(i) >= stepsF) break;
                    if (pos.x < 0.0 || pos.x > 1.0 || pos.y < 0.0 || pos.y > 1.0 || pos.z >= 1.0) {
                        // Extension de bord : si le rayon sort de l'écran en
                        // longeant un objet (pilier, mur...), on étire le
                        // dernier pixel du bord au lieu de couper le reflet.
                        // STRICT : le bord doit être la continuation de la
                        // surface tracée (profondeurs proches) — sinon on
                        // étale du premier plan sans rapport, qui danse
                        // quand la caméra s'incline (vérifié par simulation)
                        vec2 cuv = clamp(pos.xy, vec2(0.002), vec2(0.998));
                        float dEdge = texture2D(depthtex0, cuv).r;
                        float dSEdge = m32 / (dEdge * 2.0 - 1.0 + m22);
                        float dREdge = m32 / (clamp(pos.z, 0.0, 0.9999) * 2.0 - 1.0 + m22);
                        if (dSEdge < dREdge && (dREdge - dSEdge) / dREdge < 0.5) {
                            refl = texture2D(colortex0, cuv).rgb;
                        }
                        break;
                    }

                    float d = texture2D(depthtex0, pos.xy).r;
                    float dRay   = m32 / (pos.z * 2.0 - 1.0 + m22);
                    float dScene = m32 / (d     * 2.0 - 1.0 + m22);

                    // Impact : la scène est devant le rayon, à moins de 50%
                    // de sa profondeur (tolérance relative, comme Kappa)
                    if (dScene < dRay && (dRay - dScene) / dRay < 0.5) {
                        // Raffinement binaire du point de croisement
                        vec3 lo = prev;
                        vec3 hi = pos;
                        for (int j = 0; j < 4; j++) {
                            vec3 mid = (lo + hi) * 0.5;
                            float md = texture2D(depthtex0, mid.xy).r;
                            float mR = m32 / (mid.z * 2.0 - 1.0 + m22);
                            float mS = m32 / (md    * 2.0 - 1.0 + m22);
                            if (mS < mR) hi = mid;
                            else lo = mid;
                        }
                        float edge = clamp(min(min(hi.x, 1.0 - hi.x), min(hi.y, 1.0 - hi.y)) * 8.0, 0.0, 1.0);
                        refl = mix(refl, texture2D(colortex0, hi.xy).rgb, edge);
                        break;
                    }
                    prev = pos;
                    pos += stepv;
                }
            }

            // Le MÉTAL teinte son reflet par son albedo (colortex7) :
            // l'or reflète le monde en doré, le cuivre en roux
            if (metalM) {
                vec3 albM = texture2D(colortex7, texcoord).rgb;
                refl *= albM / max(luminance(albM), 0.08) * 0.9;
            }

            color = mix(color, refl, reflWeight);

            // v2.4 : GLINT solaire/lunaire — l'astre accroche la crête des
            // vagues (normale ondulée) : l'eau ÉTINCELLE au lieu de juste
            // refléter. Masqué en grotte par l'exposition ciel (wdata.b).
            if (wdata.a > 0.8) {
                vec3 lDir = safeNormalize(shadowLightPosition);
                float glint = pow(clamp(dot(rDir, lDir), 0.0, 1.0), 520.0);
                color += getShadowLightColor(sunDirW.y, rainStrength)
                       * glint * 2.4 * (0.35 + 0.65 * fres)
                       * wdata.b * wdata.b;
            }
        }
        #endif

        // === Profondeur & écume (pixels d'eau) ===
        #ifdef WATER_FOAM
        if (wdata.a > 0.8 && isEyeInWater == 0) {
            float d1f = texture2D(depthtex1, texcoord).r;
            if (d1f < 1.0) {
                vec3 p1f = reconstructPlayer(texcoord, d1f);
                float gap = max(length(p1f) - dist, 0.0);

                // L'eau fonce avec l'épaisseur d'eau TRAVERSÉE (le long du rayon)
                color *= mix(vec3(0.40, 0.52, 0.55), vec3(1.0), exp(-gap * 0.14));

                // L'écume, elle, dépend de la profondeur VERTICALE (surface
                // moins fond) — indépendante de l'angle de vue, sinon elle
                // n'apparaît jamais quand on regarde le lac de loin.
                // MAIS elle exige aussi un fond PROCHE le long du rayon :
                // l'eau surélevée (fontaines) voyait le décor lointain
                // derrière elle comme un "fond peu profond" -> écume étirée
                // sur toute la surface
                float vertDepth = max(playerPos.y - p1f.y, 0.0);
                float rayGate = smoothstep(2.5, 0.8, gap);
                float shore = smoothstep(0.40, 0.05, vertDepth) * rayGate;
                if (shore > 0.01) {
                    vec3 w1f = p1f + cameraPosition;
                    float fn = valueNoise(w1f.xz * 7.0 + vec2(frameTimeCounter * 0.7, frameTimeCounter * 0.45))
                             + valueNoise(w1f.xz * 15.0 - vec2(frameTimeCounter * 0.5, frameTimeCounter * 0.9)) * 0.5;
                    float foam = smoothstep(0.55, 0.95, fn * 0.67) * shore;
                    vec3 foamCol = getSkyAmbientColor(sunH, rainStrength) * 3.5 * wdata.b + vec3(0.015);
                    color = mix(color, foamCol, clamp(foam, 0.0, 1.0) * 0.75);
                }
            }
        }
        #endif

        // === Caustiques sur le fond sous l'eau ===
        #ifdef WATER_CAUSTICS
        if (wdata.a > 0.8 || isEyeInWater == 1) {
            float d1 = texture2D(depthtex1, texcoord).r;
            if (d1 < 1.0) {
                vec3 p1 = reconstructPlayer(texcoord, d1);
                vec3 w1 = p1 + cameraPosition;
                float depthGap = (isEyeInWater == 1) ? length(p1) : length(p1) - dist;
                float ca = caustic(w1.xz * 0.9 + w1.y * 0.25, frameTimeCounter * 1.1);
                float fadeC = clamp(depthGap * 0.6, 0.0, 1.0) * exp(-max(depthGap, 0.0) * 0.08);
                float skyC = (isEyeInWater == 1) ? 1.0 : wdata.b;
                color *= 1.0 + ca * 1.2 * fadeC * skyC * mix(0.15, 1.0, day);
            }
        }
        #endif

        // === Brouillard ===
        if (isEyeInWater == 1) {
            // --- Sous l'eau v2.2 : absorption réelle + fenêtre de Snell ---
            float eyeDepth = max(63.0 - cameraPosition.y, 0.0);

            // L'eau absorbe le ROUGE d'abord, puis le vert : plus on est
            // profond et plus on regarde loin, plus le monde vire au
            // bleu-vert sombre (le chemin lumineux cumule descente + trajet)
            float path = dist + eyeDepth * 2.0;
            color *= exp(-vec3(0.105, 0.030, 0.018) * path);

            // La clarté vient d'en haut : le jour l'eau est lumineuse près
            // de la surface, la nuit et en profondeur c'est le noir
            float sunVis = mix(0.06, 1.0, day) * exp(-eyeDepth * 0.06);
            vec3 waterCol = vec3(0.012, 0.046, 0.054) * sunVis;
            float f = 1.0 - exp(-dist * (0.10 + 0.015 * min(eyeDepth, 20.0)));
            color = mix(color, waterCol, f);

            // Fenêtre de Snell : vers le haut, la lumière du ciel se
            // concentre dans un cône (~49°) — le puits de lumière ; au-delà
            // du cône, la surface vue de dessous s'assombrit en miroir
            float win = smoothstep(0.52, 0.74, dir.y);
            color *= 1.0 + win * 0.9 * sunVis;
            color *= 1.0 - (1.0 - win) * clamp(dir.y * 1.6, 0.0, 1.0) * 0.35;
        } else {
            // v2.2.1 : brouillard ATMOSPHÉRIQUE en couche (fini la purée
            // uniforme) — la densité décroît exponentiellement avec
            // l'altitude : au sol l'air est épais, sur une haute montagne
            // il devient cristallin et l'horizon s'ouvre (prépare le
            // Distant Horizons maison). Intégrale analytique exacte de
            // exp(-y/H) le long du rayon.
            float d0 = (0.0045 + 0.0025 * (1.0 - day)) * FOG_DENSITY;
            const float fogH = 1.0 / 42.0;   // épaisseur de la couche ~42 blocs
            float cy = max(cameraPosition.y - 63.0, 0.0);
            // DH (v2.5) : le fog est calibré pour ~256-512 m — sur les
            // distances LOD on ÉTIRE la distance perçue, sinon l'horizon
            // DH sature en gris. ATTENTION : avec DH, Iris ÉTEND le far
            // plane vanilla -> la reconstruction du CIEL (depth=1) passe
            // de ~300 m à des kilomètres, et le fog saturait sur le ciel
            // en ANNEAUX CENTRÉS ÉCRAN (le fameux dôme, sensible au FOV
            // donc au sprint). Le ciel est plafonné à sa distance d'avant.
            float fogDist = dist;
            #ifdef DISTANT_HORIZONS
                if (depth >= 0.99999) {
                    fogDist = min(dist, 480.0);           // vrai ciel
                } else {
                    // le fog PROCHE (< 256 m) reste intact (ambiance) ;
                    // seul le lointain est étiré vers l'horizon DH
                    float kDH = clamp(256.0 / max(float(dhRenderDistance), 256.0),
                                      0.22, 1.0);
                    fogDist = min(dist, 256.0) + max(dist - 256.0, 0.0) * kDH;
                }
            #endif
            float od;
            if (abs(dir.y) > 0.01) {
                od = d0 * exp(-cy * fogH)
                   * (1.0 - exp(-fogDist * dir.y * fogH)) / (dir.y * fogH);
            } else {
                od = d0 * exp(-cy * fogH) * fogDist;
            }
            od = max(od, 0.0);
            // le voile de pluie, lui, noie tout le ciel uniformément
            od += fogDist * 0.006 * rainStrength * FOG_DENSITY;
            float fogF = 1.0 - exp(-od);

            // La brume au sol s'efface sous l'averse (le fog de pluie la remplace)
            float worldY = playerPos.y + cameraPosition.y;
            float mist;
            #if defined(DRIFTING_MIST) && !defined(HEAVY_FOG)
            // Brume VOLUMÉTRIQUE : l'intégrale de densité (bancs de bruit
            // le long du rayon) est marchée en demi-résolution dans deferred
            // (colortex6.b) — les nappes ont une vraie profondeur
            mist = texture2D(colortex6, min(texcoord * 0.5, vec2(0.4995))).b;
            mist *= 2.2 * MIST_STRENGTH * (0.5 + 0.5 * (1.0 - day))
                  * (1.0 - 0.6 * rainStrength);
            #else
            mist = exp(-max(worldY - 63.0, 0.0) / 10.0);
            mist *= (1.0 - exp(-dist * 0.015)) * MIST_STRENGTH * (0.5 + 0.5 * (1.0 - day))
                  * (1.0 - 0.6 * rainStrength);
            #endif

            fogF = clamp(fogF + mist * 0.45, 0.0, 1.0);

            vec3 fogDir = normalize(vec3(dir.x, dir.y * 0.3, dir.z));
            vec3 fogCol = getSkyColor(fogDir, sunDirW, rainStrength);
            // Sous la pluie : le brouillard prend la couleur de la DALLE
            // NUAGEUSE (même famille de gris que le ciel d'orage) — le
            // lointain et le ciel se fondent au lieu de se découper
            vec3 overcastFog = mix(vec3(0.0010, 0.0013, 0.0020) * NIGHT_BRIGHTNESS,
                                   vec3(0.055, 0.059, 0.067), day);
            fogCol = mix(fogCol, overcastFog, rainStrength * 0.75);

            color = mix(color, fogCol, fogF);
        }
    }

    // === Nappe lourde : la mer de brouillard s'applique aussi sur le ciel
    //     à l'horizon (les vallées noyées se fondent dans le lointain) ===
    #ifdef HEAVY_FOG
    if (isEyeInWater == 0) {
        // Lecture adoucie (4 prises) : gomme le reste de grain de la marche
        vec2 hp = vec2(1.0 / viewWidth, 1.0 / viewHeight);
        vec2 hb = min(texcoord * 0.5, vec2(0.4995));
        vec2 hcap = vec2(0.4995);
        float heavy = (texture2D(colortex6, hb).b
                     + texture2D(colortex6, min(hb + vec2(hp.x, 0.0), hcap)).b
                     + texture2D(colortex6, min(hb + vec2(0.0, hp.y), hcap)).b
                     + texture2D(colortex6, min(hb + hp, hcap)).b) * 0.25
                    * (1.0 - 0.35 * rainStrength);
        if (heavy > 0.002) {
            vec3 heavyCol = getSkyColor(normalize(vec3(dir.x, 0.05, dir.z)), sunDirW, rainStrength);
            // Gris lourd, désaturé, qui s'éteint la nuit
            heavyCol = mix(heavyCol, vec3(luminance(heavyCol)) * vec3(0.98, 1.0, 1.04), 0.40)
                     * (0.72 + 0.28 * day);
            // Plafond d'opacité : les silhouettes restent LISIBLES même au
            // fond des vallées (v2.2.1 : 0.92 max noyait tout depuis les
            // crêtes — l'effet mer vit dans les 2/3 bas, pas dans l'opacité)
            color = mix(color, heavyCol, min(heavy, 0.62 + 0.12 * (1.0 - day)));
        }
    }
    #endif

    // === Lumière volumétrique : la lumière filtre à travers les obstacles ===
    // L'intégrale chère est calculée en DEMI-RÉSOLUTION dans deferred
    // (quart bas-gauche de colortex6) ; ici on la ré-agrandit avec un
    // filtre bilatéral guidé par la distance (pas de halos sur les bords).
    #ifdef VOLUMETRIC_LIGHT
    {
        float maxDist = min(dist, 48.0);
        vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
        vec2 halfUV = texcoord * 0.5;
        float refD = maxDist / 48.0;

        float vl = 0.0;
        float wsum = 0.0;
        for (int oy = 0; oy <= 1; oy++) {
            for (int ox = 0; ox <= 1; ox++) {
                vec2 suv = min(halfUV + vec2(float(ox), float(oy)) * px,
                               vec2(0.5) - px * 0.5);
                vec2 s = texture2D(colortex6, suv).rg;
                float w = exp(-abs(s.g - refD) * 24.0) + 1e-4;
                vl += s.r * w;
                wsum += w;
            }
        }
        vl /= wsum;

        // Vraie phase de Mie (double Henyey-Greenstein, idée IterationT) :
        // lobe avant serré + rétro-diffusion douce — les rais ont du corps
        // sous tous les angles, plus seulement pile face au soleil
        float cosVL = dot(dir, lightDirW);
        float hg1 = (1.0 - 0.3025) / pow(1.3025 - 1.10 * cosVL, 1.5);   // g = 0.55
        float hg2 = (1.0 - 0.09) / pow(1.09 + 0.60 * cosVL, 1.5);       // g = -0.30
        float phase = (hg1 * 0.7 + hg2 * 0.3) * 0.85;
        // Effet "poudre" : la masse brumeuse s'éclaircit face à la lumière
        float powder = 1.0 - exp(-maxDist * 0.10);
        phase *= 0.65 + 0.35 * powder * (cosVL * 0.5 + 0.5);
        // Rolloff anti-flashbang (v2.2.1) : le lobe avant HG culmine à ~x7.6
        // pile face au soleil — compressé façon Reinhard, les rais gardent
        // leur corps latéral mais le contre-jour ne crame plus l'écran
        phase = phase / (1.0 + 0.30 * phase);
        float amount = (1.0 - exp(-maxDist * 0.05)) * (0.06 + 0.22 * dusk);
        vec3 vlCol = getShadowLightColor(sunH, rainStrength);

        if (isEyeInWater == 1) {
            // Rais sous-marins : éteints la nuit et en profondeur
            float eyeDepth = max(63.0 - cameraPosition.y, 0.0);
            vlCol = vec3(0.015, 0.045, 0.055) * mix(0.08, 1.0, day) * exp(-eyeDepth * 0.05);
            phase = 0.6;
            amount = (1.0 - exp(-maxDist * 0.1)) * 0.5;
        }

        color += vlCol * (vl * phase * amount * VL_STRENGTH);
    }
    #endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.1) discard;

    // Émissif : brille dans le noir (le bloom fera le reste)
    vec3 color = srgbToLinear(tex.rgb) * 1.5;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, tex.a);
}

#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/shadows.glsl"
#include "/lib/water.glsl"

uniform sampler2D texture;
uniform ivec2 atlasSize;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform vec3 cameraPosition;
#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
uniform int frameCounter;
uniform sampler3D floodfill_sampler;
uniform sampler3D floodfill_sampler_copy;
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;
varying float matFlag;
varying float wetK;
varying float pbrK;
varying vec3 viewVec;
varying vec3 worldPosV;
varying vec3 tangentV;
varying float tangentW;
varying vec2 midCoord;
varying vec2 spriteHalf;

// La hauteur vient de la TEXTURE elle-même : pixels clairs = bosses,
// sombres = creux (joints de briques, fissures) — pas de bruit inventé
float pomHeight(vec2 uv) {
    return clamp(luminance(texture2D(texture, uv).rgb) * 1.25, 0.0, 1.0);
}

vec2 pomClamp(vec2 uv) {
    vec2 eps = spriteHalf * 0.02;
    return clamp(uv, midCoord - spriteHalf + eps, midCoord + spriteHalf - eps);
}

void main() {
    // --- Relief 3D (POM) : la caméra "descend" dans les creux de la
    // texture — les joints s'enfoncent, les pierres avancent, avec une
    // vraie parallaxe quand on se déplace. Style texture pack 3D. ---
    vec2 uvP = texcoord;
    #ifdef POM
    if (vertDist < POM_DISTANCE && abs(matFlag) < 0.5 && spriteHalf.x > 1e-6) {
        vec3 T = normalize(tangentV);
        vec3 B = normalize(cross(T, normalV)) * tangentW;
        vec3 vT = normalize(vec3(dot(viewVec, T), dot(viewVec, B), dot(viewVec, normalV)));
        if (vT.z < -0.05) {
            float fade = 1.0 - vertDist / POM_DISTANCE;
            // Profondeur en unités de tuile, plafonnée en rasant
            vec2 slope = (vT.xy / max(-vT.z, 0.22)) * (POM_DEPTH * fade) * (spriteHalf * 2.0);

            const int POM_STEPS = 10;
            vec2 uvStep = slope / float(POM_STEPS);
            float layerStep = 1.0 / float(POM_STEPS);

            vec2 uv = texcoord;
            float layer = 1.0;
            float h = pomHeight(uv);
            for (int i = 0; i < POM_STEPS; i++) {
                if (layer <= h) break;
                uv = pomClamp(uv + uvStep);
                layer -= layerStep;
                h = pomHeight(uv);
            }
            uvP = uv;
        }
    }
    #endif

    vec4 tex = texture2D(texture, uvP);
    if (tex.a < 0.1) discard;

    vec3 albedo = srgbToLinear(tex.rgb * glcolor.rgb);

    // Variations organiques : casse l'uniformité des grandes surfaces
    #ifdef COLOR_VARIATION
    if (matFlag < 0.5) {
        float varn = valueNoise(worldPosV.xz * 0.13) * 0.6
                   + valueNoise(worldPosV.xz * 0.031) * 0.4;
        albedo *= 0.88 + 0.24 * varn;
    }
    #endif

    // --- Auto-relief : normal map générée depuis la texture vanilla ---
    // (pixels sombres = creux, clairs = bosses ; blocs proches seulement)
    vec3 N = normalV;
    #ifdef AUTO_NORMALS
    if (vertDist < 24.0 && abs(matFlag) < 0.5) {
        vec2 texel = 1.0 / vec2(atlasSize);
        float lC = luminance(tex.rgb);
        float lX = luminance(texture2D(texture, uvP + vec2(texel.x, 0.0)).rgb);
        float lY = luminance(texture2D(texture, uvP + vec2(0.0, texel.y)).rgb);
        // Gradient borné : les textures très contrastées ne partent pas en grain
        vec2 grad = clamp(vec2(lX - lC, lY - lC), -0.1, 0.1);

        float fadeR = 1.0 - vertDist / 24.0;

        // Base tangente monde approchée depuis la normale géométrique
        vec3 nWg = mat3(gbufferModelViewInverse) * normalV;
        vec3 tW = (abs(nWg.y) > 0.5) ? vec3(1.0, 0.0, 0.0)
                                     : normalize(cross(vec3(0.0, 1.0, 0.0), nWg));
        vec3 bW = cross(nWg, tW);
        vec3 nWnew = normalize(nWg - (tW * grad.x + bW * grad.y) * 2.5 * RELIEF_STRENGTH * fadeR);
        N = normalize(mat3(gbufferModelView) * nWnew);
    }
    #endif

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    // Orientation monde de la face (relief : le ciel éclaire par le haut)
    float upW = clamp((mat3(gbufferModelViewInverse) * N).y, -1.0, 1.0);
    float hemi = 0.45 + 0.55 * (upW * 0.5 + 0.5);

    // Surfaces mouillées : flaques irrégulières sur les sols exposés
    float wet = 0.0;
    vec2 rippleG = vec2(0.0);
    float splashLit = 0.0;   // couronne + éclat : ADDITIF uniquement
    #ifdef RAIN_WETNESS
        // humidité générale (toute la surface exposée) vs FLAQUES (le fbm)
        float damp = rainStrength * smoothstep(0.85, 0.95, lmcoord.y)
                   * (0.3 + 0.7 * clamp(upW, 0.0, 1.0));
        float puddle = smoothstep(0.42, 0.75, fbm(worldPosV.xz * 0.22));
        // Contraste des flaques accentué : certaines brillent nettement
        // plus que d'autres (retour beta : reflets trop uniformes)
        wet = damp * (0.22 + 0.88 * puddle);
        albedo *= 1.0 - 0.35 * wet;

        // IMPACTS DE PLUIE : le gradient va dans la normale des REFLETS
        // (nBuf, plus bas), JAMAIS dans la normale d'ÉCLAIRAGE — le TAA
        // moyennerait les anneaux animés en disques sombres rémanents.
        // La couronne et l'éclat, eux, sont purement ADDITIFS.
        // Portée 32 m : mesuré, un anneau fait 4,8 cm de large, soit
        // moins d'UN pixel au-delà de ~48 m (invisible + aliasing).
        #ifdef RAIN_SPLASH
        if (damp > 0.04 && vertDist < 32.0) {
            float fadeS = 1.0 - smoothstep(20.0, 32.0, vertDist);
            vec4 sp = rainSplash(worldPosV.xz, frameTimeCounter, puddle);
            // la NORMALE porte l'effet (l'eau déforme, elle ne couvre pas)
            rippleG = sp.xy * (0.85 * damp * fadeS * RAIN_SPLASH_STRENGTH);
            // la couleur n'est qu'un ACCENT : le sol doit rester lisible
            splashLit = (sp.z * 0.5 + sp.w * 0.7) * damp * fadeS * RAIN_SPLASH_STRENGTH;
        }
        #else
        if (wet > 0.12 && vertDist < 48.0) {
            rippleG = rainRippleGrad(worldPosV.xz, frameTimeCounter) * (0.25 * wet);
        }
        #endif
    #endif

    vec3 lightDirV = safeNormalize(shadowLightPosition);
    float NdotL = clamp(dot(N, lightDirV), 0.0, 1.0);
    float NdotLgeo = clamp(dot(normalV, lightDirV), 0.0, 1.0);

    // Ombre : shadow map près du joueur, estimation lightmap au-delà
    // (biais basé sur la normale géométrique, pas la normale détaillée)
    float skyExposure = smoothstep(0.7, 0.95, lmcoord.y);
    // OMBRE COLORÉE : le soleil qui traverse un vitrail peint le sol de
    // sa couleur (shadowtex1 + shadowcolor0, façon SEUS PTGI)
    vec3 shadow = getShadowColored(shadowPos, NdotLgeo,
            worldPosV - cameraPosition,
            mat3(gbufferModelViewInverse) * normalV, sunDirW, cameraPosition);
    float shadowFade = smoothstep(shadowDistance * 0.75, shadowDistance, vertDist);
    shadow = mix(shadow, vec3(skyExposure), shadowFade);
    // Les nuages projettent leurs ombres : taches de lumière mouvantes
    shadow *= cloudShadow(worldPosV, sunDirW, rainStrength, frameTimeCounter);

    // La lumière directe exige un accès au ciel (coupe le soleil au Nether
    // et limite les fuites hors de portée de la shadow map)
    float skyGate = smoothstep(0.05, 0.35, lmcoord.y);

    float flick = torchFlicker(frameTimeCounter);

    // === LUMIÈRE COLORÉE VOXEL : la couleur de la lumière de bloc vient
    // du volume flood-fill (shadowcomp) — soul lantern bleue, redstone
    // rouge, vitrail qui teinte... L'INTENSITÉ reste celle de la lightmap
    // vanilla (notre courbe dorée). Hors volume / OptiFine : or classique.
    vec3 torchLightCol = getTorchLight(lmcoord.x);
    #if defined IRIS_FEATURE_CUSTOM_IMAGES && defined COLORED_LIGHT
    {
        vec3 playerP = (gbufferModelViewInverse * vec4(viewVec, 1.0)).xyz;
        vec3 nWv = mat3(gbufferModelViewInverse) * normalV;
        vec3 vox = playerP + nWv * 0.55 + fract(cameraPosition)
                 + vec3(64.0, 32.0, 64.0);
        vec3 vt = vox / vec3(128.0, 64.0, 128.0);
        if (vt == clamp(vt, vec3(0.01), vec3(0.99))) {
            vec4 lv = (mod(float(frameCounter), 2.0) < 0.5)
                    ? texture3D(floodfill_sampler_copy, vt)
                    : texture3D(floodfill_sampler, vt);
            vec3 cv = sqrt(max(lv.rgb, 0.0));
            float pres = luminance(cv);
            if (pres > 0.015) {
                // INTENSITÉ VOXEL : le flood-fill porte BIEN plus loin que
                // la lightmap vanilla (14 blocs max) — la lumière colorée
                // DIFFUSE façon Eclipse/PTGI, la courbe vanilla reste un
                // plancher près des sources. Le slider dose la diffusion.
                float voxI = pres * pres * (0.11 * COLORED_LIGHT_STRENGTH);
                float inten = max(getTorchIntensity(lmcoord.x), voxI);
                vec3 colored = inten * (cv / pres) * luminance(FIRE_COLOR);
                // fondu aux bords du volume + confiance
                vec3 eV = abs(vt - 0.5) * 2.0;
                float edge = smoothstep(1.0, 0.8, max(eV.x, max(eV.y, eV.z)));
                // la TEINTE du voxel s'impose dès qu'il y a de la lumière
                // colorée, même faible : doser par son intensité faisait
                // RETOURNER la couleur vers l'or vanilla en s'éloignant
                // (une glowstone derrière un verre vert redevenait jaune)
                float kC = edge * smoothstep(0.003, 0.030, pres);
                torchLightCol = mix(torchLightCol, colored, kC);
            }
        }
    }
    #endif

    vec3 light = getShadowLightColor(sunH, rainStrength) * (shadow * NdotL * skyGate)
               + getSkyAmbientColor(sunH, rainStrength) * (lmcoord.y * lmcoord.y) * hemi
               + torchLightCol * flick
               + CAVE_AMBIENT
               // Ambiance de dimension : là où le ciel n'existe pas (Nether,
               // dims moddées), la couleur de fog du biome éclaire faiblement
               + srgbToLinear(fogColor) * 0.055 * (1.0 - lmcoord.y) * hemi;

    #ifdef HAND_LIGHT
        float held = float(max(heldBlockLightValue, heldBlockLightValue2));
        light += getHeldLight(vertDist, held, flick);
    #endif

    vec3 color = albedo * light;

    // === IMPACTS DE PLUIE : l'éclat (ADDITIF, jamais soustractif) ===
    // Le SSR déforme déjà les reflets de la SCÈNE via la normale perturbée,
    // mais il ne peut pas refléter les sources ponctuelles (soleil, lune,
    // lanterne hors écran). C'est ce terme qui fait ÉTINCELER les impacts
    // sous une lanterne, la nuit — là où le SSR ne montre presque rien.
    // Aucun double comptage : deux phénomènes distincts.
    #if defined(RAIN_WETNESS) && defined(RAIN_SPLASH)
    if (splashLit > 0.001 || dot(rippleG, rippleG) > 1e-6) {
        vec3 vDirS = normalize(viewVec);
        // normale perturbée par les anneaux (monde -> vue)
        vec3 nWr = mat3(gbufferModelViewInverse) * normalV;
        nWr = normalize(nWr + vec3(rippleG.x, 0.0, rippleG.y) * 3.0);
        vec3 nVr = normalize(mat3(gbufferModelView) * nWr);

        float specR = pow(clamp(dot(reflect(vDirS, nVr), lightDirV), 0.0, 1.0), 64.0);
        vec3 srcLight = getShadowLightColor(sunH, rainStrength) * shadow * skyGate
                      + torchLightCol * flick;
        // l'anneau accroche la lumière ; la couronne et l'éclat brillent
        // additif TRÈS discret : un impact d'eau DÉFORME le reflet, il ne
        // repeint pas le sol en blanc (c'était le bug des « blobs opaques »)
        color += srcLight * (specR * 0.8 + splashLit * 0.10);
    }
    #endif

    // Éclat des surfaces mouillées : reflet du ciel en angle rasant + spéculaire
    #ifdef RAIN_WETNESS
    if (wet > 0.001) {
        vec3 vDir = normalize(viewVec);
        float spec = pow(clamp(dot(reflect(vDir, N), lightDirV), 0.0, 1.0), 48.0);
        // Fresnel sur la normale GÉOMÉTRIQUE : l'eau lisse la surface,
        // sinon chaque bosse du relief devient un point blanc
        float sheen = pow(1.0 - clamp(dot(-vDir, normalV), 0.0, 1.0), 4.0);
        // La brillance dépend du matériau (wetK) : la pierre luit, le bois
        // et la terre foncent surtout
        color += getShadowLightColor(sunH, rainStrength) * spec * shadow * wet * 1.2 * wetK;
        color += getSkyAmbientColor(sunH, rainStrength) * sheen * wet * (lmcoord.y * lmcoord.y) * 1.0 * wetK;
        // Les flaques accrochent la lueur chaude des torches et lanternes
        color += getTorchLight(lmcoord.x) * flick * sheen * wet * 2.0 * wetK;
    }
    #endif

    // --- Auto-PBR : métaux & minéraux polis (style RTX, zéro resource
    // pack). Spéculaire dur du soleil/de la lune, TEINTÉ par l'albedo sur
    // le métal (l'or brille doré, le cuivre roux) ; les pixels clairs de
    // la texture sont plus polis que les sombres (joints, gravures).
    float pbrGloss = 0.0;
    #ifdef AUTO_PBR
    if (pbrK > 0.01) {
        float lumP = luminance(albedo);
        pbrGloss = pbrK * (0.55 + 0.45 * smoothstep(0.25, 0.75, lumP));
        vec3 vDirP = normalize(viewVec);
        float sp = mix(24.0, 220.0, pbrGloss);
        float specP = pow(clamp(dot(reflect(vDirP, N), lightDirV), 0.0, 1.0), sp)
                    * (0.35 + pbrGloss * 1.4) * PBR_STRENGTH;
        float metalP = step(0.9, pbrK);
        vec3 tintP = mix(vec3(1.0), albedo / max(lumP, 0.06), metalP);
        color += getShadowLightColor(sunH, rainStrength) * specP * shadow * skyGate * tintP;
        // les torches accrochent le poli en angle rasant
        float fresP = pow(1.0 - clamp(dot(-vDirP, normalV), 0.0, 1.0), 3.0);
        color += getTorchLight(lmcoord.x) * flick * fresP * pbrGloss * 0.5 * tintP;
    }
    #endif

    // --- Blocs émissifs ---
    float lum = luminance(albedo);
    if (matFlag > 0.5 && matFlag < 1.5) {
        // Lave / magma : les zones chaudes irradient, avec une pulsation lente
        float pulse = 0.88 + 0.12 * sin(frameTimeCounter * 1.1 + sin(frameTimeCounter * 0.53) * 2.0);
        color = albedo * light * 0.25 + albedo * pow(lum, 1.5) * 7.0 * pulse;
    } else if (matFlag > 1.5 && matFlag < 2.5) {
        // Torches, lanternes, feux : les pixels brillants (flammes) émettent
        // fort — ils doivent dépasser nettement le seuil du bloom.
        // v2.4 : les émetteurs SOMBRES mais saturés (redstone, améthyste)
        // n'émettaient presque rien (glow basé luminance seule) — un boost
        // de saturation les allume, et nourrit la lumière colorée
        float maxCe = max(albedo.r, max(albedo.g, albedo.b));
        float satE = clamp((maxCe - min(albedo.r, min(albedo.g, albedo.b)))
                / max(maxCe, 1e-4), 0.0, 1.0);
        color += albedo * (pow(lum, 2.0) * 6.0
                + satE * satE * 1.6 * (1.0 - min(lum * 0.8, 0.8))) * flick;
    } else if (matFlag > 2.5 && matFlag < 3.5) {
        // Blocs des ÂMES : une lueur spectrale bleu-gris respire à la
        // surface, des volutes froides dérivent lentement.
        // PROPORTIONNELLE à l'éclairage local : dans le noir elle reste un
        // souffle à peine visible — l'ancien plancher fixe brillait 10x
        // plus fort que le bloc = marbré fluo mouvant sur tout le Nether
        float wisp = fbm(worldPosV.xz * 0.9
                + vec2(frameTimeCounter * 0.10, frameTimeCounter * 0.22));
        float breath = 0.7 + 0.3 * sin(frameTimeCounter * 0.8
                + worldPosV.x * 0.6 + worldPosV.z * 0.4);
        float wispF = smoothstep(0.40, 0.75, wisp) * breath;
        color = mix(color, vec3(luminance(color)) * vec3(0.75, 0.95, 1.15), 0.30);
        color += vec3(0.10, 0.30, 0.42) * wispF * (0.006 + luminance(color) * 0.6);
    }

    // Masque de reflets : les sols mouillés reflètent les lumières (SSR).
    // Encodage : 0.38 (sec) → 0.54 (minéral trempé) ; le seuil SSR est 0.40
    // et la force est décodée dans composite. wetK module par matériau.
    float wetMask = 0.0;
    #ifdef RAIN_WETNESS
        wetMask = 0.38 + 0.16 * smoothstep(0.12, 0.4, wet) * wetK;
    #endif
    #ifdef AUTO_PBR
        // reflets SSR À SEC : bande MÉTAL 0.70-0.80 (reflet teinté par
        // l'albedo dans composite), minéraux polis dans la bande "mouillé"
        if (pbrK > 0.9) wetMask = 0.75;
        else if (pbrK > 0.01) wetMask = max(wetMask, 0.40 + 0.13 * pbrGloss);
    #endif

/* DRAWBUFFERS:027 */
    gl_FragData[0] = vec4(color, tex.a * glcolor.a);
    // Normale GÉOMÉTRIQUE (lisse) pour le SSR : le micro-relief fait rater
    // le rayon un texel sur deux. Les anneaux de pluie, eux, sont doux et
    // cohérents -> on les garde pour que les reflets ondulent
    vec3 nBuf = normalize(normalV);
    #ifdef RAIN_WETNESS
    // BUG CORRIGÉ : le seuil `wet > 0.12` (masque de FLAQUE) jetait le
    // gradient des impacts sur toute la pierre simplement mouillée — ils
    // étaient calculés puis perdus. On teste maintenant le gradient
    // lui-même, en plus de la rugosité liée aux flaques.
    if ((wet > 0.12 || dot(rippleG, rippleG) > 1e-8) && vertDist < 48.0) {
        vec3 nBw = mat3(gbufferModelViewInverse) * nBuf;
        nBw.xz += rippleG;
        // Micro-rugosité STATIQUE (sans animation : sûre pour le TAA) qui
        // casse la perfection des reflets — plus marquée sur le bois et la
        // terre (wetK bas) que sur la pierre polie
        nBw.xz += vec2(valueNoise(worldPosV.xz * 5.0) - 0.5,
                       valueNoise(worldPosV.xz * 5.0 + 17.3) - 0.5)
                * (0.10 * (1.2 - wetK)) * wet;
        nBuf = normalize(mat3(gbufferModelView) * nBw);
    }
    #endif
    gl_FragData[1] = vec4(octEncode(nBuf), lmcoord.y, wetMask);
    // Albedo LINÉAIRE plein-res pour le GI (composite multiplie
    // l'irradiance rebondie par lui — les couleurs restent nettes).
    // Alpha = lightmap TORCHE : la lumière colorée (composite) sait
    // combien ce pixel reçoit de lumière de bloc à re-teinter.
    gl_FragData[2] = vec4(albedo, lmcoord.x);
}

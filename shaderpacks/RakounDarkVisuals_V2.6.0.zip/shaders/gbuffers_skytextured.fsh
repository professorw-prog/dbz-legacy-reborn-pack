#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 tex = texture2D(texture, texcoord) * glcolor;

    // Astres pâles et froids, voilés
    vec3 color = srgbToLinear(tex.rgb) * vec3(0.70, 0.72, 0.85) * 0.75;

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, tex.a);
}

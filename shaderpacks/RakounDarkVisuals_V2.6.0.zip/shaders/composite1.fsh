#version 120

// God rays : rayons de lumière volumétriques en espace écran,
// accumulés depuis la position du soleil / de la lune.

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

#ifdef GODRAYS
    // Position de la source de lumière à l'écran
    vec4 clip = gbufferProjection * vec4(shadowLightPosition, 1.0);
    if (clip.w > 0.0) {
        vec2 lightUV = (clip.xy / clip.w) * 0.5 + 0.5;

        // Fondu quand la source s'éloigne du champ de vision
        float vis = smoothstep(1.2, 0.65, length(lightUV - vec2(0.5)));

        if (vis > 0.0) {
            vec2 delta = (lightUV - texcoord) / float(GODRAY_SAMPLES);
            // Départ légèrement bruité pour casser les bandes
            vec2 pos = texcoord + delta * hash12(gl_FragCoord.xy);

            vec3 rays = vec3(0.0);
            float weight = 1.0;
            for (int i = 0; i < GODRAY_SAMPLES; i++) {
                pos += delta;
                if (pos.x < 0.0 || pos.x > 1.0 || pos.y < 0.0 || pos.y > 1.0) break;
                // Seul le ciel visible alimente les rayons
                if (texture2D(depthtex0, pos).r >= 1.0) {
                    rays += texture2D(colortex0, pos).rgb * weight;
                }
                weight *= 0.95;
            }
            rays /= float(GODRAY_SAMPLES);

            // Discrets la nuit (lune/étoiles), présents au crépuscule et le jour
            float sunH = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition).y;
            float day = smoothstep(-0.05, 0.25, sunH);
            float strength = mix(0.2, 1.0, day);

            // Diffusion vers l'AVANT : les rais ne se voient qu'en regardant
            // vers la source. Sans ce facteur, les stries radiales se
            // projetaient sur le sol comme de fausses ombres pointant vers
            // le soleil.
            vec4 vd4 = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
            vec3 viewDir = normalize(vd4.xyz);
            float toSun = pow(clamp(dot(viewDir, safeNormalize(shadowLightPosition)), 0.0, 1.0), 3.0);

            // Sous la pluie, les rayons survivent à ~55% : des godrays
            // diffus percent l'orage quand le soleil est dans l'axe
            color += rays * 1.0 * GODRAY_STRENGTH * strength * vis * toSun * (1.0 - 0.45 * rainStrength);
        }
    }
#endif

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

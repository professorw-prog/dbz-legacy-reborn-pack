#version 120

// END : deferred NEUTRE (dédié — jamais écrasé par sync_worlds).
// Pas de VL solaire ni de mer de brouillard dans le vide.

varying vec2 texcoord;

void main() {
/* DRAWBUFFERS:6 */
    // vl neutre, brume nulle — alpha 0.25 = marqueur "End"
    gl_FragData[0] = vec4(1.0, 1.0, 0.0, 0.25);
}

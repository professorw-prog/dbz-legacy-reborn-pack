#version 120

// END : le VIDE — et son maître.
//  - un TROU NOIR GÉANT à lentille gravitationnelle domine le ciel :
//    les étoiles s'étirent en anneau autour de l'horizon des événements,
//    le disque d'accrétion s'enroule au-dessus et en dessous (recette
//    IterationT portée en GLSL 120, lib/blackhole.glsl)
//  - champ d'étoiles froides violacées + nébuleuse pourpre
//  - voile violet spectral conservé sur les îles
// IMPORTANT : les const de buffers doivent être REDÉCLARÉES ici — quand un
// dossier de dimension surcharge composite.fsh, celles du fichier racine
// sont perdues pour cette dimension.

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16F;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA16F;
const bool colortex3Clear = false;
const int colortex4Format = RGBA16F;
const bool colortex4Clear = false;
const int colortex5Format = RGBA16F;
const bool colortex5Clear = false;
const int colortex6Format = RGBA16;
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/blackhole.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform float frameTimeCounter;
uniform int frameCounter;

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;

    vec4 ndc = vec4(texcoord, depth, 1.0) * 2.0 - 1.0;
    vec4 vp = gbufferProjectionInverse * ndc;
    vec3 playerPos = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;
    float dist = length(playerPos);
    vec3 dir = playerPos / max(dist, 1e-4);

    if (depth >= 1.0) {
        // ============ LE CIEL DU VIDE ============
        // Le Trou Noir courbe la direction de TOUT le fond
        float bhTrans = 1.0;
        vec3 bhGlow = vec3(0.0);
        float dith = fract(hash12(gl_FragCoord.xy)
                + float(frameCounter - (frameCounter / 64) * 64) * 0.6180339887);
        vec3 bdir = blackHoleMarch(dir, normalize(vec3(0.30, 0.42, -0.85)), 0.38,
                                   dith, frameTimeCounter, 1.0, bhTrans, bhGlow);

        // Base : le néant, à peine violacé vers l'« horizon »
        vec3 sky = mix(vec3(0.009, 0.005, 0.018), vec3(0.002, 0.0015, 0.005),
                       clamp(abs(bdir.y) * 1.6, 0.0, 1.0));

        // Nébuleuse pourpre : nappes lentes dans le vide
        vec2 suv = octEncode(bdir);
        float neb = fbm(suv * 7.0 + vec2(frameTimeCounter * 0.004, 0.0));
        float neb2 = fbm(suv * 13.0 - vec2(0.0, frameTimeCounter * 0.003));
        sky += vec3(0.030, 0.012, 0.052) * smoothstep(0.52, 0.85, neb)
             + vec3(0.016, 0.006, 0.030) * smoothstep(0.58, 0.88, neb2);

        // Étoiles froides violacées (elles S'ÉTIRENT autour du trou :
        // la direction est déjà courbée)
        float s1 = starLayer(suv, 420.0, 0.958, 9.0);
        float s2 = starLayer(suv + 3.7, 190.0, 0.972, 7.0);
        float s3 = starLayer(suv + 9.1, 90.0, 0.986, 6.0);
        float tvar = hash12(floor(suv * 420.0) + 5.3);
        vec3 sCol = mix(vec3(0.85, 0.70, 1.0), vec3(0.70, 0.80, 1.0), tvar);
        sky += (s1 * 0.05 + s2 * 0.11 + s3 * 0.24) * sCol;

        // L'horizon des événements avale le fond ; le disque s'ajoute
        color = sky * bhTrans + bhGlow;
    } else {
        // ============ LES ÎLES ============
        // Voile violet spectral (conservé)
        vec3 fogCol = vec3(0.020, 0.012, 0.036);
        float f = min(1.0 - exp(-dist * 0.007 * FOG_DENSITY), 0.9);
        color = mix(color, fogCol, f);
    }

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

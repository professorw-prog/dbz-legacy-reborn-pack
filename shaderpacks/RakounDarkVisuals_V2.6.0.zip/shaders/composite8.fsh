#version 120

// Capture sphérique (inspirée de Kappa) : panorama 360° persistant de la
// scène, mis à jour chaque frame avec ce qui est visible à l'écran. Sert
// de repli aux reflets quand le rayon SSR sort de l'écran.
// Chaque texel = une direction monde (équirectangulaire) ; a = 1 si déjà vu.
// (Désactivé par défaut — voir OFFSCREEN_REFLECTIONS.)

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex4;
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;

varying vec2 texcoord;

void main() {
    vec4 result = texture2D(colortex4, texcoord);

#ifdef OFFSCREEN_REFLECTIONS
    // Direction monde correspondant à ce texel du panorama
    float phi   = (texcoord.x - 0.5) * 6.2831853;
    float theta = (1.0 - texcoord.y) * 3.14159265;
    vec3 dir = vec3(sin(theta) * sin(phi), cos(theta), sin(theta) * cos(phi));

    // Si cette direction est actuellement visible, on rafraîchit le texel
    vec3 vDir = mat3(gbufferModelView) * dir;
    if (vDir.z < 0.0) {
        vec4 clip = gbufferProjection * vec4(vDir, 0.0);
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (uv.x > 0.02 && uv.x < 0.98 && uv.y > 0.02 && uv.y < 0.98) {
            result = vec4(texture2D(colortex0, uv).rgb, 1.0);
        }
    }
#endif

/* DRAWBUFFERS:4 */
    gl_FragData[0] = result;
}

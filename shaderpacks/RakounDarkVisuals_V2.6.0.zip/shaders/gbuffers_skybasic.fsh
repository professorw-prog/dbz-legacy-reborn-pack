#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;

varying vec4 starData;
varying vec3 playerDir;

void main() {
    vec4 color;

    if (starData.a > 0.5) {
        // Étoiles vanilla adoucies : le champ d'étoiles dense est
        // désormais procédural (composite/deepSky), celles-ci ne servent
        // plus que d'accents brillants épars
        vec3 starCol = srgbToLinear(starData.rgb) * vec3(0.55, 0.70, 1.00) * 0.9;
        color = vec4(starCol, clamp(starData.r * 2.0, 0.0, 1.0) * (1.0 - rainStrength));
    } else {
        vec3 dir = normalize(playerDir);
        vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
        color = vec4(getSkyColor(dir, sunDirW, rainStrength), 1.0);
    }

/* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}

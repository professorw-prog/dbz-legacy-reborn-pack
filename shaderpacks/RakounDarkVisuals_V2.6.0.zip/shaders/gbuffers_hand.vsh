#version 120

// Main / objets tenus en 1ere personne.
// Programme DEDIE (avant : fallback textured) : il doit ECRIRE dans
// colortex2 pour effacer le masque de sol mouille du terrain derriere
// le bras — sinon les reflets de pluie "traversent" la peau (bug
// remonte par ChaosMeli23 sur CurseForge).

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
}

#version 330 compatibility

// DISTANT HORIZONS (v2.5) : le terrain LOD au-delà de la render
// distance, éclairé avec NOTRE lumière — même soleil, mêmes nuits
// bleues, même fog. Iris fournit dhMaterialId et les macros DH_BLOCK_*.

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"

flat out int matId;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normalW;
out vec3 playerPos;

uniform mat4 gbufferModelViewInverse;

void main() {
    gl_Position = ftransform();
    gl_Position.xy += taaJitter() * gl_Position.w;

    matId = dhMaterialId;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    playerPos = (gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
}

#version 120

// Terrain : blocs opaques et cutout (feuilles, plantes, torches...).

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"
#include "/lib/wind.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 at_tangent;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normalV;
varying vec4 shadowPos;
varying float vertDist;
varying float matFlag; // 0 = normal, 1 = lave/magma, 2 = source de lumière
varying float wetK;    // brillance sous la pluie : 1 = minéral, 0.5 = bois, 0.6 = organique
varying float pbrK;    // auto-PBR : 1 = métal (reflet teinté), 0.55 = poli/gemme
varying vec3 viewVec;
varying vec3 worldPosV;
// POM : base tangente + bornes de la tuile dans l'atlas
varying vec3 tangentV;
varying float tangentW;
varying vec2 midCoord;
varying vec2 spriteHalf;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;
    vec3 worldPos = playerPos.xyz + cameraPosition;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);

    // POM : tangente en espace vue + bornes de la tuile (|texcoord-mid|
    // est identique aux 4 coins -> constant sur la face après interpolation)
    tangentV = normalize(gl_NormalMatrix * at_tangent.xyz);
    tangentW = at_tangent.w;
    midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).xy;
    spriteHalf = abs(texcoord - midCoord);

    matFlag = 0.0;
    if (mc_Entity.x == 10009.0) matFlag = 1.0;
    if (mc_Entity.x == 10010.0 || mc_Entity.x == 10011.0
     || (mc_Entity.x >= 11001.0 && mc_Entity.x <= 11019.0)) matFlag = 2.0;
    if (mc_Entity.x == 10033.0) matFlag = 3.0; // blocs des âmes
    // Végétation : -1 → pas de relief auto (textures trop contrastées, ça scintille)
    if (mc_Entity.x == 10001.0 || mc_Entity.x == 10002.0 || mc_Entity.x == 10003.0) matFlag = -1.0;

    // Réponse à la pluie selon la famille de matériau
    wetK = 0.8;
    if (mc_Entity.x == 10030.0) wetK = 1.0;
    if (mc_Entity.x == 10031.0) wetK = 0.5;
    if (mc_Entity.x == 10032.0) wetK = 0.6;

    // Auto-PBR : famille de matériau réfléchissant
    pbrK = 0.0;
    if (mc_Entity.x == 10040.0) pbrK = 1.0;
    if (mc_Entity.x == 10041.0) pbrK = 0.55;

    // --- VENT 2.0 : un champ de bourrasques UNIQUE traverse la carte ---
    // (lib/wind.glsl — la pluie lit le même champ : tout plie ensemble)
    float t = frameTimeCounter * (1.2 + 0.5 * rainStrength);
    bool moved = false;

    float waving = 0.0;
    float amp = 0.0;
    #ifdef WAVING_PLANTS
        if (mc_Entity.x == 10001.0 || mc_Entity.x == 10002.0) {
            // Seuls les sommets hauts du quad bougent (le pied reste ancré)
            waving = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
            amp = 0.08;
        }
    #endif
    #ifdef WAVING_LEAVES
        if (mc_Entity.x == 10003.0) { waving = 1.0; amp = 0.055; }
    #endif

    // La rafale locale : calme ~0.3, bourrasque ~1.5, orage jusqu'à ~3
    vec2 wd = windDirection(frameTimeCounter);
    float gust = windGust(worldPos.xz, frameTimeCounter, rainStrength);

    if (waving > 0.0) {
        float k = waving * lmcoord.y;

        // POUSSÉE directionnelle : tout penche DANS LE SENS du vent,
        // d'autant plus fort que la bourrasque est violente
        vec2 sway = wd * gust * amp * 1.15;

        // Oscillation propre de la plante autour de la poussée (elle
        // reprend sa place entre deux rafales)
        sway += vec2(
            sin(t + worldPos.x * 0.8 + worldPos.z * 0.4),
            sin(t * 0.85 + worldPos.z * 0.9 + worldPos.x * 0.3)
        ) * amp * (0.35 + 0.40 * gust);

        // Bruissement rapide : tremble surtout DANS la bourrasque
        sway += vec2(
            sin(t * 4.1 + worldPos.x * 2.3 + worldPos.z * 1.9),
            sin(t * 3.7 + worldPos.z * 2.7 + worldPos.x * 1.3)
        ) * 0.015 * (0.4 + 0.8 * gust);

        playerPos.xz += sway * k;
        playerPos.y += sin(t * 0.9 + worldPos.x * 0.5 + worldPos.z * 0.8)
                     * amp * 0.35 * k * (0.5 + 0.5 * gust);
        moved = true;
    }

    // Lanternes suspendues : balancement PENDULAIRE ancré au plafond —
    // l'amplitude croît vers le bas (le haut de la chaîne reste accroché,
    // le corps oscille : fini la chaîne qui part en translation avec la
    // lanterne, retour KeanyKM). Les lanternes posées sont en 10010.
    if (mc_Entity.x == 10011.0 || mc_Entity.x == 11002.0) {
        float phase = worldPos.x * 1.3 + worldPos.z * 2.1;
        float hang = clamp(1.0 - fract(worldPos.y + 0.001), 0.0, 1.0);
        playerPos.xz += vec2(
            sin(t * 1.9 + phase),
            sin(t * 1.5 + phase * 1.4)
        ) * 0.022 * hang * (0.5 + 0.7 * gust) * (1.0 + rainStrength * 0.9);
        moved = true;
    }

    if (moved) viewPos = gbufferModelView * playerPos;

    gl_Position = gl_ProjectionMatrix * viewPos;
    gl_Position.xy += taaJitter() * gl_Position.w;
    viewVec = viewPos.xyz;
    worldPosV = worldPos;

    // Normal offset : le point testé dans la shadow map est décalé le long
    // de la normale — la parade anti-acné standard
    vec4 shadowSample = playerPos;
    shadowSample.xyz += (mat3(gbufferModelViewInverse) * normalV) * 0.06;
    shadowPos = shadowProjection * (shadowModelView * shadowSample);
    vertDist = length(playerPos.xyz);
}

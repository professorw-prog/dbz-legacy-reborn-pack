#version 120

// PLUIE 2.0 : les quads météo vanilla sont CISAILLÉS par le vent —
// plus un point est haut au-dessus de l'œil, plus il est emporté sous
// le vent : les stries PENCHENT, et penchent PLUS FORT dans les
// bourrasques (même champ de vent que la végétation : tout est cohérent).

#include "/lib/settings.glsl"
#include "/lib/jitter.glsl"
#include "/lib/wind.glsl"

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 worldPosV; // position APRÈS cisaillement (les stries y sont verticales)
varying float gustV;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;

    // Rafale À LA COLONNE du joueur : toute la pluie visible partage la
    // même inclinaison instantanée (elle "souffle" par vagues)
    vec2 wd = windDirection(frameTimeCounter);
    float gust = windGust(cameraPosition.xz, frameTimeCounter, rainStrength);
    gustV = gust;

    // Cisaillement : l'écart de hauteur à l'œil emporte le point sous le vent
    playerPos.xz += wd * playerPos.y * (0.07 + 0.09 * gust);

    viewPos = gbufferModelView * playerPos;
    gl_Position = gl_ProjectionMatrix * viewPos;
    gl_Position.xy += taaJitter() * gl_Position.w;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    worldPosV = playerPos.xyz + cameraPosition;
}

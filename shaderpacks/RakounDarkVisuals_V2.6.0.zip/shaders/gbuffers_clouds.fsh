#version 120

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.05) discard;

    vec3 sunDirW = safeNormalize(mat3(gbufferModelViewInverse) * sunPosition);
    float sunH = sunDirW.y;

    // Nuages bas et lourds, éclairés par le ciel ambiant
    vec3 albedo = srgbToLinear(tex.rgb);
    vec3 color = albedo * (getSkyAmbientColor(sunH, rainStrength) * 2.2
                         + getShadowLightColor(sunH, rainStrength) * 0.35);

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, tex.a * 0.85);
}

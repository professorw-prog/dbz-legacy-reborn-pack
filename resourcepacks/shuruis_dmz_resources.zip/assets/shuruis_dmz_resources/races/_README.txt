Reserved for the custom RACES editor.
Put race assets in the playermodel/, hair/ and aura/ folders here.

Reserved for the custom FORMS editor.
Put form assets in the playermodel/, hair/ and aura/ folders here.

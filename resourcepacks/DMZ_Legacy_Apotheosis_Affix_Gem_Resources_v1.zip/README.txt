Optional client resource pack for DMZ Legacy Apotheosis Affix & Gem Overhaul v1. Provides names and models for custom affixes/gems.
